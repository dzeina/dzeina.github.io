--Query 1
SELECT	COUNT(*) AS [Total Employees]
FROM	Employees

--Query 2
SELECT	COUNT(DISTINCT [Employee ID]) AS [Total Employees in Orders]
FROM	Orders

--Query 3
SELECT	E.[Last Name] + ' ' + E.[First Name] AS [Employee Name]
		,O.[Order Date]
FROM	Employees E 
		JOIN Orders O 
		ON E.ID=O.[Employee ID]
ORDER BY [Employee Name]

--Query 4
SELECT	E.[Last Name] + ' ' + E.[First Name] AS [Employee Name]
		,COUNT([Order ID])
FROM	Employees E 
		LEFT JOIN Orders O 
		ON E.ID=O.[Employee ID]
GROUP BY E.[Last Name] + ' ' + E.[First Name] 
ORDER BY [Employee Name]

--Query 5
SELECT	E.[Last Name] + ' ' + E.[First Name] AS [Employee Name]
		,COUNT([Order ID])
FROM	Orders O
		RIGHT JOIN Employees E 
		ON E.ID=O.[Employee ID]
GROUP BY E.[Last Name] + ' ' + E.[First Name] 
ORDER BY [Employee Name]

--Query 6
SELECT	MIN([List Price]) AS [Minimum Price], 
		AVG([List Price]) AS [Average Price], 
		MAX([List Price]) AS [Maximum Price]
FROM	Products

--Query 7
SELECT	City, Count(*) as [Number of Employees]
FROM	Employees
GROUP BY City
ORDER BY [Number of Employees] DESC

--Query 8
SELECT	[Order ID], MAX(Quantity*[Unit Price]) AS [Total Amount]
FROM	[Order Details]
GROUP BY [Order ID]

--Query 9
SELECT	[Order ID], SUM(Quantity*[Unit Price]) AS [Total Amount]
FROM	[Order Details]
GROUP BY [Order ID]
ORDER BY [Total Amount] DESC

--Query 10
SELECT	[Order ID], SUM(Quantity*[Unit Price]) AS [Total Amount]
FROM	[Order Details]
GROUP BY [Order ID]
HAVING	SUM(Quantity*[Unit Price])>2000
ORDER BY [Total Amount] DESC

--Query 11
SELECT	[Order ID], SUM(Quantity*[Unit Price]) AS [Total Amount]
FROM	[Order Details]
GROUP BY [Order ID]
HAVING	SUM(Quantity*[Unit Price])>=ALL(
		SELECT	SUM(Quantity*[Unit Price])
		FROM	[Order Details]
		GROUP BY [Order ID])
ORDER BY [Total Amount] DESC
