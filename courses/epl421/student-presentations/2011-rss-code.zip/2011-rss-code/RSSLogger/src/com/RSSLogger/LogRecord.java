package com.RSSLogger;

public class LogRecord {

	private long ts;
	private double lng;
	private double lat;
	private String bssid;
	private int rss;

	public LogRecord(long ts, double lng, double lat, String bssid, int rss) {
		super();
		this.ts = ts;
		this.lng = lng;
		this.lat = lat;
		this.bssid = bssid;
		this.rss = rss;
	}

	public String toString() {
		String str = new String();
		str = String.valueOf(ts) + " " + String.valueOf(lng) + " "
				+ String.valueOf(lat) + " " + String.valueOf(bssid) + " "
				+ String.valueOf(rss) + "\n";
		return str;
	}

}
