package com.RSSLogger;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RSSLogger extends Activity {

	private LocationManager mgr = null;
	private Location curLocation = null;

	private final LocationListener locationListener = new LocationListener() {

		public void onLocationChanged(Location location) {
			updateWithNewLocation("Location Changed:", location);
		}

		public void onProviderDisabled(String provider) {
			log("Provider disabled " + provider);
		}

		public void onProviderEnabled(String provider) {
			log("Provider enabled: " + provider);
		}

		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

	};
	private Object syncObject = new Object();
	private boolean isScanning;
	private Button Record_to_file;
	private Criteria criteria;
	private Spinner spinnerN;
	private TextView output;
	private TextView chooseN;
	private WifiManager mainWifi = null;
	private ArrayList<ArrayList<LogRecord>> samples = new ArrayList<ArrayList<LogRecord>>();
	private WifiReceiver receiverWifi;
	private Timer timer;
	private String bestProvider;
	private final String FILENAME_RSS = "rss-log.txt";
	private Toast toast;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		isScanning = false;
		output = (TextView) findViewById(R.id.output);

		/**
		 * Spinner create. Set invisible
		 * */
		spinnerN = (Spinner) findViewById(R.id.spinnerN);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.N_Samples_Array,
				android.R.layout.simple_spinner_item);
		adapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerN.setAdapter(adapter);
		spinnerN.setVisibility(View.INVISIBLE);

		/**
		 * The text to choice
		 * */
		chooseN = (TextView) findViewById(R.id.chooseN);
		chooseN
				.setText("Press \"Start Scan\" from Menu to start scanning for Access Points\n");

		/**
		 * Use the GPS
		 * */
		mgr = (LocationManager) getSystemService(LOCATION_SERVICE);

		/**
		 * Set criteria
		 * */
		criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_COARSE);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		criteria.setAltitudeRequired(true);
		criteria.setBearingRequired(false);
		criteria.setSpeedRequired(false);
		criteria.setCostAllowed(false);

		/**
		 * Use the WIFI
		 * */
		mainWifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);

		/**
		 * Create new receiver to get broadcasts
		 * */
		receiverWifi = new WifiReceiver();

		/**
		 * Button for recording
		 * */
		Record_to_file = (Button) findViewById(R.id.logChanges);
		Record_to_file.setOnClickListener(new Button.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				click_action_Record_Info();
			}
		});
		Record_to_file.setVisibility(View.INVISIBLE);

	}

	/**
	 * Draw the menu
	 * */
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.layout.mapmenu, menu);
		return true;
	}

	/**
	 * Method to handle menu choices
	 * */
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		/* Start Scanning */
		case R.id.Start_Scan:
			startScan();
			break;
		/* Stop Scanning */
		case R.id.Stop_Scan:
			stopScan();
			break;
		/* Make Radio Map */
		case R.id.Clear_Screen:
			if (output.getText().length() != 0) {
				output.setText("");
				toastPrint("Cleared!", R.drawable.info);
			} else
				toastPrint("Already Cleared!", R.drawable.warning);
			break;
		case R.id.Exit_App:

			onDestroy();
			finish();
			System.exit(0);
			break;
		}
		return true;
	}

	/**
	 * Start the AP and GPS scanning.
	 * */
	private void startScan() {

		if (isScanning) {
			toastPrint("Already Scanning...", R.drawable.warning);
			return;
		}
		isScanning = true;

		toastPrint("Start scanning for GPS and AP...", R.drawable.info);

		spinnerN.setVisibility(View.VISIBLE);
		chooseN.setText("Choose No of Samples:\n");
		Record_to_file.setVisibility(View.VISIBLE);
		output.setVisibility(View.VISIBLE);

		bestProvider = mgr.getBestProvider(criteria, true);
		Location location = mgr.getLastKnownLocation(bestProvider);
		curLocation = location;
		updateWithNewLocation("Starting Location:", location);

		/**
		 * Request for updates every 1 sec if 2m distance changed
		 * */
		mgr.requestLocationUpdates(bestProvider, 1000, 2, locationListener);

		if (!mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_ENABLING)
				mainWifi.setWifiEnabled(true);

		registerReceiver(receiverWifi, new IntentFilter(
				WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

		/* Autoscan every 2 sec */
		timer = new Timer();

		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mainWifi.startScan();

			}
		}, 2000, 2000);

	}

	private void stopScan() {

		if (!isScanning) {
			toastPrint("Scanning already stopped!", R.drawable.warning);
			return;
		}
		isScanning = false;

		toastPrint("Scanning Stopped", R.drawable.info);

		spinnerN.setVisibility(View.INVISIBLE);
		Record_to_file.setVisibility(View.INVISIBLE);
		output.setVisibility(View.INVISIBLE);
		output.setText("");
		chooseN
				.setText("Press \"Start Scan\" from Menu to start scanning for Access Points\n");

		if (locationListener != null)
			mgr.removeUpdates(locationListener);

		if (mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_DISABLING)
				mainWifi.setWifiEnabled(false);

		unregisterReceiver(receiverWifi);
	}

	/**
	 * Write to rss-log.txt
	 * */
	private void click_action_Record_Info() {

		// TODO Auto-generated method stub
		String choice = (String) spinnerN.getSelectedItem();
		int N = Integer.parseInt(choice);
		String header = "# Timestamp, Longitude, Latitude, MAC Address of AP, RSS\n";
		ArrayList<LogRecord> writeRecords;
		LogRecord writeLR;

		synchronized (syncObject) {

			if (!samples.isEmpty()) {
				try {

					File root = Environment.getExternalStorageDirectory();
					if (root.canWrite()) {
						FileOutputStream fos = new FileOutputStream(new File(
								root, FILENAME_RSS), true);

						for (int i = 0; i < N && i < samples.size(); ++i) {
							fos.write(header.getBytes());
							writeRecords = samples.get(i);
							for (int j = 0; j < writeRecords.size(); ++j) {
								writeLR = writeRecords.get(j);
								fos.write(writeLR.toString().getBytes());
							}
						}

						if (!samples.isEmpty()) {

							toastPrint(((N < samples.size()) ? N : samples
									.size())
									+ " Samples Recorded on\n"
									+ Calendar.getInstance().getTime()
											.toString(), R.drawable.info);
							log(((N < samples.size()) ? N : samples.size())
									+ " Samples Recorded on\n"
									+ Calendar.getInstance().getTime()
											.toString());
							samples.clear();
						}

						fos.close();
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					toastPrint("Error occured while writing to log",
							R.drawable.error);
				}
			} else
				toastPrint("No stored samples. Start a scan first",
						R.drawable.warning);
		}
	}

	/**
	 * Receive AP results
	 * */
	class WifiReceiver extends BroadcastReceiver {

		public void onReceive(Context c, Intent intent) {

			List<ScanResult> wifiList = mainWifi.getScanResults();
			ArrayList<LogRecord> Records = new ArrayList<LogRecord>();
			Records.clear();

			Date date = new Date();
			long timestamp = date.getTime();

			log(wifiList.size() + " Access Points Received");
			Location temp_location;

			synchronized (syncObject) {
				temp_location = curLocation;
			}

			if (temp_location != null && !wifiList.isEmpty()) {
				for (int i = 0; i < wifiList.size(); i++) {
					LogRecord lr = new LogRecord(timestamp, temp_location
							.getLatitude(), temp_location.getLongitude(),
							wifiList.get(i).BSSID, wifiList.get(i).level);
					Records.add(lr);
				}
				synchronized (syncObject) {
					samples.add(0, Records);
				}
			}
		}
	}

	/**
	 * Method used to print pop up message to user
	 * */
	protected void toastPrint(String textMSG, int imageID) {

		LayoutInflater inflater = getLayoutInflater();
		View layout = inflater.inflate(R.layout.toast_layout,
				(ViewGroup) findViewById(R.id.toast_layout_root));

		ImageView image = (ImageView) layout.findViewById(R.id.toast_image);
		image.setImageResource(imageID);
		TextView text = (TextView) layout.findViewById(R.id.toast_text);
		text.setText(textMSG);
		toast = new Toast(getApplicationContext());
		toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
		toast.setDuration(Toast.LENGTH_SHORT);
		toast.setView(layout);
		toast.show();
	}

	/**
	 * Show messages to screen
	 * */
	private void updateWithNewLocation(String msg, Location location) {

		String latLongString;

		if (location != null) {
			double lat = location.getLatitude();
			double lng = location.getLongitude();
			latLongString = "Longitute: " + lat + "\nLatitude: " + lng;
		} else {
			latLongString = "No location found";
		}
		log(msg + "\n" + latLongString);

		synchronized (syncObject) {
			curLocation = location;
		}
	}

	/**
	 * Show on screen updates and info
	 * */
	private void log(String string) {
		output.setText("\n" + string + "\n" + output.getText() + "\n");
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		if (mgr != null && locationListener != null)
			mgr.removeUpdates(locationListener);
		if (mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_DISABLING)
				mainWifi.setWifiEnabled(false);
		if (isScanning) {
			log("Scanning stopped!");
			isScanning = false;
			unregisterReceiver(receiverWifi);
		}
		super.onStop();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {

		// Stop updates to save power while app paused
		if (mgr != null && locationListener != null)
			mgr.removeUpdates(locationListener);
		if (mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_DISABLING)
				mainWifi.setWifiEnabled(false);
		if (isScanning) {
			log("Scanning paused!");
			isScanning = false;
			unregisterReceiver(receiverWifi);
		}
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (mgr != null && locationListener != null)
			mgr.removeUpdates(locationListener);
		if (mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_DISABLING)
				mainWifi.setWifiEnabled(false);
		super.onDestroy();
	}
}