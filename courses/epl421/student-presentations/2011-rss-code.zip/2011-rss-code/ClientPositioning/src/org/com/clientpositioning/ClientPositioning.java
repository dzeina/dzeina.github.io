package org.com.clientpositioning;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.location.Location;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ClientPositioning extends Activity {

	SharedPreferences settings;
	SharedPreferences algorithms;

	public static String myGeo = null;
	public static String realGeo = null;

	private boolean isScanning;
	public static TextView output;
	private TextView title;
	private Toast toast;

	private Button btnDownload;
	private Button btnFindMe;

	private String serverAddress = new String();
	private String portNumber = new String();
	private Socket connection = null;
	private boolean IN_PROGRESS = false;

	private final String FILENAME_RADIO_MAP = "radio-map.txt";

	private Object syncObject = new Object();
	private RadioMap RM;
	private String algorithmSelection;
	ArrayList<LogRecord> LastScanList;
	private WifiManager mainWifi = null;
	private WifiReceiver receiverWifi;
	private Timer timer;

	/**
	 * Called when the activity is first created.
	 * */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		LastScanList = new ArrayList<LogRecord>();
		output = (TextView) findViewById(R.id.output);
		title = (TextView) findViewById(R.id.title);
		btnDownload = (Button) findViewById(R.id.downloadRadioMap);
		btnFindMe = (Button) findViewById(R.id.find_me);
		isScanning = false;
		title.setText("Starting the Application");

		/*
		 * Enable wifi
		 */
		mainWifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);

		receiverWifi = new WifiReceiver();

		log("Start Scanning for near Access Points...");
		/*
		 * Start scanning access points
		 */
		startScan();

		/*
		 * Get previous preferences
		 */
		settings = PreferenceManager.getDefaultSharedPreferences(this);
		initialDownload(this);

		algorithms = PreferenceManager.getDefaultSharedPreferences(this);
		initialFindMe(this);
	}

	/* Creates the menu items */
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}

	// This method is called once the menu is selected
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.Setup_Properties:
			// Launch Preference activity
			Intent downloadRM = new Intent(ClientPositioning.this,
					SetupProperties.class);
			startActivity(downloadRM);

			toastPrint("Aplication Settings are Stored", R.drawable.info);
			break;

		case R.id.Choose_Algorithm:
			Intent findME = new Intent(ClientPositioning.this,
					ChooseAnAlgorithm.class);
			startActivity(findME);

			toastPrint("Processing the algorithm", R.drawable.info);
			break;
		}
		return true;
	}

	private void calculateProbabilisticAlgorithm() {
		// TODO Auto-generated method stub
		String myGeo;
		toastPrint("Probabilistic Algorithm", R.drawable.info);
		myGeo = Algorithms.NearestNeighboor(LastScanList, RM, 2);
		log("\nEstimated Coordinates: \n" + myGeo);

		ClientPositioning.myGeo = myGeo;

		Intent onMap = new Intent(ClientPositioning.this, FindMeOnMap.class);
		startActivityForResult(onMap, 2);

	}

	private void calculateNearestNeighborAlgorithm() {
		// TODO Auto-generated method stub
		String myGeo;
		toastPrint("Nearest Neighbor Algorithm", R.drawable.info);

		myGeo = Algorithms.NearestNeighboor(LastScanList, RM, 1);
		log("\nEstimated Coordinates:\n" + myGeo);

		ClientPositioning.myGeo = myGeo;

		Intent onMap = new Intent(ClientPositioning.this, FindMeOnMap.class);
		startActivityForResult(onMap, 1);

	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 1) {
			if (ClientPositioning.realGeo != null) {

				String coordinates1[] = ClientPositioning.myGeo.replace(", ",
						" ").split(" ");
				double lng1 = Double.parseDouble(coordinates1[0]);
				double lat1 = Double.parseDouble(coordinates1[1]);

				String coordinates2[] = ClientPositioning.realGeo.replace(", ",
						" ").split(" ");
				double lng2 = Double.parseDouble(coordinates2[0]);
				double lat2 = Double.parseDouble(coordinates2[1]);

				// float posError = (float) Math.sqrt((lng1 - lng2)
				// * (lng1 - lng2) + (lat1 - lat2) * (lat1 - lat2));
				float[] results = new float[1];
				Location.distanceBetween(lat1, lng1, lat2, lng2, results);
				if (results != null)
					log("Nearest Neighbor Algorithm Positioning Error: \n"
							+ results[0] + "m.");

				log("Actual Position: \n" + ClientPositioning.realGeo);
			} else
				log("Could not calculate Nearest Neighbor Algorithm Positioning Error");
		} else if (requestCode == 2) {
			if (ClientPositioning.realGeo != null) {

				String coordinates1[] = ClientPositioning.myGeo.replace(", ",
						" ").split(" ");
				double lng1 = Double.parseDouble(coordinates1[0]);
				double lat1 = Double.parseDouble(coordinates1[1]);

				String coordinates2[] = ClientPositioning.realGeo.replace(", ",
						" ").split(" ");
				double lng2 = Double.parseDouble(coordinates2[0]);
				double lat2 = Double.parseDouble(coordinates2[1]);

				// float posError = (float) Math.sqrt((lng1 - lng2)
				// * (lng1 - lng2) + (lat1 - lat2) * (lat1 - lat2));
				float[] results = new float[1];
				Location.distanceBetween(lat1, lng1, lat2, lng2, results);
				if (results != null)
					log("Probabilistic Algorithm Positioning Error: \n"
							+ results[0] + "m.");

				log("Actual Position: \n" + ClientPositioning.realGeo);
			} else
				log("Could not calculate Probabilistic Algorithm Positioning Error");
		}
	}

	private void initialFindMe(ClientPositioning cl) {

		btnFindMe.setOnClickListener(new Button.OnClickListener() {

			public void onClick(View v) {

				algorithmSelection = algorithms.getString("Algorithms", "n/a");

				if (algorithmSelection.equals("n/a")
						|| algorithmSelection.equals("")) {
					toastPrint(
							"Unable to find the location\nChoose one of the 2 Algorithms \nGO To menu->Settings",
							R.drawable.error);

					return;
				}

				synchronized (syncObject) {
					if (IN_PROGRESS == true)
						return;
					IN_PROGRESS = true;
				}

				unregisterReceiver(receiverWifi);

				if (LastScanList.isEmpty()) {
					toastPrint("No Access Point Received. "
							+ "Wait for a scan first and try again.",
							R.drawable.warning);
					synchronized (syncObject) {
						IN_PROGRESS = false;
					}
					registerReceiver(receiverWifi, new IntentFilter(
							WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
					return;
				}
				File root = Environment.getExternalStorageDirectory();

				if (!root.canRead()) {
					toastPrint("Internal Error occured. "
							+ "Can't read from directory "
							+ root.getAbsolutePath()
							+ "\nYou may need an external memory card",
							R.drawable.error);
					synchronized (syncObject) {
						IN_PROGRESS = false;
					}
					registerReceiver(receiverWifi, new IntentFilter(
							WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
					return;
				}

				/* Call function to get the Radio Map */
				RM = ReadFromFileRM.ReadRadioMap(new File(root,
						FILENAME_RADIO_MAP));

				/* Error reading Radio Map */
				if (RM == null) {
					toastPrint("Error while reading radio map. "
							+ "Download Radio Map and try again.",
							R.drawable.error);
					synchronized (syncObject) {
						IN_PROGRESS = false;
					}
					registerReceiver(receiverWifi, new IntentFilter(
							WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
					return;
				}

				output.setText("here");

				if (algorithmSelection.equals("1"))
					calculateNearestNeighborAlgorithm();
				else if (algorithmSelection.equals("2"))
					calculateProbabilisticAlgorithm();

				registerReceiver(receiverWifi, new IntentFilter(
						WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

				synchronized (syncObject) {
					IN_PROGRESS = false;
				}
			}
		});

	}

	private void initialDownload(ClientPositioning cl) {

		btnDownload.setOnClickListener(new Button.OnClickListener() {

			public void onClick(View v) {

				serverAddress = settings.getString("serverAdd", "n/a");

				if (serverAddress.equals("n/a") || serverAddress.equals("")) {
					toastPrint(
							"Unable to start connection with the server\nSpecify the server's IP and port \nGO To menu->Settings",
							R.drawable.error);
					return;
				}

				portNumber = settings.getString("port", "n/a");

				if (portNumber.equals("n/a") || portNumber.equals("")) {
					toastPrint(
							"Unable to start connection with the server\nSpecify the server's IP and port \nGO To menu->Settings",
							R.drawable.error);

				}

				synchronized (syncObject) {
					if (IN_PROGRESS == true)
						return;
					IN_PROGRESS = true;
				}

				output.setText("");

				log("Connecting to " + serverAddress + ":" + portNumber + "...");
				serverConnect();

				synchronized (syncObject) {
					IN_PROGRESS = false;
				}

			}
		});

	}

	private void serverConnect() {

		String host = new String(serverAddress);
		String port = new String(portNumber);
		FileOutputStream fos;
		File root = Environment.getExternalStorageDirectory();

		try {
			// CONNECT TO SERVER

			connection = new Socket(host, Integer.parseInt(port));

			log("Socket created.\nConnecting to server IP " + host
					+ " on port " + port + "...\n");

			if (root.canWrite()) {
				fos = new FileOutputStream(new File(root, FILENAME_RADIO_MAP),
						false);
			} else {
				toastPrint("Internal Error occured. Can't write to directory "
						+ root.getAbsolutePath()
						+ "\nYou may need an external memory card",
						R.drawable.error);
				return;
			}

			PrintWriter out = new PrintWriter(connection.getOutputStream(),
					true);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					connection.getInputStream()));
			String inputLine, outputLine;

			inputLine = in.readLine();

			if (!inputLine.equalsIgnoreCase("+OK READY")) {
				log("Server not ready\n");
				fos.close();
				out.close();
				in.close();
				connection.close();
				return;
			}
			log("SERVER: " + inputLine);

			do {
				outputLine = "GET radiomap";
				log("CLIENT: " + outputLine);
				out.println(outputLine);
				inputLine = in.readLine();
			} while (inputLine.startsWith("ERROR"));

			if (inputLine.startsWith("UNAVAILABLE")
					|| inputLine.compareTo("null") == 0) {
				log("Server is unavailable\n");
				fos.close();
				out.close();
				in.close();
				connection.close();
				return;
			}
			log("");
			output.append("SERVER: " + inputLine);

			inputLine = inputLine.replaceFirst("RADIOMAP ", "");
			fos.write((inputLine + "\n").getBytes());

			while ((inputLine = in.readLine()) != null) {
				if (inputLine.compareTo("null") == 0
						|| inputLine.startsWith("CORRUPTED"))
					break;
				output.append(" | " + inputLine);
				fos.write((inputLine + "\n").getBytes());
			}

			output.append("\n");

			fos.close();
			out.close();
			in.close();
			connection.close();
			toast.setDuration(Toast.LENGTH_LONG);
			toastPrint("Radio Map Successfully Received and Stored in \""
					+ root.getAbsolutePath() + "\" on "
					+ Calendar.getInstance().getTime().toString(),
					R.drawable.info);

		} catch (Exception e) {
			log("Error: " + e.getMessage());
		} // end try
	}

	/**
	 * Receive AP results
	 * */
	class WifiReceiver extends BroadcastReceiver {

		public void onReceive(Context c, Intent intent) {

			synchronized (syncObject) {
				if (IN_PROGRESS == true)
					return;
				IN_PROGRESS = true;
			}
			List<ScanResult> wifiList = mainWifi.getScanResults();

			LastScanList.clear();

			if (!wifiList.isEmpty()) {
				for (int i = 0; i < wifiList.size(); i++) {
					LogRecord lr = new LogRecord(wifiList.get(i).BSSID,
							wifiList.get(i).level);
					LastScanList.add(lr);
				}
			}

			synchronized (syncObject) {
				IN_PROGRESS = false;
			}
		}
	}

	private void startScan() {

		if (isScanning) {
			return;
		}
		isScanning = true;

		if (!mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_ENABLING)
				mainWifi.setWifiEnabled(true);

		registerReceiver(receiverWifi, new IntentFilter(
				WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

		// Initiate a scan.
		timer = new Timer();
		// change the mode of the comparison
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mainWifi.startScan();

			}
		}, 2000, 2000);

	}

	private void stopScan() {

		if (!isScanning) {
			return;
		}
		isScanning = false;

		if (mainWifi.isWifiEnabled())
			if (mainWifi.getWifiState() != WifiManager.WIFI_STATE_DISABLING)
				mainWifi.setWifiEnabled(false);

		unregisterReceiver(receiverWifi);
	}

	protected void toastPrint(String textMSG, int imageID) {

		LayoutInflater inflater = getLayoutInflater();
		View layout = inflater.inflate(R.layout.toast_layout,
				(ViewGroup) findViewById(R.id.toast_layout_root));

		ImageView image = (ImageView) layout.findViewById(R.id.toast_image);
		image.setImageResource(imageID);
		TextView text = (TextView) layout.findViewById(R.id.toast_text);
		text.setText(textMSG);
		toast = new Toast(getApplicationContext());
		toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
		toast.setDuration(Toast.LENGTH_SHORT);
		toast.setView(layout);
		toast.show();
	}

	/**
	 * Show on screen updates and info
	 * */
	private void log(String string) {
		output.append(string + "\n");
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		// Stop updates to save power while app paused
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		stopScan();
		super.onDestroy();
	}

}