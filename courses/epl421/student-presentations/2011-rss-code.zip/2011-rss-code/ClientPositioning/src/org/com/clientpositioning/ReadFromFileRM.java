package org.com.clientpositioning;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * 
 * @author Silouanos
 */
public class ReadFromFileRM {


	public static RadioMap ReadRadioMap(File inFile) {

		if (!inFile.exists() || !inFile.canRead()) {
			return null;
		}

		RadioMap rm = new RadioMap();
		ArrayList<String> MacAdressList = rm.getMacAdressList();
		HashMap<String, ArrayList<String>> GeolocationRSS_HashMap = rm
				.getGeolocationRSS_HashMap();
		ArrayList<String> RSS_Values;
		BufferedReader reader = null;
		String line;
		String[] temp;
		String key;

		try {

			reader = new BufferedReader(new FileReader(inFile));

			/* Read the first line */
			line = reader.readLine();
			/* Must exists */
			if (line == null)
				return null;

			line = line.replace(", ", " ");
			temp = line.split(" ");

			/* Must have more than 4 fields */
			if (temp.length < 4)
				return null;

			/* Store all Mac Addresses */
			for (int i = 3; i < temp.length; ++i)
				MacAdressList.add(temp[i]);

			while ((line = reader.readLine()) != null) {
				line = line.replace(", ", " ");
				temp = line.split(" ");

				if (temp.length < 3)
					break;

				key = temp[0] + " " + temp[1];

				RSS_Values = new ArrayList<String>();

				for (int i = 2; i < temp.length; ++i)
					RSS_Values.add(temp[i]);

				GeolocationRSS_HashMap.put(key, RSS_Values);
			}

			reader.close();
		} catch (Exception ex) {
			return null;
		}
		return rm;
	}
}
