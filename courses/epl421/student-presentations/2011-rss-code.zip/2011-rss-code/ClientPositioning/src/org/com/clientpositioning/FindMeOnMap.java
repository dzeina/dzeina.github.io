package org.com.clientpositioning;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class FindMeOnMap extends MapActivity {

	private MapController mapController;
	private MapView mapView;
	private LocationManager locationManager;
	private GeoPoint p;
	private GeoPoint realP = null;
	MarkerOverlay markerOverlay;
	List<Overlay> listOfOverlays;

	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.map_layout); // bind the layout to the activity

		// create a map view

		mapView = (MapView) findViewById(R.id.mapview);
		mapView.setBuiltInZoomControls(true);
		mapView.setStreetView(true);
		mapController = mapView.getController();
		mapController.setZoom(18); // Zoon 1 is world view
		mapView.setClickable(true);
		mapView.setEnabled(true);

		String coordinates[] = ClientPositioning.myGeo.replace(", ", " ")
				.split(" ");
		// String coordinates[] = {" 35.009875", "33.322311"};
		double lat = Double.parseDouble(coordinates[0]);
		double lng = Double.parseDouble(coordinates[1]);

		p = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));

		mapController.animateTo(p);

		// mapView.setSatellite(true);

		markerOverlay = new MarkerOverlay();
		List<Overlay> listOfOverlays = mapView.getOverlays();
		listOfOverlays.clear();
		listOfOverlays.add(markerOverlay);

		mapView.invalidate();

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,
				0, new GeoUpdateHandler());
	}

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

	public class GeoUpdateHandler implements LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			int lat = (int) (location.getLatitude() * 1E6);
			int lng = (int) (location.getLongitude() * 1E6);
			realP = new GeoPoint(lat, lng);
			markerOverlay = new MarkerOverlay();
			List<Overlay> listOfOverlays = mapView.getOverlays();
			listOfOverlays.add(markerOverlay);
			mapView.invalidate();

			locationManager.removeUpdates(this);
		}

		@Override
		public void onProviderDisabled(String provider) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}
	}

	public class MarkerOverlay extends Overlay {

		Geocoder geoCoder = null;

		public MarkerOverlay() {
			super();
		}

		@Override
		public void draw(Canvas canvas, MapView mapV, boolean shadow) {

			if (shadow) {

				Projection projection = null;
				Point pt = null;

				if (realP == null) {
					projection = mapV.getProjection();
					pt = new Point();
					projection.toPixels(p, pt);

					Bitmap markerBitmap = BitmapFactory.decodeResource(
							getApplicationContext().getResources(),
							R.drawable.pin);
					canvas.drawBitmap(markerBitmap, pt.x,
							pt.y - markerBitmap.getHeight(), null);
				} else {

					projection = mapV.getProjection();
					pt = new Point();
					projection.toPixels(p, pt);

					Point pt2 = new Point();
					projection.toPixels(realP, pt2);
					
					ClientPositioning.realGeo = (float) realP.getLatitudeE6()/(float)1E6 + ", "+(float) realP.getLongitudeE6()/(float)1E6;
					
					float circleRadius = (float) Math.sqrt((pt2.y - pt.y)
							* (pt2.y - pt.y) + (pt2.x - pt.x) * (pt2.x - pt.x));

					Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
					
					circlePaint.setColor(0x44AA0000);

					circlePaint.setStyle(Style.FILL_AND_STROKE);
					canvas.drawCircle((float) pt.x, (float) pt.y, circleRadius,
							circlePaint);

					circlePaint.setColor(0x99000000);
					circlePaint.setStyle(Style.STROKE);
					canvas.drawCircle((float) pt.x, (float) pt.y, circleRadius,
							circlePaint);

					Bitmap markerBitmap2 = BitmapFactory.decodeResource(
							getApplicationContext().getResources(),
							R.drawable.pin2);
					canvas.drawBitmap(markerBitmap2, pt2.x, pt2.y
							- markerBitmap2.getHeight()+20, null);

					Bitmap markerBitmap = BitmapFactory.decodeResource(
							getApplicationContext().getResources(),
							R.drawable.pin);
					canvas.drawBitmap(markerBitmap, pt.x,
							pt.y - markerBitmap.getHeight(), null);

					circlePaint.setColor(0xFF000000);
					circlePaint.setStrokeWidth(5);

					canvas.drawLine(pt.x, pt.y, pt2.x, pt2.y, circlePaint);

				}
				super.draw(canvas, mapV, shadow);
			}
		}
	}
}
