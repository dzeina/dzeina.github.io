package org.com.clientpositioning;

import java.util.ArrayList;
import java.lang.Math;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * 
 * @author Silouanos
 */
public class Algorithms {

	private static int sGreek = 6;
	
	public static String NearestNeighboor(ArrayList<LogRecord> lastScanList,
			RadioMap RM, int choice) {

		int i, j;

		ArrayList<String> MacAdressList = RM.getMacAdressList();
		ArrayList<String> RSS_Values;
		ArrayList<String> temp_Order_RSS_Values = new ArrayList<String>();
		LogRecord temp_LR;
		String myGeolocation = "";
		float bestResult;
		
		if (choice == 1) {
			bestResult = Float.MAX_VALUE;
		} else
			bestResult = -1;
		
		float curResult = 0;

		for (i = 0; i < MacAdressList.size(); ++i) {

			for (j = 0; j < lastScanList.size(); ++j) {

				temp_LR = lastScanList.get(j);
				/* MAC Address Matching */
				if (MacAdressList.get(i).compareTo(temp_LR.getBssid()) == 0) {
					temp_Order_RSS_Values.add(String.valueOf(temp_LR.getRss()));
					break;
				}
			}
			if (j == lastScanList.size())
				temp_Order_RSS_Values.add(String.valueOf(-110));
		}

		for (String Geolocation : RM.getGeolocationRSS_HashMap().keySet()) {
			
			RSS_Values = RM.getGeolocationRSS_HashMap().get(Geolocation);
			if (choice == 1) {
				curResult = nnAlg(RSS_Values, temp_Order_RSS_Values);
				if (curResult < bestResult) {
					bestResult = curResult;
					myGeolocation = Geolocation;
				}
			} else {
				curResult = PosAlg(RSS_Values, temp_Order_RSS_Values);
				if (curResult > bestResult) {
					bestResult = curResult;
					myGeolocation = Geolocation;
				}
			}
		}

		return myGeolocation;
	}

	/**
	 * 
	 * @param l1
	 * @param l2
	 * @return
	 */
	public static float nnAlg(ArrayList<String> l1, ArrayList<String> l2) {

		float finalResult = 0;
		float v1;
		float v2;
		float temp;
		String str;

		for (int i = 0; i < l1.size(); ++i) {

			str = l1.get(i);
			//ClientPositioning.output.append(str);
			v1 = Float.valueOf(str.trim()).floatValue();
			//return (float) 3.0;
			str = l2.get(i);

			v2 = Float.valueOf(str.trim()).floatValue();

			// do the procedure
			temp = v1 - v2;
			temp *= temp;
			// do the procedure
			finalResult += temp;
		}
		return ((float) Math.sqrt(finalResult));
	}

	/**
	 * 
	 * @param l1
	 *            first array list
	 * @param l2
	 *            second array list
	 * @return the final double value
	 */
	public static float PosAlg(ArrayList<String> l1, ArrayList<String> l2) {

		float finalResult = 1;
		float v1;
		float v2;
		float temp;
		String str;
		
		for (int i = 0; i < l1.size(); ++i) {
			
			str = l1.get(i);

			v1 = Float.valueOf(str.trim()).floatValue();

			str = l2.get(i);
			
			v2 = Float.valueOf(str.trim()).floatValue();

			// do the procedure
			temp = v1 - v2;
			
			temp *= temp;
			
			temp = -temp;
			
			temp /= (float) (sGreek * sGreek);
			temp = (float) Math.exp(temp);
			// do the procedure
			finalResult*=temp;
		}
		return finalResult;
	}
}
