package org.com.clientpositioning;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Silouanos
 */
import java.util.ArrayList;
import java.util.HashMap;

public class RadioMap {
	
	private ArrayList<String> MacAdressList;
	private HashMap<String, ArrayList<String>> GeolocationRSS_HashMap;

	public RadioMap() {
		super();
		MacAdressList = new ArrayList<String>();
		GeolocationRSS_HashMap = new HashMap<String, ArrayList<String>>();
	}
	
	public ArrayList<String> getMacAdressList() {
		return MacAdressList;
	}

	public HashMap<String, ArrayList<String>> getGeolocationRSS_HashMap() {
		return GeolocationRSS_HashMap;
	}
	
	public String toString(){
		String str="MAC Adresses: ";
		ArrayList<String> temp;
		for (int i=0; i < MacAdressList.size(); ++i)
			str+=MacAdressList.get(i)+" ";
		
		str+="\nGeolocations\n";
		for (String Geolocation : GeolocationRSS_HashMap.keySet()) {
			str+=Geolocation + " ";
			temp=GeolocationRSS_HashMap.get(Geolocation);
			for (int i=0; i< temp.size(); ++i)
				str+=temp.get(i) + " ";
			str+="\n";
		}
		
		return str;
	}
}
