import java.net.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")
public class Server extends Frame implements WindowListener, KeyListener {

	boolean listening = true;
	static int ServerPort = 65510;
	static final Lock lock = new ReentrantLock();
	static TextArea logDisplay;
	String path = null;
	String filename = "./radio-map.txt";
	ServerSocket ListenSocket;
	Socket Connection;
	OutputStream outStream;
	DataOutputStream outDataStream;
	TextField filetext;
	String message;
	HashMap<String, HashMap<String, ArrayList<Integer>>> RadioMap;
	boolean flag = true;
	
	public Server() {
		super("Server");
		RadioMap = new HashMap<String, HashMap<String, ArrayList<Integer>>>();
		logDisplay = new TextArea(40, 10);
		add(BorderLayout.CENTER, logDisplay);
		filetext = new TextField();
		filetext.addKeyListener(this);
		add(BorderLayout.PAGE_END, filetext);
		addWindowListener(this);
		setSize(600, 500);
		setVisible(true);
		logDisplay.setEditable(false);
	} // end Server_Basic constructor

	public void runServer() {

		try {
			ListenSocket = new ServerSocket(ServerPort);
			logDisplay.setText("Starting Radio Map Server on port "
					+ ServerPort + "\n");
			try {
				InetAddress here = InetAddress.getLocalHost();
				// Get server's IP Address
				logDisplay.append("Server Started on " + here.getHostName()
						+ " with IP:PORT [" + here.getHostAddress() + ":"
						+ ServerPort + "]\n");
			} catch (UnknownHostException e) {
				logDisplay.setText("Problem with local host\n");
			}

			logDisplay.append("Please give the path to RSS log "
					+ "files to generate the Radio Map" + " at bottom"
					+ " of the window\n");
			while (flag)
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			// wait while clients are connected
			logDisplay.append("Listening for Connections...");
			while (listening) {
				Connection = ListenSocket.accept();
				logDisplay.append("\nConnection request received from "
						+ Connection.getInetAddress().getHostName());
				MultiServerThread thread = new MultiServerThread(Connection, filename);
				thread.start();
			}// end of while(true)
			ListenSocket.close();
		} // end try
		catch (IOException except) {
			except.printStackTrace();
		} // end catch
	} // end runServer

	public static void main(String[] args) {

		Server server = new Server();

		server.runServer();

	} // end main

	public void windowActivated(WindowEvent e) {
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		setVisible(false);
		this.dispose();
		System.exit(0);
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	/** Handle the key typed event from the text field. */
	public void keyTyped(KeyEvent e) {

		if (e.getKeyChar() == '\n' && filetext.isEditable()) {
			path = filetext.getText();
			logDisplay.append("The given path is '" + path + "'\n");
			if (!readFromPath(path))
				logDisplay
						.append("Existed Radio Map will be used if exists!\n");
			else
				logDisplay.append("Created new Radio Map!\n");
			filetext.setEditable(false);
			filetext.setText("The server is up and running!");
			flag=false;
		}
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
	}

	public boolean readFromPath(String path) {

		File inFile = new File(path);
		if (!inFile.exists() || !inFile.isDirectory()) {
			logDisplay.append("You gave a path that does "
					+ "not exist or is not directory\n"
					+ "No new Radio Map will be created.\n");
			return false;
		}

		RadioMap.clear();
		createRadioMapFromPath(inFile);

		if (!writeRadioMap())
			return false;
		return true;
	}

	/**
	 * Write the new Radio Map
	 * */
	private boolean writeRadioMap() {

		DecimalFormat dec = new DecimalFormat("###.#");
		HashMap<String, ArrayList<Integer>> MACAddressMap;
		ArrayList<Integer> RSS_Values;
		FileOutputStream fos;
		File outp;
		if (RadioMap.isEmpty()) {
			logDisplay.append("Directory did not contain any files "
					+ "or files have different format than expected!\n");
			return false;
		}

		try {
			outp = new File(filename);
			fos = new FileOutputStream(outp, false);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			return false;
		}

		try {
			/* Store all unique MAC addresses */
			HashSet<String> s = new HashSet<String>();

			for (String Geolocation : RadioMap.keySet()) {
				MACAddressMap = RadioMap.get(Geolocation);
				s.addAll(MACAddressMap.keySet());
			}

			/* Start the print out to Radio Map file */
			fos.write("# Longitude, Latitude".getBytes());

			Iterator<String> iterator = s.iterator();
			while (iterator.hasNext()) {
				fos.write(", ".getBytes());
				fos.write(iterator.next().getBytes());
			}
			fos.write("\n".getBytes());

			/*
			 * For each Geolocation print the Average RSS of every single MAC
			 * Address
			 */
			iterator = s.iterator();
			String MacAddress;

			for (String Geolocation : RadioMap.keySet()) {

				fos.write(Geolocation.replace(" ", ", ").getBytes());

				MACAddressMap = RadioMap.get(Geolocation);

				iterator = s.iterator();

				/*
				 * For every MAC Address print average RSS value, or -110 if
				 * does not exist
				 */
				while (iterator.hasNext()) {

					MacAddress = iterator.next();

					RSS_Values = MACAddressMap.get(MacAddress);

					if (RSS_Values == null)
						fos.write(", -110".getBytes());
					else {
						float rss_sum = (float) 0.0;
						float rss_avg = (float) 0.0;
						for (int i = 0; i < RSS_Values.size(); ++i)
							rss_sum += RSS_Values.get(i);
						rss_avg = rss_sum / RSS_Values.size();
						fos.write((", " + dec.format(rss_avg)).getBytes());
					}
				}
				fos.write("\n".getBytes());
			}
		} catch (Exception e) {
			outp.delete();
			return false;
		}
		return true;
	}

	/**
	 * Creates the new Radio Map
	 * */
	private void createRadioMapFromPath(File inFile) {
		// TODO Auto-generated method stub
		if (inFile.exists()) {

			if (inFile.canExecute() && inFile.isDirectory()) {
				// System.out.println("Directory:" + inFile.getAbsolutePath());
				String[] list = inFile.list();

				if (list != null) {
					for (int i = 0; i < list.length; i++)
						createRadioMapFromPath(new File(inFile, list[i]));
				}

			} else if (inFile.canRead() && inFile.isFile()) {
				// System.out.println("File:" + inFile.getAbsolutePath());
				parseLogFileToRadioMap(inFile);
			}
		}
	}

	private void parseLogFileToRadioMap(File inFile) {

		BufferedReader reader = null;
		HashMap<String, ArrayList<Integer>> MACAddressMap;
		ArrayList<Integer> RSS_Values;
		String key = "";

		try {
			String line;
			reader = new BufferedReader(new FileReader(inFile));

			while ((line = reader.readLine()) != null) {
				/* Ignore the labels */
				if (line.startsWith("#"))
					continue;

				/* Remove commas */
				line = line.replace(", ", " ");

				/* Split fields */
				String[] temp = line.split(" ");

				/* The file may be corrupted so ignore reading it */
				if (temp.length != 5)
					break;

				/* Key of Geolocation X,Y */
				key = temp[1] + " " + temp[2];

				/*
				 * Get the current geolocation value
				 */
				MACAddressMap = RadioMap.get(key);

				/*
				 * Geolocation first read so far
				 */
				if (MACAddressMap == null) {
					MACAddressMap = new HashMap<String, ArrayList<Integer>>();
					RSS_Values = new ArrayList<Integer>();
					RSS_Values.add(Integer.parseInt(temp[4]));
					MACAddressMap.put(temp[3], RSS_Values);
					RadioMap.put(key, MACAddressMap);
					continue;
				}

				/*
				 * Get the RSS Values of MAC address
				 */
				RSS_Values = MACAddressMap.get(temp[3]);

				/*
				 * MAC Address first read so far
				 */
				if (RSS_Values == null) {
					RSS_Values = new ArrayList<Integer>();
					RSS_Values.add(Integer.parseInt(temp[4]));
					MACAddressMap.put(temp[3], RSS_Values);
					continue;
				}

				/*
				 * MAC Address already exists. Just insert to array list the new
				 * RSS value
				 */
				RSS_Values.add(Integer.parseInt(temp[4]));
			}

			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error occured");
		}
	}

}
