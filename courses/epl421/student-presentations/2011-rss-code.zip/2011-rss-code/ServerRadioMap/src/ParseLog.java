import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ParseLog {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HashMap<String, HashMap<String, ArrayList<Integer>>> RadioMap = new HashMap<String, HashMap<String, ArrayList<Integer>>>();

		File inFile = new File("rss-log.txt");

		BufferedReader reader = null;
		if (!inFile.exists()) {
			System.out.println("File not found");
			return;
		} else if (!inFile.canRead()) {
			System.out.println("File not readable");
			return;
		}

		HashMap<String, ArrayList<Integer>> MACAddressMap;
		ArrayList<Integer> RSS_Values;
		String key = "";
		try {

			String line;
			reader = new BufferedReader(new FileReader(inFile));
			while ((line = reader.readLine()) != null) {
				if (line.startsWith("#"))
					continue;

				line = line.replace(", ", " ");
				String[] temp = line.split(" ");
				if (temp.length != 5)
					break;

				key = temp[1] + " " + temp[2];

				/**
				 * Get the current geolocation value
				 * */
				MACAddressMap = RadioMap.get(key);

				/**
				 * Geolocation first read so far
				 * */
				if (MACAddressMap == null) {
					MACAddressMap = new HashMap<String, ArrayList<Integer>>();
					RSS_Values = new ArrayList<Integer>();
					RSS_Values.add(Integer.parseInt(temp[4]));
					MACAddressMap.put(temp[3], RSS_Values);
					RadioMap.put(key, MACAddressMap);
					continue;
				}

				/**
				 * Get the RSS Values of MAC address
				 * */
				RSS_Values = MACAddressMap.get(temp[3]);

				/**
				 * MAC Address first read so far
				 * */
				if (RSS_Values == null) {
					RSS_Values = new ArrayList<Integer>();
					RSS_Values.add(Integer.parseInt(temp[4]));
					MACAddressMap.put(temp[3], RSS_Values);
					continue;
				}

				/**
				 * MAC Address already exists. Just insert to array list the new
				 * RSS value
				 * */
				RSS_Values.add(Integer.parseInt(temp[4]));
			}

			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error occured");
		}

		/* Store all unique MAC addresses */
		HashSet<String> s = new HashSet<String>();
		for (String Geolocation : RadioMap.keySet()) {
			MACAddressMap = RadioMap.get(Geolocation);
			s.addAll(MACAddressMap.keySet());
		}

		/* Start the print out to Radio Map file */
		System.out.print("# Longitude, Latitude");
		Iterator<String> iterator = s.iterator();
		while (iterator.hasNext()) {
			System.out.print(", " + iterator.next());
		}
		System.out.println();

		/* For each Geolocation print the Average RSS
		 * of every single MAC Address */
		iterator = s.iterator();
		String MacAddress;

		for (String Geolocation : RadioMap.keySet()) {
			System.out.print(Geolocation.replace(" ", ", "));

			MACAddressMap = RadioMap.get(Geolocation);
			
			iterator = s.iterator();
			
			/* For every MAC Address print average RSS value,
			 * or -110 if does not exist */
			while (iterator.hasNext()) {

				MacAddress = iterator.next();

				RSS_Values = MACAddressMap.get(MacAddress);

				if (RSS_Values == null)
					System.out.print(", -110");
				else {
					float rss_sum = (float) 0.0;
					float rss_avg = (float) 0.0;
					for (int i = 0; i < RSS_Values.size(); ++i)
						rss_sum += RSS_Values.get(i);
					rss_avg = rss_sum / RSS_Values.size();
					System.out.printf(", %.1f", rss_avg);
				}
			}
			System.out.println();
		}
	}
}
