import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class RadioMapProtocol {

	private static final int WAITING = 0;
	private static final int SENTREADYMSG = 1;
	private static final int SENDINGRADIOMAP = 2;
	private static final int DONE = 3;

	private String line = null;
	private int state = WAITING;
	File inFile = null;
	BufferedReader reader = null;
	private String[] answers = { "+OK READY", "RADIOMAP" };

	public RadioMapProtocol(String filename) {
		super();
		inFile = new File(filename);
	}

	public String processInput(String theInput) {
		String theOutput = null;

		if (state == WAITING) {
			theOutput = answers[0];
			state = SENTREADYMSG;
		} else if (state == SENTREADYMSG) {
			if (theInput.equalsIgnoreCase("GET radiomap")) {
				theOutput = answers[1];
				state = SENDINGRADIOMAP;
				try {
					reader = new BufferedReader(new FileReader(inFile));
					line = reader.readLine();
					if (line == null) {
						reader.close();
						state = DONE;
						theOutput = null;
					} else
						theOutput += " " + line;
				} catch (Exception fnf) {
					theOutput = "UNAVAILABLE: Radio Map is currently unavailable.\n"
							+ "Please try later.";
					state = DONE;
				}
			} else {
				theOutput = "ERROR: Retrieving radiomap requires \"GET radiomap\" command! "
						+ "Try again.\n+OK READY";
			}
		} else if (state == SENDINGRADIOMAP) {
			String line;
			try {
				if ((line = reader.readLine()) != null) {
					theOutput = line;
				} else {
					theOutput = null;
					state = DONE;
					reader.close();
				}
			} catch (Exception e) {
				theOutput = "CORRUPTED: Corrupted file.\n"
						+ "Please try later.";
				state = DONE;
			}
		} else if (state == DONE) {
			theOutput = null;
		}
		return theOutput;
	}
}
