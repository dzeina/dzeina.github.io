Genikes odigies:

1) To ClientPositioning einai Google API 8 kai 1.6 JRE.
2) Sto manifest.xml tou ClientPositioning isws na xreiazetai allo Google API key. An ginei egkatastasi tou .apk kai den emfanizontai oi xartes parolo pou einai anikta ta WiFi tote isws auto na ftaiei.
3) Ston RadioMapServer dinetai to "Directory" pou periexei ola ta RSS logs opws auta exoun apothikeutei apo tis siskeves me to RSS Logger.
4) H kiniti siskevi gia na apothikeusei dedomena xreiazetai anagkastika external memory, diaforetika tipwnetai error popup message. (auto isxiei kai gia ta 2 .apk)

Gia peretairw provlimata, veltiwseis, anixneusi bugs enimerwste mas.

More info: 
gconst02@cs.ucy.ac.cy
mconst02@cs.ucy.ac.cy
snicol02@cs.ucy.ac.cy

