***********************************************************     
*                           PROJECT                       *
*                         D LANGUAGE                      *
***********************************************************

-----------------------------------------------------------

Team members:
        1) Despoiana Antoniou       (975654)
	2) Yiannis Constantinou     (994464)
        3) Nicolas Hadjitheophanous (986792)

-----------------------------------------------------------

Arxeia:
  - json.d
  - mashup.d

-----------------------------------------------------------
**********
  Json.d 
**********

To sigkekrimeno arxeio an ektelesoume tin entoli 
dmd -run json.d 
tha anoiksei to latest.json pou iparxei idi kai tha dimiourgisei 
ena folder LATEST_MSGS opou mesa tha exei ta .txt arxeia tou
tweeter pou to kathena tha periexei 3 grammes me ta stoixeia 
pou xreiazomaste gia tin ilopoiisi tis askisis
text:
ceated at:
retweet:

-----------------------------------------------------------
************
  mashup.d
************

Distixws epeidi den kataferame na spasoume teleiws swsta ta json mas 
gia to tweeter kai to rays frontisame na ilopoiisoume tin askisi mas 
me ta arxeia pou eixame dimiourgisei otan tin treksame se bash kwdika
Etsi mesa sto kwdika mas iparxoun idi 2 folders latest_msgs kai geo_msgs 
kai mesa iparxoun .txt arxeia gia ta tweeter kai rays msgs pou tha 
xrisimopoiisoume gia tin epilisi twn erwtimatwn mas. Etsi simantiko 
einai autoi oi 2 folders na min svistoun pote. 


1o erwtima: all-build-lexicon
=============================
Gia na tra3ei to sigkekrimeno erwtima ekteloume 
dmd -run mashup.d all build lexicon 
kai dimiourgeite ena arxeio lexicon.txt pou mesa exei taksinomimenes 
tis le3eis me f8inousa seira mazi me tous counters tous. 


2o erwtima: geo-oldest
======================
Gia na tra3ei to sigkekrimeno erwtima ekteloume 
dmd -run mashup.d geo-oldest 
kai emfanizetai stin o8oni mas to teleftaio rays kai to teleftaio tweet 
apo ton geo_msgs folder.


3o erwtima: latest-oldest
======================
Gia na tra3ei to sigkekrimeno erwtima ekteloume
dmd -run mashup.d latest-oldest 
kai emfanizetai stin o8oni mas to teleftaio rays kai to teleftaio tweet 
apo ton latest_msgs folder.


4o erwtima: geo-sort
======================
Gia na tra3ei to sigkekrimeno erwtima ekteloume
dmd -run mashup.d geo-sort 
kai emfanizontai stin o8oni mas apo to pio palio mexri kai to pio prosfato 
rays kai apo to pio palio mexri kai to pio prosfato tweet apo ton geo_msgs folder.


5o erwtima: latest-sort
======================
Gia na tra3ei to sigkekrimeno erwtima ekteloume
dmd -run mashup.d latest-sort 
kai emfanizontai stin o8oni mas apo to pio palio mexri kai to pio prosfato 
rays kai apo to pio palio mexri kai to pio prosfato tweet apo ton latest_msgs folder.


6o erwtima: geo-before-date
======================
Gia na tra3ei to sigkekrimeno erwtima ekteloume
dmd -run mashup.d ge-before-date <year> 
kai emfanizontai stin o8oni mas ola ta tweeter msgs pou exoun dimiourgi8ei prin 
apo tin xronologia pou dinei o xristis.