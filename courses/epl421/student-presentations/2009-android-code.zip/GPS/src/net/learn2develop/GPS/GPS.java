package net.learn2develop.GPS;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

public class GPS extends Activity 
{
    private LocationManager lm;
    private LocationListener locationListener;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); 
        //Clean up the temp file from previous measurements
        FileOutputStream fout;
		try {
			fout = openFileOutput("temp.txt",MODE_WORLD_READABLE);
			OutputStreamWriter osw=new OutputStreamWriter(fout);
			osw.write("");
			osw.flush();
			osw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
        //---use the LocationManager class to obtain GPS locations---
        lm = (LocationManager) 
            getSystemService(Context.LOCATION_SERVICE);          
        locationListener = new MyLocationListener();
        lm.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,  0, 0, locationListener);        
    }  
    private class MyLocationListener implements LocationListener 
    {
        public void onLocationChanged(Location loc) {
            if (loc != null) {
                String tempstr=new String(); 
                tempstr="Lat: " + loc.getLatitude() +" Lng: " + loc.getLongitude()+"\n";
                try {
					FileOutputStream fout=openFileOutput("temp.txt",MODE_APPEND);
					OutputStreamWriter osw=new OutputStreamWriter(fout);
					osw.write(tempstr);
					osw.flush();
					osw.close();
					FileInputStream fin=openFileInput("temp.txt");
					InputStreamReader isr=new InputStreamReader(fin);
					char[] temp = new char[1024];
					isr.read(temp);
					String readstr=new String(temp);
					//boolean isthesame= tempstr.equals(readstr);
					Toast.makeText(getBaseContext(), readstr, 50).show();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
            }
        }
        public void onProviderDisabled(String provider) {
        }
        public void onProviderEnabled(String provider) {
        }
        public void onStatusChanged(String provider, int status, 
            Bundle extras) {
        }
    }        
}
