//Names: Andreas Constantinou 1028793

#include "server.h"
#include <pthread.h>



int main(int argc, char *argv[]) // Server with Internet stream sockets
{
	int i;
	if (argc != 3) {
		printf("Server\nUsage: %s  PORT  DIRECTORY \nUse CTRL-C to shutdown server.\n",argv[0]);
		return 1;
	}
	// FIXME Na do an mporo na elegxo an ine valid o fakelos pou dothike apo to server.
	chdir(argv[2]);
	directory = (char *) malloc (strlen(argv[2]));
	strcpy(directory, argv[2]);
	pthread_mutex_init(&mutex, 0);
	pthread_cond_init(&cond, 0);
	initThreads();

	// CTRL-C to shutdown_server 
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = shutdown_server;
	sigaction(SIGINT, &sa, 0);
	// TODO Eki pou tha stamataei i litourgia tou server tha ginete to pthread_destroy

	 //Query localhost 
	struct addrinfo hints, *ai;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = PF_UNSPEC; // FIXME Mporo na to vallo kai gia IPv6 kai gia IPv4
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;
	getaddrinfo(0, argv[1], &hints, &ai);

	server = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
	//~ printf("\nserver = %d", server);
	if (bind(server, ai->ai_addr, ai->ai_addrlen) == -1) {
		perror("bind");
		exit(1);
	}

	if (listen(server, BACKLOG) == -1) {
		perror("listen");
		exit(1);
	}
	work=0;
	for(i=0; i<WORKER_LEN; i++){
		pthread_create(&(workers_[i].thread), NULL, serverClients , &(workers_[i]));
		//~ printf("pthread %d created\t",i);
		pthread_detach(workers_[i].thread);
	}
	printf("Listening for connections to port %s\n", argv[1]);

	metritis = find_available_worker();
	while (1) {
		
		// TODO NA mpi elegxos an kseperasame to WORKER_LEN
		if ((workers_[metritis].sock = accept(server, &(workers_[metritis].addr), &(workers_[metritis].addrlenght)) ) < 0) 
		{
			perror("accept");
			exit(1);
		}
		pthread_mutex_lock( &mutex );
		workers_[metritis].isBusy = 1;
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
		
		metritis = find_available_worker();
	}
	return 0;
}


