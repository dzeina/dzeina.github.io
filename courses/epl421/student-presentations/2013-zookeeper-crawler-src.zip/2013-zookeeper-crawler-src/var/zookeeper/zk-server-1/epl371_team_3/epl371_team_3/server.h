//Names: Andreas Constantinou 1028793

#ifndef ___SERVER_H
#define ___SERVER_H

/* Libraries */
#include <sys/types.h>	// For sockets
#include <sys/socket.h>	// For sockets
#include <netinet/in.h>	// For Internet sockets
#include <netdb.h>		// For gethostbyaddr
#include <stdio.h>			// For I/O
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <ctype.h>
#include <pthread.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <libgen.h>
#include <pthread.h>
#include <dirent.h>

#define LINE_MAX 1000

#define WORKER_LEN 5
#define BACKLOG 10

#define ERROR -1

#define AUTHORIZATION 1
#define TRANSACTION 2
#define UPDATE 3

#define AUTH_QUIT 10
#define AUTH_USER 11
#define AUTH_PASS 12

#define TRAN_STAT 20
#define TRAN_LIST 21
#define TRAN_LIST_1 22
#define TRAN_RETR 23
#define TRAN_DELE 24
#define TRAN_QUIT 25

#define USER_STR "USER"
#define PASS_STR "PASS"
#define QUIT_STR "QUIT"

#define STAT_STR "STAT"
#define LIST_STR "LIST"
#define RETR_STR "RETR"
#define DELE_STR "DELE"

/* Struct of thread */
typedef struct threadS{
	int sock;
	struct sockaddr addr;
	socklen_t addrlenght;
	pthread_t thread;
	int isBusy;
}ThreadS;

/* Struct of message */
typedef struct messageS{
	char name[10];
	int num;
	int deleded;
	long long BytesSize;
	struct messageS *next; 
}MessageS;

/* Struct of list */
typedef struct listS{
	struct messageS *head;
	long long BytesSize;
	long long TotalBytesSize;
	int count;
	int countTotal;	
}ListS;

/* Global variables */
ThreadS workers_[WORKER_LEN]; 
int work;
pthread_mutex_t mutex ;
pthread_cond_t cond ;
int server; 
int metritis;
int State;
char *directory;


/* Orismoi sinartisewn */
ListS *ListCreate(int count);

void ListInsert (ListS *l, long long BytesSize, char *name);

void ListSort (ListS *l);

MessageS * ListGetMessage(ListS *l , int pos);

void ListMessageDelete(ListS *l, int pos);

int ListForceMessagesDelete(ListS *l);

void ListDelete(ListS *l);

int isNumeric (const char * s);

void initThreads(); // Arxikopoiisi twn theads pou apoteloun to threadpool.

void recieve_line(int sock, char *header); // Paralavi mias grammis(header) apo ton client.

ssize_t send_line(int sock, const char* str); // Apostoli apantiseis me to header ston client.

int find_available_worker(); // Vriskoume ena diathesimo thread pou tha eksipiretisei kapoio neo client.

void close_connection(int sock); // Klini tin sindesi me ton client pou akoui socket sock.

int busy_workers(); // Epistrefei posa threads ergates ine apasxolimenoi me kapio client.

void shutdown_server(); // Termatizei tin litourgia tou server.

int check_header(char *header); // Elegxos tou header pou edose o client a ine sosto.

void find_mimetype(char *file, char *mimetype); // Briskoume to mimetype tou arxiou.

char *strrev(char *str);

void *serverClients(void *arg); // I sinartisi pou eksipireti mia etisi tou client.

#endif
