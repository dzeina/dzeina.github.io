//Names: Andreas Constantinou 1028793

#include "server.h"
#include <pthread.h>
#include <string.h>

//TODO Na perno ta orismata apo tin etisi tou client kai na ta vallo se metavlites


ListS *ListCreate(int count)
{
	ListS *list1 = (ListS*) malloc(sizeof(ListS));
	if (list1==NULL)
	{
		perror("malloc");
		exit(1);
	}
	list1->head=NULL;
	list1->BytesSize=0;
	list1->TotalBytesSize=0;
	list1->countTotal=count;
	list1->count=count;
	return list1;
}

void ListInsert (ListS *l, long long BytesSize, char *name )
{
	int i=0;
	MessageS *node = (MessageS*) malloc(sizeof(MessageS));
	MessageS *head1,*t,*p;
	if (node==NULL)
	{
		perror("malloc");
		exit(1);
	}
	if(l->head==NULL)
	{
		
		l->count=l->count +1;
		l->countTotal=l->countTotal +1;
		l->BytesSize= l->BytesSize + BytesSize;
		l->TotalBytesSize= l->TotalBytesSize + BytesSize;
		l->head=node;
		strcpy(node->name, name);
		node->num=l->count;
		node->deleded=0;
		node->BytesSize=BytesSize;
		node->next=NULL;
		return;
	}
	node->next=NULL;
	head1=l->head;
	for(t=l->head,p=t,i=1;t!=NULL;i++,t=t->next)
	{
		p=t;
	}
	l->count=l->count +1;
	l->countTotal=l->countTotal +1;
	l->BytesSize= l->BytesSize + BytesSize;
	l->TotalBytesSize= l->TotalBytesSize + BytesSize;
	strcpy(node->name, name);
	node->num=l->count;
	node->deleded=0;
	node->BytesSize=BytesSize;
	p->next=node;
	node->next=t;
	return;
}

void ListSort (ListS *l)
{
	int tempNum, numNow, numNext;
	long long tempBytesSize;
	char tempName[10];
	MessageS  *now,*next;
	if(l->head!=NULL)
		now=l->head;
	else 
		now=NULL;
	if (now)
	{
		if (now->next != NULL)
			next=now->next;
		else
			next=NULL;
	}
	while(now)
	{
		while(next)
		{
			numNow = atoi(now->name);
			numNext = atoi(next->name);
			if( numNow > numNext )
			{
				//~ now->num = numNext;
				//~ next->num = numNow;
				
				tempBytesSize = now->BytesSize;
				now->BytesSize = next->BytesSize;
				next->BytesSize = tempBytesSize;
				
				strcpy(tempName, now->name);
				strcpy(now->name, next->name);
				strcpy(next->name, tempName);
			}
			next = next->next;
		}
		now = now->next;
		if(now)
			next=now->next;
	}
	
}

MessageS * ListGetMessage(ListS *l , int pos)
{
	//~ Get the pos undeleded message!
	MessageS *head1;
	head1=l->head;
	int i=1;
	while(head1)
	{
		if(i==pos)
			return head1;
		if( (head1->deleded)==0)
			i++;
		head1=head1->next;
	}
	return(head1);
}

void ListMessageDelete(ListS *l, int pos)
{
	int i=1;
	MessageS *head1, *head1temp1, *head1temp2;
	head1=l->head;
	while(head1)
	{
		if(i==pos)
		{
			l->count=l->count -1;
			//~ TODO : Na kano akoma mia sinartisi i opia tha svinei aferei to countTotal otan tha ginete QUIT
			head1temp2=head1->next;
			free(head1);
			head1=head1temp1;
			head1->next=head1temp2;
			return;
		}
		head1temp1=head1;
		head1=head1->next;
		i++;
	}
	printf("\nNot exist this message!"); 
	
}

int ListForceMessagesDelete(ListS *l)
{
	//~ TODO : edo tha diagrafonte ola ta minimata pou ine deleded kai tha anaprosarmozete o arithmos tou kathe minimatos kathos
	//~ kai to onoma tou kathe arxiou mesa ston katalogo! Ara tha dexete parametro i sinartisi afti me to onoma tou katalogou.
	MessageS *head1, *head1temp1, *head1temp2;
	head1 = l->head;
	int i, success;
	success=1;
	while(head1)
	{
		if( head1->deleded == 1 )
		{
			i = remove(head1->name);
			if( !(i) )
			{
				l->count=l->count -1;
				l->countTotal=l->countTotal -1;
				head1temp2=head1->next;
				free(head1);
				
				if( head1 == l->head )
				{
					head1= head1temp2;
				}
				else
				{
					head1=head1temp1;
					head1->next=head1temp2;
				}
			}
			else if ( success )
			{
				success = 0;
			}
		}
		head1temp1=head1;
		head1=head1->next;
	}
	i=1;
	head1 = l->head;
	while(head1)
	{
		head1->num = i;
		i++;
		head1 = head1->next;
	}
	return success;
}
void ListDelete(ListS *l)
{
	MessageS *to_free_node;
	while(l->head!=NULL)
	{
		to_free_node=l->head;
		l->head= to_free_node->next;
		free(to_free_node);
	}
	free(l);
}

//~ Returns true (non-zero) if character-string parameter represents a signed or unsigned floating-point number. 
//~ Otherwise returns false (zero).
int isNumeric (const char * s)
{
    if (s == NULL || *s == '\0' || isspace(*s))
      return 0;
    char * p;
    strtod (s, &p);
    return *p == '\0';
}

void initThreads()
{
	int i=0;
	for(i=0; i<WORKER_LEN; i++){
		workers_[i].isBusy = 0;
	}
}

void recieve_line(int sock, char *header) 
{
	char c;
	char buf[1024]={"\0"};
	//~ char *buf;
	char *return_string;
	int len;
	int i;
	//~ bzero(buf, sizeof(buf));
	if (len = recv(sock, buf, sizeof buf ,0) < 1) {
		printf("\nerror recv\n"); 
		perror("recv wrong line"); 
		return ;
	}

	strcpy(header, buf);
	header[strlen(header) - 2] ='\0';
	//~ printf("\nheaderEW: %s %d", header, (int)strlen(header)); // ToDelete
}

 //~ Sends a string through a TCP socket
ssize_t send_line(int sock, const char* str)
 {
	size_t len = strlen(str);
	return send(sock, str, len,0);
}

int find_available_worker()
{
	int i;
	for(i = 0; i<WORKER_LEN; i++){
		if (workers_[i].isBusy == 0){
			workers_[i].isBusy == 1;
			return i;
		}
	}
	return -1; // den iparxoun available workers. Tha ginete drop to request
}

void close_connection(int sock)
{
	int i;
	pthread_mutex_lock(&mutex);
	for(i = 0; i<WORKER_LEN; i++)
		if (workers_[i].sock == sock)
			break;
	if(i==WORKER_LEN) 
		return;
	shutdown(workers_[i].sock, SHUT_RDWR);
	close(workers_[i].sock);
	workers_[i].isBusy = 0;
	pthread_mutex_unlock(&mutex);
}

int busy_workers()
{
	int i=0, count=0;
	for(i=0; i<WORKER_LEN; i++){
		if(workers_[i].isBusy == 1) {count++;}
	}
	return count;
}

// Closes all client sockets and threads and exits
void shutdown_server()
{
	size_t i;
	int count;
	count = busy_workers();
	pthread_mutex_lock(&mutex);
	printf("Shutting down  %d connections...\n", count);
	for (i = 0; i < WORKER_LEN; i++) {
		if(workers_[i].isBusy == 1){
			shutdown(workers_[i].sock, SHUT_RDWR);
			close(workers_[i].sock);
			pthread_cancel(workers_[i].thread);
		}
	}
	pthread_mutex_unlock(&mutex);
	pthread_mutex_destroy(&mutex);
	shutdown(server, SHUT_RDWR);
	close(server);
	exit(0);
}

int check_header(char *header)
{
	
	if (State==AUTHORIZATION)
	{
		char *pch1, *pch2, *pch3;
		pch1 = strtok (header, " ");
		pch3 = strtok (NULL, " ");
		if (pch3==NULL)
		{
			if ( (strcmp(header,QUIT_STR)==0) )
			{		
				return AUTH_QUIT;
			}
			else
			{

				return ERROR;
			}
		}
		else
		{
			
			pch2 = strtok (NULL, " ");
			if (pch2!=NULL)
			{
				return ERROR;
			}
			else
			{
				if ((strcmp(pch1,USER_STR)==0))
				{
					return AUTH_USER;
				}
				else if ((strcmp(pch1,PASS_STR)==0))
				{
					return AUTH_PASS;
				}
				else
				{
					return ERROR;
				}
			}
		}

	}
	else if (State==TRANSACTION)
	{
		char *pch1, *pch2, *pch3;
		pch1 = strtok (header, " ");
		pch3 = strtok (NULL, " ");
		if (pch3==NULL)
		{
			if ( (strcmp(header,STAT_STR)==0) )
			{		
				return TRAN_STAT;
			}
			else if ( (strcmp(header,LIST_STR)==0) )
			{
				return TRAN_LIST;
			}
			else if ( (strcmp(header,QUIT_STR)==0) )
			{
				return TRAN_QUIT;
			}
			else
			{
				return ERROR;
			}
		}
		else
		{
			
			pch2 = strtok (NULL, " ");
			if (pch2!=NULL)
			{
				return ERROR;
			}
			else if ( (strcmp(pch1, LIST_STR)==0))
			{
				if ( (isNumeric(pch3)==0) )
				{
					return ERROR;
				}
				else 
				{
					return TRAN_LIST_1;
				}
			}
			else if ( (strcmp(pch1, RETR_STR)==0))
			{
				if ( (isNumeric(pch3)==0) )
				{
					return ERROR;
				}
				else 
				{
					return TRAN_RETR;
				}
			}
			else if ( (strcmp(pch1, DELE_STR)==0))
			{
				if ( (isNumeric(pch3)==0) )
				{
					return ERROR;
				}
				else 
				{
					return TRAN_DELE;
				}
			}
		}
	}
	else if (State==UPDATE)
	{
		
	}
	return 0;
}

void find_mimetype(char *file, char *mimetype)
{
	char t_file[256]= {'\0'};
	strcpy(t_file, file);
	strrev(t_file);
	int i=0;
	char type[15]={'\0'};
	while(t_file[i] != '.'){
		type[i] = t_file[i];
		i++;
	}
	type[i]='\0';

	if((strcmp(type,"txt") == 0) || (strcmp(type,"des") == 0) || (strcmp(type,"kwa") == 0) || (strcmp(type,"c") == 0) || (strcmp(type, "h") == 0)) 
		strcpy(mimetype, "text/plain");
	else if((strcmp(type,"lmth") == 0) || (strcmp(type,"mth") == 0))
		strcpy(mimetype, "text/html");
	else if((strcmp(type,"gepj") == 0) || (strcmp(type,"gpj") == 0))
		strcpy(mimetype, "image/jpeg");
	else if((strcmp(type,"fig") == 0) )
		strcpy(mimetype, "image/gif");
	else if((strcmp(type,"fdp") == 0) )
		strcpy(mimetype, "application/pdf");
	else
		strcpy(mimetype, "application/octet-stream");
}

char *strrev(char *str)
{
	char *p1, *p2;
	if (! str || ! *str)
		return str;
	for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
	{
		*p1 ^= *p2;
		*p2 ^= *p1;
		*p1 ^= *p2;
	}
	return str;
}

void *serverClients(void *arg)
{
	
	char *temp_header, *header;
	ThreadS *w_x = (ThreadS*)arg;
	int FlagAuthorizationUsername=1;
	int FlagAuthorizationPassword=1;
	int c_header;
	int FirstLoopIteration=1;
	
	ListS *List;
	List = ListCreate(0);
	
	//~ TODO : Isos edo prepi na allazo katalogo me to username tou xristi i isos i lista na ginete pio kato pou tha ksero to username
	DIR * dirp;
	struct dirent * entry;
	struct stat statbuf;
	dirp = opendir(directory); /* There should be error handling after this */
	while ((entry = readdir(dirp)) != NULL) 
	{
		lstat(entry->d_name,&statbuf);
		if (S_ISREG(statbuf.st_mode)) /* If the entry is a regular file */
		{ 
			//~ printf("\nfile %s, %d", entry->d_name, List->count);
			
			ListInsert(List, (long long) statbuf.st_size, entry->d_name);
		}
	}
	closedir(dirp);
	
	ListSort(List);
	
	while(1)
	{
		pthread_mutex_lock( &(mutex) );
		while(!(w_x->isBusy))//oso DEN einai busy
			pthread_cond_wait(&cond, &(mutex));
		pthread_mutex_unlock( &(mutex) );
		
		//~ TODO: Na svistoun oi axristes metavlites kai na vgoun ekso oses prepi apo aftes!
		//~ TODO: Na do ti ginete kai dn perno to sosto arithmo minimatwn sto mailbox
		int sock_ = w_x->sock,flag_connect, flag_invalid_input, i, j, k, first_space, second_space,hd = 1;
		char response[512], ip[64], file[256]= {'\0'}, t_file[256]= {'\0'}, connection_[20], mimetype[64]= {'\0'},url[256]={'\0'};
		char str_1[100]= {'\0'}, str_2[100]= {'\0'}, str_3[100]= {'\0'};
		//~ char name[20];
		char *name;
		char *password;
		size_t found;
		struct stat st;
		
		//~ TODO : Opou exi apantisi sto client na prostheso sto responce "C:"

		/* Message: READY
		 * Egkathidrithike to TCP connection me ton petati kai tha tou
		 * stiloume to minima: "S: + OK POP3 server ready".
		 * 
		 * */
		if (FirstLoopIteration==1)
		{
			sprintf(response,"\nS: +OK POP3 server ready\n");
			send_line(sock_,  response);
			FirstLoopIteration = 0;
		}
		
		header = (char*)malloc(1024); // Maximum size of header 512 characters
		if(header==NULL) { 
			perror("malloc"); 
			exit(1);
		}
		// TODO Na ginoun oles oi arxikopoioisois
		flag_invalid_input = 0;
		flag_connect = 1;
		
		/* ----------------STATE OF AUTHORIZATION-----------
			 * Edo ine i katastasi tou AUTHORIZATION. Stin katastasi afti tha dothi to 
			 * username(USER) kai to password(PASS) apo ton Client. Diladi o Server 
			 * perimeni tis entole:	
			 * 	(1) USER name : username
			 * 	(2) PASS string : password
			 * 	(3) QUIT :	Μετά την εκτέλεση της εντολής QUIT ο εξυπηρετητής 
			 * 					απελευθερώνει τη πρόσβαση πάνω στο mailbox του πελάτη
			 * 					και κλείνει τη σύνδεση TCP.
			 * 
			 * */
		if (FlagAuthorizationUsername==1 || FlagAuthorizationPassword==1)
		{
			State = AUTHORIZATION;	
			/* Recieve Input from Client
			 * Edo o Server ine etimos na diavasei ti tha tou grapsei o Client 		 
			 * 
			 * */
			recieve_line(sock_,header);
			
			/* Check the Input of Client
			 * Elegxete to Input tou Client kai an den ine valid
			 * aporriptete kai stelnoume apantisei piso ston Client
			 * na dosei ksana Input 
			 * 
			 * */
			
			temp_header = (char*)malloc(strlen(header)*(sizeof(char)));
			if(temp_header==NULL) 
			{ 
				perror("malloc"); 
				exit(1);
			}
			strcpy(temp_header,header);
			c_header = check_header(temp_header);
			if (FlagAuthorizationUsername==1 && FlagAuthorizationPassword==1 && c_header==AUTH_USER)
			{
				char * pch;
				int i1;
				i1= strcspn (header," ");
				int K= (strlen(header) ) - (i1);
				name=(char*) malloc(K);
				pch=header+i1;
				strncpy(name, pch, K);
				
				//~ TODO: Edo prepi na ginei elegxos an ine valid to username
				sprintf(response,"\nS: +OK %s is a valid mailbox\n", name); 
				send_line(sock_, response);
				FlagAuthorizationUsername=0;
			}
			else if (FlagAuthorizationUsername==1 && FlagAuthorizationPassword==1 && c_header==AUTH_PASS)
			{
				//~ ERROR : Send error message to Client.
				sprintf(response,"\nS: -ERR\n"); 
				send_line(sock_, response);
			}
			else if (FlagAuthorizationUsername==0 && FlagAuthorizationPassword==1 && c_header==AUTH_PASS)
			{
				char * pch;
				int i1;
				i1= strcspn (header," ");
				int K= (strlen(header) ) - (i1);
				password=(char*) malloc(K);
				pch=header+i1;
				strncpy(password, pch, K);
				
				//~ TODO: Edo prepi na ginei elegxos an ine sosto to password
				sprintf(response,"\nS: +OK maildrop locked and ready\n"); 
				send_line(sock_, response);
				FlagAuthorizationPassword=0;
				State = TRANSACTION;
			}
			else if (FlagAuthorizationUsername==0 && FlagAuthorizationPassword==1 && c_header==AUTH_USER)
			{
				//~ ERROR : Send error message to Client.
				sprintf(response,"\nS: -ERR\n"); 
				send_line(sock_, response);
			}
			else if (c_header==AUTH_QUIT)
			{
				sprintf(response,"\nS: +OK user POP3 server signing off\n");
				send_line(sock_,  response);
				close_connection(sock_);
				w_x->isBusy = 0; // Kimizoume to thread
				FlagAuthorizationUsername = 1;
				FlagAuthorizationPassword = 1;
				FirstLoopIteration = 1;
			}
			else if (c_header==ERROR)
			{
				sprintf(response,"\nS: -ERR\n"); 
				send_line(sock_, response);
			}
			
			//~ TODO: Edo prepi na valo ena xronometro gia na metro ton xrono apo tin stigmi pou egine login
			 //~ Na to kano me tin sinartisi alarm mallon 
		}
		
		/* ----------------STATE OF TRANSACTION-----------
		 * Edo ine i katastasi tou TRANSACTION. Stin katastasi afti mporei na 
		 * 	dothi :
		 * 	
		 * 	(1) STAT : Ο εξυπηρετητής στέλνει θετικό δείκτη κατάστασης +OK μαζί με κάποιες
		 *  					 πληροφορίες για το mailbox. Πιο συγκεκριμένα το +ΟΚ ακολουθείται από 
		 * 					 ένα ακριβώς κενό, ακολουθεί ο αριθμός των μηνυμάτων μέσα στο mailbox, 
		 * 					 ακόμα ένα κενό και το μέγεθος του mailbox σε bytes. Τα μηνύματα που 
		 * 					 χαρακτηρίζονται ως deleted (βλέπε παρακάτω εντολή DELE) δεν προσμετρώνται.
		 * 	(2) LIST [msg] : Εάν δοθεί ο αριθμός μηνύματος, ο εξυπηρετητής στέλνει μια γραμμή 
		 * 							 που περιέχει το δείκτη θετικής κατάστασης +ΟΚ ακολουθούμενο από 
		 * 							 ένα κένο, τον αριθμό του μηνύματος, ακόμα ένα κενό και το μέγεθος 
		 * 							 του μηνύματος σε bytes. Η γραμμή αυτή ονομάζεται scan listing για το 
		 * 							 μήνυμα αυτό. Αν δεν δίνεται κανένα όρισμα, ο εξυπηρετητής στέλνει μια 
		 * 							 θετική απόκριση πολλαπλών γραμμών. Μετά το αρχικό +OK, για κάθε 
		 * 							 μήνυμα μέσα στο mailbox, στέλνεται ξεχωριστή γραμμή που περιέχει αριθμό 
		 * 							 του μηνύματος, ένα κενό και το μέγεθος του μηνύματος σε bytes. Αν δεν 
		 * 							 υπάρχουν μηνύματα μέσα στο mailbox, ο εξυπηρετητής απαντά με το +ΟΚ μόνο. 
		 * 							 Τα μηνύματα που χαρακτηρίζονται ως deleted δεν προσμετρώνται.
		 * 	(3) RETR msg : Εάν ο εξυπηρετητής απαντήσει θετικά, τότε επιστρέφεται απάντηση πολλαπλών 
		 * 							γραμμών. Μετά το αρχικό +OK, στέλνεται το μήνυμα που αντιστοιχεί στον 
		 * 							δοσμένο αριθμό μηνύματος, προσέχοντας να κάνετε byte-stuff το χαρακτήρα τερματισμού.
		 * 	(4) DELE msg : Ο εξυπηρετητής σημειώνει το μήνυμα σαν deleted. Κάθε μελλοντική αναφορά 
		 * 							(κάποιας POP3 εντολής) στον αριθμό που σχετίζεται με κάποιο μήνυμα που 
		 * 							χαρακτηρίζεται ως deleted θα επιστρέφει λάθος. Στην πργματικότητα ο 
		 * 							εξυπηρετητής δεν διαγράφει το μήνυμα μέχρι η σύνοδος να φτάσει στην κατάσταση UPDATE.
		 * 	(5) QUIT : 
		 * 
		 * */
		else if (State==TRANSACTION)
		{
			//~ Dimiourgia Listas me komvous. Kathe komvos tha exi 3 metavlites(num[int], deleded[boolean], *next )
			recieve_line(sock_,header);
			temp_header = (char*)malloc(strlen(header)*(sizeof(char)));
			if(temp_header==NULL) 
			{ 
				perror("malloc"); 
				exit(1);
			}
			strcpy(temp_header,header);
			c_header = check_header(temp_header);
			
			if (c_header==TRAN_STAT)
			{
				sprintf(response,"\nS: +OK %d %lld\n", List->count, List->BytesSize ); 
				send_line(sock_, response);	
			}
			else if (c_header==TRAN_LIST)
			{
				if ( List->count>1 )
				{
					sprintf(response,"\nS: +OK %d messages (%lld octets)\n", List->count, List->BytesSize );
					send_line(sock_, response);
					MessageS *m;
					int c;
					for(c=1; c<=List->count; c++)
					{
						m = ListGetMessage(List, c);
						sprintf(response,"\nS: %d %lld\n", c, m->BytesSize );
						send_line(sock_, response);
					}	
				} 
				else if ( (List->count)==1 )
				{
					sprintf(response,"\nS: +OK %d message (%lld octets)\n", List->count, List->BytesSize );
					send_line(sock_, response);
					MessageS *m;
					m = ListGetMessage(List, 1);
					sprintf(response,"\nS: %d %lld\n", 1, m->BytesSize );
					send_line(sock_, response);
				}
				else
				{
					sprintf(response,"\nS: +OK\n");
					send_line(sock_, response);	
				}
				
				
			}
			else if (c_header==TRAN_LIST_1)
			{
				char *pch1;
				MessageS *m;
				pch1=strtok(header, " ");
				pch1=strtok(NULL, " ");
				int MessageNum;
				MessageNum= atoi(pch1);
				m = ListGetMessage(List, MessageNum);
				if (m && (m->deleded==0))
				{
					sprintf(response,"\nS: +OK %d %lld\n", MessageNum, m->BytesSize);
					send_line(sock_, response);
				}
				else
				{
					sprintf(response,"\nS: -ERR no such message, only %d messages in mailbox\n",List->count);
					send_line(sock_, response);
				} 
			}
			else if (c_header==TRAN_RETR)
			{
				char *pch1;
				MessageS *m;
				FILE* p;
				char inp[10];
				//~ TODO: Na do pos tha perno olokliri tin grammi. 
				char line[LINE_MAX];
				int MessageNum;
				
				pch1=strtok(header, " ");
				pch1=strtok(NULL, " ");
				MessageNum= atoi(pch1);
				m = ListGetMessage(List, MessageNum);
				if (m && (m->deleded==0) )
				{
					sprintf(response,"\nS: +OK %lld octets\n",  m->BytesSize);
					send_line(sock_, response);
					
					printf("\ncheck %s\n", m->name);
					strcpy(inp,m->name);
					p=fopen(inp,"r"); 
					if ( p == NULL ) 
					{
						perror( "fopen" );
						exit(1);
					}
					sprintf(response,"\nS: ");
					send_line(sock_, response);
					while (( fgets ( line, sizeof line, p) != NULL ) )
					{
							sprintf(response,"%s\n",  line);
							send_line(sock_, response);
					}
					sprintf(response,"\nS: .\n");
					send_line(sock_, response);
				}
				else
				{
					sprintf(response,"\nS: -ERR no such message\n");
					send_line(sock_, response);
				} 
			}
			else if (c_header==TRAN_DELE)
			{
				char *pch1;
				int MessageNum;
				MessageS *m;
				
				pch1=strtok(header, " ");
				pch1=strtok(NULL, " ");
				MessageNum= atoi(pch1);
				m = ListGetMessage(List, MessageNum);
				if ( m )
				{
					m->deleded = 1;
					(List->count)--;
					List->BytesSize = List->BytesSize - m->BytesSize;
					//~ TODO : Edo na allakso oles tis periptoseis pou epireazonte apo tin diagrafi afti
					sprintf(response,"\nS: +OK message %d deleted\n", MessageNum);
					send_line(sock_, response);
				}
				else
				{
					sprintf(response,"\nS: -ERR no such message\n");
					send_line(sock_, response);
				} 
			}
			else if (c_header==TRAN_QUIT)
			{
				State=UPDATE;
			}
			else if (c_header==ERROR)
			{
				sprintf(response,"\nS: -ERR\n"); 
				send_line(sock_, response);
			}
		}
		
		/* ----------------STATE OF UPDATE-----------
		 * Ο εξυπηρετητής διαγράφει από το mailbox όλα τα μηνύματα που έχουν χαρακτηριστεί ως deleted 
		 * και στέλνει ανάλογη απάντηση χρησιμοποιώντας τους δείκτες κατάστασης +OK και -ERR. Σε καμία 
		 * περίπτωση δεν μπορεί ο εξυπηρετητής να διαγράψει μηνύματα που δεν έχουν χαρακτηριστεί ως deleted.
		 * Ανεξαρτήτως η διαγραφή αρχείων υπήρξε επιτυχής ή όχι, ο εξυπηρετητής απελευθερώνει τη πρόσβαση 
		 * πάνω στο mailbox του πελάτη και κλείνει τη σύνδεση TCP. 
		 * */
		else if (State==UPDATE)
		{
			//~ TODO : Na sviso ta deleded kai na kliso tin TCP connection
			int success;
			
			success = ListForceMessagesDelete(List);
			
			if ( success )
			{
				if ( (List->count) == 0 )
				{
					sprintf(response,"\nS: +OK %s POP3 server signing off (mailbox empty)\n", name); 
					send_line(sock_, response);			
				}
				else
				{
					sprintf(response,"\nS: +OK %s POP3 server signing off (%d messages left)\n", name, List->count); 
					send_line(sock_, response);
				}	
			}
			else
			{
				sprintf(response,"\nS: -ERR some deleted messages not removed\n", name); 
				send_line(sock_, response);
			}
			
			close_connection(sock_);
			w_x->isBusy = 0; // Kimizoume to thread
			FlagAuthorizationUsername = 1;
			FlagAuthorizationPassword = 1;
			FirstLoopIteration = 1;
		}
		
		free(header);
		header=NULL;
		free(temp_header);
		temp_header = NULL;
	}// End of While(1)
}
