#!/bin/bash


./var/zookeeper/zk-server-1/bin/zkServer.sh stop
./var/zookeeper/zk-server-2/bin/zkServer.sh stop
./var/zookeeper/zk-server-3/bin/zkServer.sh stop
