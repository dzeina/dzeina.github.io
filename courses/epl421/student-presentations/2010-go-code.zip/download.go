//FILE: download.go

package main

import
(
 os "os"
 fmt "fmt"
 flag "flag"
 net "net"
 bufio "bufio"
 bytes "bytes"
 strings "strings"
 strconv "strconv"
)

// Function: Check the amount of arguments
func checkArguments(){
	flag.Parse()	// Scans the arg list and sets up flags
	if flag.NArg() < 2 {
	  os.Stdout.WriteString("Please enter more arguments!\n")
	  os.Stdout.WriteString("command: ./download [options] popserver username\n")
	  os.Exit(-1)
	}
	if flag.NArg() > 4 {
	  os.Stdout.WriteString("Please enter less arguments!\n")
	  os.Stdout.WriteString("command: ./download [options] popserver username\n")
	  os.Exit(-1)
	}
}

// Function: Connect to server
func connect(para1, para2 string) net.Conn {
	str1:=fmt.Sprintf("%s:110", para1)
	conn, err := net.Dial("tcp", "", str1)
       	if err != nil {
       		os.Stdout.WriteString("Unable to connect to server!\n")
		os.Exit(-1)
       	}
	// Read from connection (server)
	data:=readFromConn(&conn)
	os.Stdout.WriteString(data)

	str2:=fmt.Sprintf("USER %s", para2)
	buff:=createCommand(bytes.NewBufferString(str2).Bytes())
        sendCommand(&conn, buff)
	data=readFromConn(&conn)
	os.Stdout.WriteString(data)
	
	fmt.Printf("Please enter your password: ")
	input, brErr := bufio.NewReader(os.Stdin).ReadString('\n') // Read password
	if brErr != nil {
                fmt.Printf("Read Input failed\n")
        }
	str:=fmt.Sprintf("PASS %s", input)
	fmt.Println(str)
	//stellw to PASS password
	buff=createCommand(bytes.NewBufferString(str).Bytes())
     	sendCommand(&conn, buff)
	data=readFromConn(&conn)
	os.Stdout.WriteString(data)

	return conn
}

// Function: Disconnect from server
func disconnect(c *net.Conn){
	c.Close()
}

func createCommand(data []byte) *bytes.Buffer {
        header := fmt.Sprintf("%s", data);
        buf := bytes.NewBufferString(header);
        buf.WriteString("\r\n");
        return buf;
}

// Function: Read from connection
func readFromConn(c *net.Conn) string{
        r, rErr := bufio.NewReader(*c).ReadString('\n');
        if rErr != nil {
                os.Stdout.WriteString("Unable to read from connection\n");
		os.Exit(-1)
        }
        fmt.Printf("%s -- response\n", r);
	return r
}

// Function: Send Command
func sendCommand(c *net.Conn, b *bytes.Buffer) {
        data := b.Bytes();
        n, err := c.Write(data);
        if err != nil || n != len(data) {
                os.Stdout.WriteString("Unable to write to connection \n");
		os.Exit(-1)
        }
}

// Function: Download emails (default function of command)
func downloadEmails(para1, para2 string) net.Conn{
//	var written int
	// Connect to server
	c:=connect(para1, para2)	
	str:=fmt.Sprintf("/tmp/%s", para2)
	dir, err := os.Stat(str)
 	if err!=nil || err==nil && !dir.IsDirectory(){
		mkdirErr:=os.Mkdir(str,744)
		if mkdirErr != nil {
                  os.Stdout.WriteString("Directory already exists. Continue..\n");
		}
        }
	buff:=createCommand(bytes.NewBufferString("STAT").Bytes())
        sendCommand(&c, buff)
	data:=readFromConn(&c)

	buff=createCommand(bytes.NewBufferString("LIST").Bytes())
        sendCommand(&c, buff)	
	readFromConn(&c)

	var list string
	for strings.LastIndex(list, ".\r\n") == -1 {
		buf := make([]byte, 1000)
 		_, rErr := c.Read(buf);			
		if rErr != nil {
        		os.Stdout.WriteString("Unable to read from connection\n");
			os.Exit(-1)
        	}
        	list += fmt.Sprintf("%s", buf)
	}

	// Calculate total number of emails saved in the server
	dataMod := strings.Fields(data)
	total,_ := strconv.Atoi(dataMod[1])
	
	emptyFlag:=0
	for i:=1; i<=total; i++ {
////////	!!!!!!!!!!!!!!!!!!!!!!!
		fi, err := os.Open(str, os.O_RDONLY, 777)
		if err != nil {
		   os.Stdout.WriteString("Unable to open the emaildir!\n");
		   os.Exit(-1)
		}
	 	names, err := fi.Readdirnames(-1) // Read directory and return
		if len(names)==0{	// If array is empty then copy all the emails
			emptyFlag=1
			break		
		}		
		name,_:=strconv.Atoi(names[i-1])
		
		if i==name{
			fmt.Println("It exists. name=%d\n",i)
		}
////////
	}
	if emptyFlag==1{
		// move all emails
		fmt.Println("empty")
		for i:=1; i<=total; i++ {
		   str:=fmt.Sprintf("RETR %d", i); fmt.Printf("\n%s", str)
		   strF:=fmt.Sprintf("/tmp/%s/%d",para2,i)
		   buff:=createCommand(bytes.NewBufferString(str).Bytes())
        	   sendCommand(&c, buff)
		   readFromConn(&c)
		   

		   newFile, _:=os.Open(strF, os.O_CREAT|os.O_WRONLY|os.O_APPEND, 777)
		   var ema string
		   for strings.LastIndex(ema, "\n.\r\n") == -1 {
	  		buf := make([]byte, 100)
 		 	_, rErr := c.Read(buf);			
		        if rErr != nil {
        		        os.Stdout.WriteString("Unable to read from connection\n");
				os.Exit(-1)
        		}
        		ema += fmt.Sprintf("%s", buf)
		   }

   		subs := strings.Split(ema, ".\r\n", 2) 
	   	_,_= newFile.Write(bytes.NewBufferString(subs[0]).Bytes())
	   	newFile.Close()
		}
	}
	return c
}

//Function: Option Groupby From (optional function of command)


//Function: Option Groupby To (optional function of command)


//Function: Option lexicon (optional function of command)


// Function: Option spellcheck (optional function of command)
func spellcheck(username string) {
	fmt.Println("spellcheck: begin")
	// Search for files in all the depth of the directory /tmp/$USER/
	//m := `find /tmp/username/ -type f`
	//environ := os.Environ()
	//var stringer []string
	//stringer:="/tmp/username/ -type f"
	//s.Exec("find", stringer, environ)
	/*for i := range m {
	 fmt.Println("lala!!!" , i)
	}*/
}
/*
spellcheck()
{
	# Search for files in all the depth of the directory /tmp/$USER/
	for i in `find /tmp/$1/ -type f`
	do
		if [ -f $i ]; then
			cat $i | sed '1,/^$/d' > body.txt
			cat $i | sed -n '1,/^$/p' > header.txt
			aspell check body.txt
			cat body.txt >> header.txt
			mv header.txt $i
			rm body.txt
		else
			continue;
		fi
	done
}
*/


/***********
 * START   *
 ***********/
func main() {
	// Check if the user gives the right amount of arguments
	checkArguments()

	// Choose an option (depending on the amount of arguments)
	flag.Parse()
	if flag.NArg() == 2 {		// Default download (without options)
		fmt.Println("ARG=2")
		conn := downloadEmails(flag.Arg(0), flag.Arg(1))
		disconnect(&conn)
 	}else if flag.NArg() == 4 {					// GroupBy
		fmt.Println("ARG=4")
		//downloadEmails $3 $4
		if flag.Arg(1) == "From" || flag.Arg(1) == "from" {	// From
			//groupbyFrom $4
		}else if flag.Arg(1) == "To" || flag.Arg(1) == "to" {	// To
			//groupbyTo $4
		}else{
			os.Stdout.WriteString("Wrong headerfield!\n")
			os.Stdout.WriteString("Please enter 'From' or 'To'.\n")
		}
	//disconnect
 	}else if flag.NArg() == 3 {
		fmt.Println("ARG=3")
		fmt.Printf("%s\n",flag.Arg(0))
		//downloadEmails $2 $3
		if flag.Arg(0) == "lexicon" {				// lexicon
			//lexicon
		}else if flag.Arg(0) == "spellcheck" {			// spellcheck
			fmt.Print("\n")
			spellcheck(flag.Arg(2))
			//spellcheck $3
			//disconnect
 		}
 	}
}

