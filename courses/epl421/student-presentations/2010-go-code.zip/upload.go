//FILE: upload.go

package main

// Import Packages	
import (
        "bytes"
        "fmt"
        "net"
        "bufio"
	"flag"
	"os"
	"io/ioutil"
)

// Function: Check given arguments
func checkArgs() (emaildir, smtpserver, username string){
	// Scan the arg list and set up flags
	flag.Parse()

	// Check number of arguments	
        if flag.NArg() < 3 {
		fmt.Printf("Arguments must be 3\n")
		fmt.Printf("command: ./upload emaildir smtpserver username\n")
		os.Exit(-1)
	}
	
	// Check first argument to exist and be a directory
	fi, err := os.Stat(flag.Arg(0))
	if err == nil {
		if !fi.IsDirectory() {
		    	fmt.Printf("Argument 1 must be a directory\n")
    			os.Exit(-1)
		}
	} else {
		fmt.Printf("%s\n", err) // Directory does not exist
		os.Exit(-1)
	}
	
	return flag.Arg(0), flag.Arg(1), flag.Arg(2)
}

// Function: Connect to smtp server through a TCP connection
func connect(smtpserver string) net.Conn {
	addr := fmt.Sprintf("%s:26", smtpserver)
	
	c, err := net.Dial("tcp", "", addr)
        if err != nil {
		fmt.Printf("Unable to connect to server!\n")
		os.Exit(-1)
 	}
 	return c
}

// Function: Disconnect from server
func disconnect(c *net.Conn){
	buff := createCommand("QUIT")
	sendTo(c, buff)
	receiveFrom(c)

	err := c.Close()
	if err != nil{
		fmt.Printf("Failed to disconnect!\n")
	}
}

// Function: Create a command 
func createCommand(command string) *bytes.Buffer {
        buf := bytes.NewBufferString(command)
        buf.WriteString("\r\n")
        return buf
}

// Function: Send Command to the connection
func sendTo(c *net.Conn, b *bytes.Buffer) {
        data := b.Bytes()
        n, err := c.Write(data)
        if err != nil || n != len(data) {
                fmt.Printf("Data lost!!! %s\n", err)
        }
}

// Function: Read from the connection
func receiveFrom(c *net.Conn){
        r, rErr := bufio.NewReader(*c).ReadString('\n')
        if rErr != nil {
                fmt.Printf("Transmission error! %s\n", rErr)
        }
        fmt.Printf("%s", r)
}

// Function: Unix cat command
func cat(dir, filename string) string{
	cur, _ := os.Getwd()
	os.Chdir(dir)
	buf, _ := ioutil.ReadFile(filename)
	os.Chdir(cur)
	return fmt.Sprintf("%s", buf)
}

// The main method
func main() {

	emaildir, smtpserver, username := checkArgs()
	
	// Create a list with the will-be-uploaded emails 
	dir, _ := os.Open(emaildir, os.O_RDONLY, 777)
	listOfFiles, _ := dir.Readdir(-1)
	
	// Read and upload each email in emaildir
	for _, file := range listOfFiles {
		c := connect(smtpserver)
		receiveFrom(&c)

		command := fmt.Sprintf("HELO %s", username)
		buff := createCommand(command)
        	sendTo(&c, buff)
		receiveFrom(&c)

		command = fmt.Sprintf("MAIL FROM: %s@runbox.com", username)
		buff = createCommand(command)
	        sendTo(&c, buff)
		receiveFrom(&c)

		command = fmt.Sprintf("RCPT TO: %s@runbox.com", username)
		buff = createCommand(command)
        	sendTo(&c, buff)
		receiveFrom(&c) 

		buff = createCommand("DATA")
		sendTo(&c, buff)

		command = fmt.Sprintf("Subject: %s", file.Name)
        	buff = createCommand(command)
		sendTo(&c, buff)
		receiveFrom(&c)

		command = cat(emaildir, file.Name)
		buff = createCommand(command)
		sendTo(&c, buff)

		buff = createCommand(".")
		sendTo(&c, buff) 
		receiveFrom(&c)

		disconnect(&c)
	}
} 
