<?php

  session_start();
  
  $info = $_SESSION['preview'];
 

	
function getDescription($info){


$txt = "

         <A NAME='cs.ucy.".date('Υ').".".strtolower($info['lname'])."'> </A>
         <hr>
         <p>The Department of Computer Science at the University of Cyprus cordially invites you to the <b>colloquium</b> entitled:</p>
        <h2>".$info['subject']."</h2>
         <table cellpadding=4 cellspacing=4>
          <tr>
            <td valign=middle ><a target=_blank href='".$info['pic_link']."'><img border=0 width=100 height=120 src='".$info['pic_location']."'></a></td>
            <td>
              <p>
                <strong>Speaker: </strong>".$info['title']. " " .$info['fname']. " " .$info['lname']."<br/>
                <strong>Affiliation: </strong>".$info['university'].", ".$info['country']."<br/>
                <strong>Category: </strong>".$info['category']."<br/>
                <strong>Location:</strong> Room ".$info['room'].", Building ".$info['building'].", ".$info['campus']."(<a href='http://www.cs.ucy.ac.cy/colloquium/campus.jpg'>map</a>)<br/>
        <strong>Date: </strong>".$info['date']."<br/>
                <strong>Time:</strong>".$info['time']."<br/>
                <strong>Host:</strong>".$host['host']."<br/>
                <strong>URL:</strong> <a target='_blank' href='http://www.cs.ucy.ac.cy/colloquium/index.php#cs.ucy.".date('Y').".".strtolower($info['lname'])."'>http://www.cs.ucy.ac.cy/colloquium/index.php#cs.ucy.".date('Y').".".strtolower($info['lname'])."</a>
              </p>
            </td>
          </tr>
         </table>

        <p><strong>Abstract:</strong><br/>
        ".$info['abstract']."
        </p>
        <p><strong>Short Bio:</strong><br/>
        ".$info['short-bio']."
        </p>  
             
         <table cellpadding=1 cellspacing=0>
           <tr><td valign=middle><img border=0 width=20 src='http://www.cs.ucy.ac.cy/colloquium/web.jpg'></td><td valign=middle><b>Web:</b>&nbsp;<a href='http://www.cs.ucy.ac.cy/colloquium/'>http://www.cs.ucy.ac.cy/colloquium/</a></td></tr>
           <tr><td valign=middle><img border=0 width=20 src='http://www.cs.ucy.ac.cy/colloquium/mail.jpg'></td><td valign=middle><b>Mailing List:</b>&nbsp;<a href='http://listserv.cs.ucy.ac.cy/mailman/listinfo/cs-colloquium'>http://listserv.cs.ucy.ac.cy/mailman/listinfo/cs-colloquium</a></td></tr>
           <tr><td valign=middle><img border=0 width=20 src='http://www.cs.ucy.ac.cy/colloquium/rss.jpg'></td><td valign=middle><b>RSS:</b>&nbsp;<a href='http://www.cs.ucy.ac.cy/colloquium/rss.xml'>http://www.cs.ucy.ac.cy/colloquium/rss.xml</a></td></tr>
         </table>
         <br/>
           

         <table cellpadding='2' cellspacing='4' width='100%''>
           <tr><td><b>Sponsor:</b> The CS Colloquium Series is supported by a generous donation from <a target=_blank href='http://www.microsoft.com/en/us/default.aspx'><img border=0 alt='Microsoft' src='http://www.cs.ucy.ac.cy/colloquium/microsoft-small.jpg'><br/></td></tr>
           </td></tr>
         </table>               

         <hr/><br/><br/>";
   
   
    return($txt);

}




?>

<?php

function GUID()
{
    if (function_exists('com_create_guid') === true)
    {
        return trim(com_create_guid(), '{}');
    }

    return sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
}

?>


<?php

if (($_SERVER['REQUEST_METHOD'] == "GET") || ($_SERVER['REQUEST_METHOD'] == "POST")){

$doc = new DOMDocument();

$doc->load( 'colloquium.xml' ) or die("Error : Could not find xml file");
$doc->formatOutput = true;				


$item  = $doc->createElement("item");
$title = $doc->createElement("title");
$link  = $doc->createElement("link");
$type  = $doc->createElement("type");
$host  = $doc->createElement("host");
$guid  = $doc->createElement("guid");
$description = $doc->createElement("description");
$pubDate = $doc->createElement("pubDate");

$doc->appendChild($item);


$txt = "Colloquium: ".$info['subject'].", ".$info['title']." ".$info['fname']." ".$info['lname']." (".$info['university'].", ".$info['country']."), ".$info['date'].", ".$info['time'].".";
$txtNode = $doc->createTextNode($txt);
$title->appendChild($txtNode);
$item->appendChild($title);

$txt = "http://www.cs.ucy.ac.cy/colloquium/index.php#cs.ucy.".date('Y').".".strtolower($info['lname']).".";
$txtNode = $doc->createTextNode($txt);
$link->appendChild($txtNode);
$item->appendChild($link);

$txt = "Type: " . $info['category'];
$txtNode = $doc->createTextNode($txt);
$type->appendChild($txtNode);
$item->appendChild($type);

$txt = "Host: ". $info['host'];
$txtNode = $doc->createTextNode($txt);
$host->appendChild($txtNode);
$item->appendChild($host);

$txt = "guid: ". $info['guid'];
$txtNode = $doc->createTextNode($txt);
$guid->appendChild($txtNode);
$item->appendChild($guid);

$cdata = $doc->createCDATASection(getDescription($info));
$description->appendChild($cdata);
$item->appendChild($description);


// Prints something like: Monday 8th of August 2005 03:12:46 PM
//echo date('l jS \of F Y h:i:s A');
$txt = date('r');
$txtNode = $doc->createTextNode($txt);
$pubDate->appendChild($txtNode);
$item->appendChild($pubDate);
//Tue, 24 Mar 2011 10:00:00

echo "<form action=Preview.php method='post'>";

$doc->formatOutput = true;

if($_SERVER['REQUEST_METHOD']=="GET"){
	echo $description->nodeValue;
}

}


?>



<Input type="submit" value="Save" name="preview"/>
<Input type="submit" value="Cancel" name="preview" />

</form>

<?php if($_SERVER['REQUEST_METHOD']=='POST')
{
	switch($_POST['preview'])
	{
		case 'Save':

			//check if we are editing or adding something
		
			if (isset($_SESSION['edit_entry'])){
				//echo "<h2>is set is true</h2>";
				$pos = $_SESSION['edit_entry'];
				$edited = $doc->getElementsByTagName("item")->item($pos);
				$edited->parentNode->removeChild($edited);
				$previousItem = $doc->getElementsByTagName("item")->item($pos);
				unset($_SESSION['edit_entry']);
				}
			else	
				$previousItem = $doc->getElementsByTagName("item")->item(0);
			
				$x = $previousItem->parentNode;

				$x->insertBefore($item, $previousItem);
				$new_xml = $doc->saveXML();

				//create backup copy of existing file
				if (!copy('colloquium.xml', 'colloquium.backup')) {
    			echo "failed to make backup copy...\n";
	 			exit();
				}

  				$newfile=fopen('colloquium.xml','w') or exit("Unable to write to file!");

  				fwrite($newfile, $new_xml);

  				fclose($newfile);


				header('Location: menu.php');
			   
				break;
		case 'Cancel':
				header('Location: add.php');
				break;
	}


}?>

