<html>
<title> RSS Administration Panel </title>

<head>
<h1> RSS Administration Panel </h1>
</head>

<?php 
	session_start(); 
	if($_SESSION['name']==""){
		
		header('Location: login.php');}
	
?>

<?php


function get_string_between($string, $start, $end){

$string = " ". $string;

$ini = strpos($string,$start);

if ($ini == 0) return "";

$ini += strlen($start);

$len = strpos($string, $end, $ini) - $ini;

return substr($string, $ini, $len);

}

class html_field
{
    //field name of the property
     public $field_name;

     //patterns containing the field
     //starting pattern
    public $start;

     //ending pattern
     public $end;

    function __construct($name, $str1, $str2) {
             $this->field_name = $name;
           $this->start = $str1;
            $this->end = $str2;

   }

    //the field value
    public $value;
}

function add_table_element($text, $id){

  echo "<tr>\n";
  $color = ( $id%2==0)?"#659EC7":"#41627E"; 

  echo "<td bgcolor=$color>";
  echo "$text";
  echo "</td>\n";
 
    echo "<td bgcolor=$color> <input type=\"radio\" name=\"rss_select\" value=\"$id\" > </td>";
   
    echo "</tr>";

}
   
function delete_rss($guid){

  $doc = new DOMDocument();
  $doc->load( 'colloquium.xml' ) or die("Error : Could not find xml file");
  $doc->formatOutput = true;

  $y=$doc->getElementsByTagName("item")->item($guid-1);

  $y->parentNode->removeChild($y);

  $new_xml = $doc->saveXML();

    //create backup copy of existing file
    if (!copy('colloquium.xml', 'colloquium.backup')) {
    echo "failed to make backup copy...\n";
     exit();
    }

  $newfile=fopen('colloquium.xml','w') or exit("Unable to write to file!");

  fwrite($newfile, $new_xml);

  fclose($newfile);


    header('Location: menu.php');
}
 
?>


<?php
  if ($_SERVER['REQUEST_METHOD'] == 'GET') {
  ?>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">

<div style="height:60%;width:80%;font:16px/26px Georgia, Garamond, Serif;overflow:scroll;">


  <?php

    echo "<table border='0' align='center' cellspacing='10'";
    echo "<tr>";
    echo "<th>Title</th>";
    echo "<th>Option</th>";

   
  $doc = new DOMDocument();
  $doc->load( 'colloquium.xml' ) or die("Error : Could not find xml file colloquium");
 
  $items = $doc->getElementsByTagName( "item" );
 
  //i represents the number of the rss entry from 1 to n
  $i=1;
 
  foreach( $items as $item )
  {
  $titles = $item->getElementsByTagName( "title" );
  $title = $titles->item(0)->nodeValue;
 
  add_table_element($title, $i);
 
  $i = $i + 1;
 
  }

    echo "</table>"
   
  ?>
 
</div>

<input type="submit" name="submit" value="Add">
<input type="submit" name="submit" value="Edit">
<input type="submit" name="submit" value="Delete">
<input type="submit" name="submit" value="Move Up">
<input type="submit" name="submit" value="Move Down">

</form>

<?php
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {

  // branch on the basis of 'submit' value
  switch ($_POST['submit']) {
      // if submit => Add
      case 'Add':
            header('Location: add.php');
            exit();
            break;

      // if submit => Edit
      case 'Edit':
           
            if(isset($_POST['rss_select'])){
            $selected_entry = $_POST['rss_select'];
            read_item($selected_entry);
            }
            else
                    header('Location: menu.php');
            break;

      // if submit=> Delete
      case 'Delete':
             if(isset($_POST['rss_select'])){
          $selected_entry = $_POST['rss_select'];
          delete_rss($selected_entry);
             }
             else
                header('Location: menu.php');
          break;

        // if submit=> Move Up
        case 'Move Up':
             if(isset($_POST['rss_select'])){
             $selected_entry = $_POST['rss_select'];
             move($selected_entry, "up");
              }
             else
                header('Location: menu.php');
             break;
       
    // if submit => Move Down
        case 'Move Down':
        if(isset($_POST['rss_select'])){
             $selected_entry = $_POST['rss_select'];
             move($selected_entry, "down");
              }
             else
                header('Location: menu.php');
             break;

  }
}
?>
 
<?php

function move($id, $option){

  $doc = new DOMDocument();
  $doc->load( 'colloquium.xml' ) or die("Error : Could not find xml file");
  $doc->formatOutput = true;

  $current=$doc->getElementsByTagName("item")->item($id-1);


    switch ($option) {

        case "up" :
            $next = $doc->getElementsByTagName("item")->item($id-2);
        break;

        case "down" :
            $next = $doc->getElementsByTagName("item")->item($id);
        break;

        }

    $clone1 = $current->cloneNode(true);
    $clone2 = $next->cloneNode(true);

    $current->parentNode->replaceChild($clone2, $current);
    $next->parentNode->replaceChild($clone1, $next);

   $new_xml = $doc->saveXML();

    //create backup copy of existing file
    if (!copy('colloquium.xml', 'colloquium.backup')) {
    echo "failed to make backup copy...\n";
     exit();
    }

  $newfile=fopen('colloquium.xml','w') or exit("Unable to write to file!");

  fwrite($newfile, $new_xml);

  fclose($newfile);

    header('Location: menu.php');
}

?>

<?php

function read_item($id){

 $doc = new DOMDocument();
  $doc->load( 'colloquium.xml' ) or die("Error : Could not find xml file");
  $doc->formatOutput = true;

    $item = $doc->getElementsByTagName("item")->item($id-1);

    $text =  $doc->saveXML($item);

    $info = array();

    $info['fullname'] = new html_field("title", "<strong>Speaker: </strong>", "<br/>");
    $info['afiliation'] = new html_field("university", "<strong>Affiliation: </strong>", "<br/>");
    $info['location'] = new html_field("room", "<strong>Location:</strong>", " (<a href");
    $info['subject'] = new html_field("subject", "<title>Colloquium: ", ",");
    $info['date'] = new html_field("date", "<strong>Date: </strong>", "<br/>");
    $info['time'] = new html_field("time", "<strong>Time:</strong>", "<br/>");
    $info['host'] = new html_field("host", "<strong>Host:</strong> ", "<br/>");
    $info['abstract'] = new html_field("abtract", "<p><strong>Abstract:</strong><br/>", "</p>");
    $info['short-bio'] = new html_field ("short-bio", "<p><strong>Short Bio:</strong><br/>", "</p>");
    $info['category'] = new html_field ("category", "<strong>Category: </strong>" , "<br/>");
    $info['pic_location'] = new html_field("pic_location", "img border=0 width=100 height=120 src=\"", "\"></a></td>");
    $info['pic_link'] = new html_field("pic_link", "<td valign=middle ><a target=_blank href=\"", "\"><img");

    foreach($info as $key => $value){

        $field = get_string_between($text, $value->start, $value->end);
        $value->value = $field;

    }

	if(isset($_SESSION[$data]))
	unset($_SESSION[$data]);
   
    $data = array();
   
    $data['title'] = strtok($info['fullname']->value, " ");
    $data['fname'] = strtok(" ");
    $data['lname'] = strtok(" ");
    $data['university'] = strtok($info['afiliation']->value, ",");
    $data['country'] = strtok(",");
    $data['subject'] = $info['subject']->value;
    $data['room'] = substr(strtok($info['location']->value, ","), 5);
    $data['building'] = substr(strtok(","), 9);
    $data['campus'] = strtok(",");
    $data['date'] = $info['date']->value;
    $data['time'] = $info['time']->value;
    $data['host'] = $info['host']->value;
    $data['abstract'] = $info['abstract']->value;
    $data['short-bio'] = $info['short-bio']->value;
    $data['category'] = $info['category']->value;
    $data['pic_location'] = $info['pic_location']->value;
    $data['pic_link'] = $info['pic_link']->value;

	$_SESSION['data']=$data;
	$_SESSION['edit_entry'] = ($id-1);   

    header('Location: edit.php');

}
 
?>


</html>
