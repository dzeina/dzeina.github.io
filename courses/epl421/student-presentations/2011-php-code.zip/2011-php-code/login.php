<html>
<head>
    <title>Log IN</title>
</head>
<body > 


<center>
<?php echo 'Welcome at CS Colluquim Editor '?>  <BR>

<?php session_start();
	
		$_SESSION['name']=$_POST['name'];
	

if ($_SERVER['REQUEST_METHOD'] == 'GET') { 

?>

<form action="login.php" method="post">
<p><label  for="Administrator Login"> <font color="FF0000">Administrator Login </font></label> </p>
 <p>Your username: <input type="text" name="name" /></p>
 <p>Your password: <input type="password" name="passwd" /></p>

 <input type="submit" value="Login" name="check" >
</form>

<br>
<?php }


if($_SERVER['REQUEST_METHOD']=='POST'){

$file = fopen("login.txt","r") or exit("Unable to open file!");
$array=array();
while(!feof($file))
  {
  
  $tok=strtok(fgets($file),":");
  $tok2=strtok(":");			
  $array[$tok]=$tok2;					
  }
fclose($file);
?> <br><p> </p> <?php

$array[$_POST['name']] = str_replace(' ', '', $array[$_POST['name']]);
$_POST['passwd'] = str_replace(' ', '', $_POST['passwd']);
$array[$_POST['name']]=substr($array[$_POST['name']],0,-1); 


	


if(array_key_exists($_POST['name'],$array) && ($_POST['name']!="") && ($_POST['passwd']!=""))
	{
	if($array[$_POST['name']]==$_POST['passwd'])
		{header('Location: menu.php');?> 
	
	<?php
		}
	else
	{echo "Invalid Username or Password";
	
	?>
		
	<form action="login.php" method="link">
	<p><input type="submit" value="Go back" /></p>    	
 	</form>

    	<?php
	}
}
else
	{
	echo "Invalid Username or Password";?> 
	<br> 
	<?php echo "Please try again!"; 

	?>
	<form action="login.php" method="link">
	<p><input type="submit" value="Go back" /></p>    	
 	</form> 
	<?php
	}
}

?> 

<img src="ucy.jpg"></center>

</body>	
</html>


