 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>

  <title>Yahoo! Calendar Control - Single-Select Implementation</title>
  

  <link rel="stylesheet" href="./examples/calendar/css/examples.css" type="text/css">
  
  <script type="text/javascript" src="./build/yahoo/yahoo.js"></script>
  <script type="text/javascript" src="./build/event/event.js" ></script>
  <script type="text/javascript" src="./build/dom/dom.js" ></script>

  <link type="text/css" rel="stylesheet" href="./build/fonts/fonts.css">
  <link type="text/css" rel="stylesheet" href="./build/reset/reset.css">  

  <script type="text/javascript" src="./build/calendar/calendar.js"></script>
  <link type="text/css" rel="stylesheet" href="./build/calendar/assets/calendar.css">  

  <link rel="stylesheet" type="text/css" href="./docs/assets/dpSyntaxHighlighter.css" />
  
  <script language="javascript">
    YAHOO.namespace("example.calendar");

    function init() {
      YAHOO.example.calendar.cal1 = new YAHOO.widget.Calendar("YAHOO.example.calendar.cal1","cal1Container");
      YAHOO.example.calendar.cal1.render();
    }

    YAHOO.util.Event.addListener(window, "load", init);
  </script>

</head>

<body>
  <div id="pageTitle">
    <h3>Calendar Control</h3>
  </div>

  <div class="column left">
    <h4>Default Single-Select Implementation</h4>

    <p>The default Calendar implementation is a single-select 1-up calendar view that defaults to the current month and year. The basic calendar can be implemented by declaring a variable to represent the calendar, and passing the calendar's ID to the Calendar constructor:</p>
<textarea name="code" class="JScript" cols="60" rows="1">
var cal1;
function init() {
   cal1 = new YAHOO.widget.Calendar("cal1", "cal1Container");
   cal1.render();
}
</textarea>
    <p>The Calendar object should be instantiated after the body has been rendered, so that a reference to the container element that will contain the calendar can be obtained. The container element can reside anywhere within the body.</p>
<textarea name="code" class="HTML" cols="60" rows="1">
<div id="cal1Container"></div>
</textarea>

    </div>
    
    <div class="column right">
      <div style="margin-left:auto;margin-right:auto;width:150px">
      <div id="cal1Container"></div>
      <div style="margin-left:auto;margin-right:auto;text-align:center;width:150px;clear:both">
        <a href="javascript:YAHOO.example.calendar.cal1.reset()" class="navLink" style="font-size:12px;text-decoration:underline">reset</a>|
        <a href="javascript:alert(YAHOO.example.calendar.cal1.getSelectedDates())" class="navLink" style="font-size:12px;text-decoration:underline">what's selected?</a>
      </div>
    </div>
  </div>

<script src="./docs/assets/dpSyntaxHighlighter.js"></script>
<script language="javascript"> 
dp.SyntaxHighlighter.HighlightAll('code'); 
</script>

</body>
</html>
