###########################################################################
####....Maria Charalambous, Loukas Neokleous, Vladimiros Theodosiou....####
####.......Ylopioisi askisis 2 se glwssa programmatismou PERL..........####
###########################################################################

#!/usr/bin/perl

#enswmatwsi vivlio8ikis gia anoigma socket
use IO::Socket; 
use LWP::Simple;

#sinartisi gia anoigma socket
sub openSocket()
{
 #apo8ikevsi parametrwn sinartisis
 my $webpage = shift;
 my $textfile = shift;

 #anoigma tcp socket sto port 80
 my $socket = IO::Socket::INET->new(PeerAddr => $webpage,PeerPort => '80',Proto => 'tcp');
 die "\nCould not create socket: $!\n" unless $socket;

 $name = "http://".$webpage;
 getstore($name, $textfile) or die 'Unable to get page';

}

#sinartisi gia kleisimo tou socket
sub closeSocket()
{
 close($socket);
}

#sinartisi gia ton elegxo tou Content-Type
sub contentType()
{
 my $textfile = shift;
 my $line;
 my $type1="text/html";
 my $type2="text/plain";
 my $res;
 open(FILE, $textfile);
 my @contents = (<FILE>);
 close(FILE);

 foreach $line (@contents)
  {
   $res = index($line,$type1);
   if( $res != '-1' )
   {
    print "\nThe Content-Type Is OK!\n\n";
    return 1;
   }

 $res = index($line,$type2);
 if( $res != '-1' )
  {
   print "\nThe Content-Type is OK!\n";
   return 1;
  }
 }
 print "The Page Requested Has a Not-Acceptable Content-Type\n\n";
 return 0;
}

sub lexicon()
{
 my $textfile = shift;
 my $line;
 open(FILE, $textfile);
 my @contents = (<FILE>);
 close(FILE);
 open(OUTFILE, ">file1.txt");
 foreach $line (@contents)
  {
   $line =~ s/<[^>]*>//g;
   $line =~ s/<[^>]*$//g;
   $line =~ s/^[^<]*>//g;
   $line =~ s/\&[^;]*;//g;
   $line =~ s/[^a-zA-Z]/ /g;
   $line =~ s/^$//g;
   $line =~ s/[ \t\n\s]+/\n/g;

   print OUTFILE $line;
  }

  close(OUTFILE);
  open(FILE, "file1.txt");
  my @contents = (<FILE>);
  close(FILE);
  open(OUTFILE, ">file1.txt");

  foreach $line (@contents)
  {
    if ($line ne "\n")
    {
      print OUTFILE lc($line);
    }
  }

  close(OUTFILE);
}

sub crawler()
{
 my $webpage = shift;
 my $textfile = shift;
 my $myline;
 my $x;

 open(FILE, $textfile);
 my @contents = (<FILE>);
 close(FILE);
 open(OUTFILE, ">file2.txt");
 
 foreach $line(@contents)
 {
   #entoli gia entopismo twn sindesmwn pou vriskonte stin istoselida	
   if ($line =~ m/(<a href[^>]*>|<A HREF[^>]*>)/)  
       {
	$x = $1."\n";

	if ( $x =~ m/(\"[^\"]*\")/ )
	  {  
	    $x = $1."\n";

	    if ( $x =~ m/(\"http:\/\/$webpage[^\"]*\"|\"\.\/[^\"]*\"|\"\.\.\/[^\"]*\")/ )
	    {
	      $x = $1."\n";

	      $x =~ s/\"//g;
	      $x =~ s/http:\/\///g;
		
		
	      print OUTFILE $x;
	    }
	  }
	}

 }
  
 close(OUTFILE);

 open(OUTFILE, "file2.txt");
 my @contents = (<OUTFILE>);
 close(OUTFILE);

 open(OUTFILE, ">file2.txt");

 foreach $line(@contents)
 {
	if (!( $line =~ m/\.\/index\.html/ ))
	{
		print OUTFILE $line;
	}
 }

 close(OUTFILE);

 open(OUTFILE, "file2.txt");
 my @contents = (<OUTFILE>);
 close(OUTFILE);

 open(OUTFILE, ">file2.txt");

 foreach $line(@contents)
 {
	$line =~ s/^\.\.\//$webpage\//;
	$line =~ s/^\.\//$webpage\//;
	$line =~ s/\.\.\///g;

	print OUTFILE $line;
 }

 close(OUTFILE);

 open(OUTFILE, "file2.txt");
 my @contents = (<OUTFILE>);
 close(OUTFILE);

my %c_hash = ();
foreach my $line (@contents) {
  $c_hash{$line} = 1;
}
my @c_unique = keys(%c_hash);


 open(OUTFILE, ">file2.txt");
 foreach $line(@c_unique)
 {
	print OUTFILE $line;
 }
 close(OUTFILE);

 open(OUTFILE, ">>allpages.txt");
 foreach $line(@c_unique)
 {
	$line =~ s/$webpage//;
	print OUTFILE $line;
 }
 close(OUTFILE);

 open(OUTFILE, "allpages.txt");
 my @contents = (<OUTFILE>);
 close(OUTFILE);

my %c_hash = ();
foreach my $line (@contents) {
  $c_hash{$line} = 1;
}
my @c_unique = keys(%c_hash);

 open(OUTFILE, ">allpages.txt");
 foreach $line(@c_unique)
 {
	print OUTFILE $line;
 }
 close(OUTFILE);

}

###############################.....................MAIN.........................######################################

#dilwsi metavlitwn
my $textfile = "content.txt";
my $contype;
my $webpage = $ARGV[0];
my $depth = 0;
my $name;

$num_args = $#ARGV + 1;
if ($num_args != 2) {
  print "\n\nWrong number of arguments\n\nUsage: ./askisi2 <Webpage> <Depth>\n\n";
  exit;
}

print "\n*****************PROGRAM START*****************\n";

print"\nThe page you gave is : $ARGV[0]\n";
print"\nThe depth you gave is : $ARGV[1]\n";

&openSocket($webpage, $textfile);
$contype = &contentType($textfile);

open(BROKEN, ">brokenurl.txt");
open(VISITED, ">allvisited.txt");

if ($contype==1)
 {
 &lexicon($textfile);
 &crawler($webpage, $textfile);
 print VISITED $webpage."\n";


  while ($depth < $ARGV[1])
   {
	$depth++;

	open(FILE, "allpages.txt");
	my @contents = (<FILE>);
	close(FILE);
	unlink("allpages.txt");
	
	foreach my $url (@contents)
	 {
		$name = "http://".$webpage.$url;
		getstore($name, $textfile) or die 'Unable to get page';

		$contype = &contentType($textfile);

		if ($contype==1)
		 {
			&lexicon($textfile);
 			&crawler($ARGV[0], $textfile);
			print VISITED $webpage.$url;
		 }
		else
		 {
		print BROKEN $name;
		 }
	 }
    }
 }
 else
 {
  print BROKEN "http://".$webpage;
 }

&closeSocket;
close(BROKEN);
close(VISITED);

#Termatismos programmatos
print "\n******************PROGRAM END******************\n";
