function displayBooks(params){
	var tokens = params.split('&');
	var url = decodeURIComponent(tokens[0]) + "/mobile/getUserBooks.php";
	var user= decodeURIComponent(tokens[1]);
	
	var device="android";
	if (navigator.appVersion.indexOf("iOS")!=-1){
			device="iOS";
	}
		
	var formData = new Object();
	formData['device'] = device;  
	formData['username'] = user;  
	var jqxhr = $.post(url, formData)
        .done(function (data) {
		var json = JSON.parse(data);

		//document.write('<input type="button" onclick="history.back();" value="Back">');

	for (var i = 1; i < json.length; i++) {
	
	var stat;
	if(json[i].status=="0")
		stat="Available";
	else if(json[i].status=="1")
		stat="Rented";
	else if(json[i].status=="-1")
		stat="No Rentals";
	else if(json[i].status=="-2")
		stat="other - no rentals";

	//if(i===1){

	var output = [
	'<center>',
	'<a href="viewBook.html?',
	params,  //liburl + user
	'&',
	encodeURIComponent(json[i].isbn),
	'&',
	encodeURIComponent(user),
	'&',
	encodeURIComponent(json[i].title),
	'&',
	encodeURIComponent(json[i].authors),
	'&',
	encodeURIComponent(json[i].publishedYear),
	'&',
	encodeURIComponent(json[i].pageCount),
	'&',
	encodeURIComponent(json[i].dateOfInsert),
	'&',
	encodeURIComponent(json[i].lang),
	'&',
	encodeURIComponent(json[i].imgURL),
	'&',
  	encodeURIComponent(json[i].status),
	'"style="text-decoration:none;">',
	'<div id="wrapper" style="width:100%;">',
	'<div id="booktitle">',
	'<p id="bti" style="font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;font-size:2em;color:#0099FF;margin:0 0 0 0;">',
	json[i].title,
	'</p>',
	'</div>',
	'<div id="bookauthor">',
	'<p id="bau" style="font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;font-size:1em;color:#000000;margin:0 0 0 0;">',
	json[i].authors,
	'</p>',
	'</p>',
	'</div>',
	'<table cellspacing="0" cellpadding="5" width="100%" id="tableborder" style="border: 10px solid #0099FF;border-left-style: none;border-right-style: none;border-top-style: none;border-bottom-style: solid;border-bottom-width: 10px;" >',
	'<tr>',
	'<td align="left">',
	"<img src="+json[i].imgURL+" alt='cover' height='140' width='140' />",
	'<td align="left">',
	'<p id="bdet" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#000000;">ISBN:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
	json[i].isbn,
	'</p>',
	'<p id="bdet" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#000000;">Published:&nbsp;',
	json[i].publishedYear,
	'</p>',
	'<p id="bdet" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#000000;">Pages:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
	json[i].pageCount,
	'</p>',
	'<p id="bdet" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#000000;">Inserted:&nbsp;&nbsp;',
	json[i].dateOfInsert,
	'</p>',
	'<p id="bdet" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#000000;">Language:&nbsp;',
	json[i].lang,
	'</p>',
	'<p id="av" style="font-size:1em;font-family:Lucida Sans, Lucida Sans Regular, Lucida Grande, Lucida Sans Unicode, Geneva, Verdana, sans-serif;color:#0099FF;margin:0 0 0 0;" >',
	stat,
	'</p>',
	'</tr>',
	'</table>',
	'</div>',
	'</a>',
    '<br>',
	'</center>'
	];
  var newDiv = document.createElement("div");
  newDiv.innerHTML = output.join('\n');
  document.getElementById("main").appendChild(newDiv);
	//document.write(output.join('\n'));
	//}

	}	
	}
	)
        .fail(function () {
		alert("Failed");
	});
}