/** Automatically generated file. DO NOT MODIFY */
package com.epl371.Smartlib_portable;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}