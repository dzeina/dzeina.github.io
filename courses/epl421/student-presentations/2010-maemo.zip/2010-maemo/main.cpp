#include <QtGui/QApplication>
#include <QtSql>
#include <QMessageBox>
#include "search.h"

#include "recipe.h"

//Forms
Search *s;

Recipe *re;

//Database
QSqlDatabase db;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //Initialization of forms
    s = new Search();

    re = new Recipe();

    //Initialize database
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("recipe.sqlite");

    if (db.open())
    {
        //Success
    }
    else
    {
        // error
        QMessageBox msgBox;
        msgBox.setText("ERROR");
        msgBox.setInformativeText("Something went wrong with the database connection.");
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setIcon(QMessageBox::Critical);

        msgBox.exec();
    }

    //Show search form
    s->show();

    return a.exec();
}
