#ifndef SEARCH_H
#define SEARCH_H

#include <QMainWindow>
#include <QModelIndex>

namespace Ui {
    class Search;
}

class Search : public QMainWindow {
    Q_OBJECT
public:
    Search(QWidget *parent = 0);
    ~Search();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::Search *ui;

private slots:
    void on_tableView_doubleClicked(QModelIndex index);
    void on_pushButton_clicked();
};

#endif // SEARCH_H
