/********************************************************************************
** Form generated from reading UI file 'recipe.ui'
**
** Created: Sun Apr 18 23:42:09 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECIPE_H
#define UI_RECIPE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Recipe
{
public:
    QWidget *centralwidget;
    QTextEdit *textEdit;
    QPushButton *pushButton;

    void setupUi(QMainWindow *Recipe)
    {
        if (Recipe->objectName().isEmpty())
            Recipe->setObjectName(QString::fromUtf8("Recipe"));
        Recipe->resize(800, 400);
        centralwidget = new QWidget(Recipe);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 10, 781, 321));
        QFont font;
        font.setPointSize(14);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 340, 781, 51));
        QFont font1;
        font1.setPointSize(24);
        pushButton->setFont(font1);
        Recipe->setCentralWidget(centralwidget);

        retranslateUi(Recipe);

        QMetaObject::connectSlotsByName(Recipe);
    } // setupUi

    void retranslateUi(QMainWindow *Recipe)
    {
        Recipe->setWindowTitle(QApplication::translate("Recipe", "MainWindow", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("Recipe", "New Search", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Recipe: public Ui_Recipe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECIPE_H
