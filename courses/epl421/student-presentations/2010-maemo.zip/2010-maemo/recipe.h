#ifndef RECIPE_H
#define RECIPE_H

#include <QMainWindow>

namespace Ui {
    class Recipe;
}

class Recipe : public QMainWindow {
    Q_OBJECT
public:
    Recipe(QWidget *parent = 0);
    ~Recipe();

    void displayRecipe(QString index);

protected:
    void changeEvent(QEvent *e);

private:
    Ui::Recipe *ui;

private slots:
    void on_pushButton_clicked();
};

#endif // RECIPE_H
