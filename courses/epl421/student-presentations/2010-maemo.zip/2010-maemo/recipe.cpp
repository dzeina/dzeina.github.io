#include "recipe.h"
#include "search.h"
#include "ui_recipe.h"
#include <QtSql>
#include <QDesktopWidget>

//Database
extern QSqlDatabase db;

//Query Model
QSqlQueryModel *querymodel;

//Form
extern Search *s;

Recipe::Recipe(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Recipe)
{
    ui->setupUi(this);

    QDesktopWidget dsk;

    querymodel = new QSqlQueryModel();
}

Recipe::~Recipe()
{
    delete ui;
}

void Recipe::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void Recipe::displayRecipe(QString index)
{
    QSqlRecord r;
    ui->textEdit->clear();
    querymodel->setQuery("Select * from Recipe where ID=\"" + index + "\";");
    r = querymodel->record(0);

    ui->textEdit->append("<div align=\"center\"><u>" +
                         r.field(1).value().toString() +
                         ((r.field(64).value().toString().isEmpty())?"":" (" + r.field(64).value().toString()+")") +
                         "</u></div><BR><b>Equipment:</b>");



    for(int j=0; j<4; ++j)
    {
        if (!(r.field(j+6).value().toString().isEmpty())){
            ui->textEdit->append(r.field(j+6).value().toString());
        }
    }

    ui->textEdit->append("<BR><b>Ingredients:</b>");
    for(int j=0; j<15; ++j)
    {
        if (!(r.field(j*3+10).value().toString().isEmpty())){
            ui->textEdit->append(r.field(j*3+10).value().toString() + " "+
                                 r.field(j*3+11).value().toString() + " ("+
                                 r.field(j*3+12).value().toString() + ")");
        }
    }

    ui->textEdit->append("<BR><b>Instructions:</b>");
    for(int j=0; j<3; ++j)
    {
        if (!(r.field(j+55).value().toString().isEmpty())){
            ui->textEdit->append(r.field(j+55).value().toString());
        }
    }

    QWidget::show();
}

void Recipe::on_pushButton_clicked()
{
    this->hide();
    s->show();
}
