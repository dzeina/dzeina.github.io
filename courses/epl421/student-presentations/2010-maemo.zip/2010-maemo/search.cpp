#include "search.h"
#include "recipe.h"
#include "ui_search.h"
#include <QtSql>
#include <QDesktopWidget>

//Forms
extern Search *s;
extern Recipe *re;

//Database
extern QSqlDatabase db;

//Query Model
QSqlQueryModel *model;

Search::Search(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);

    QDesktopWidget dsk;

    model = new QSqlQueryModel();
}

Search::~Search()
{
    delete ui;
}

void Search::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}


void Search::on_pushButton_clicked()
{
    model->setQuery("SELECT ID, RecipeName, Description FROM recipe WHERE RecipeName LIKE \"%" + ui->lineEdit->text() + "%\"");

    ui->tableView->setModel(model);
    ui->tableView->show();

    ui->tableView->setColumnHidden(0,true);
    ui->tableView->setColumnWidth(1,290);
    ui->tableView->setColumnWidth(2,430);
}

void Search::on_tableView_doubleClicked(QModelIndex index)
{
    re->displayRecipe(model->record(index.row()).field(0).value().toString());
    this->hide();
}
