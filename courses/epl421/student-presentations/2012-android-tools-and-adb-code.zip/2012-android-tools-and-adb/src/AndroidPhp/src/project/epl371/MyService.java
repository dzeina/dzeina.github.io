package project.epl371;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service implements Runnable {
	private NotificationManager nm;
	String TAG = "SERVER_THREAD";
	/** Server */
	ServerSide server;
	static String lastCmd = "";
	private static boolean isRunning = false;
	private static boolean threadRunning = false;

	ArrayList<Messenger> mClients = new ArrayList<Messenger>(); // Keeps track
																// of all
																// current
																// registered
																// clients.

	static final int MSG_REGISTER_CLIENT = 1;
	static final int MSG_UNREGISTER_CLIENT = 2;
	static final int MSG_GUI_Command = 3;
	static final int MSG_GUI_Result = 4;
	static final int MSG_INSTALL = 5;
	final Messenger mMessenger = new Messenger(new IncomingHandler()); // Target
																		// we
																		// publish
																		// for
																		// clients
																		// to
																		// send
																		// messages
																		// to
																		// IncomingHandler.

	public static final String APK_URL = "http://192.168.10.21/epl371/newEra.php";

	@Override
	public IBinder onBind(Intent intent) {
		return mMessenger.getBinder();
	}

	class IncomingHandler extends Handler { // Handler of incoming messages from
											// clients.
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_REGISTER_CLIENT:
				mClients.add(msg.replyTo);
				break;
			case MSG_UNREGISTER_CLIENT:
				mClients.remove(msg.replyTo);
				break;
			default:
				super.handleMessage(msg);
			}
		}
	}

	private void sendMessageToUI(String msg_str) {

		for (int i = mClients.size() - 1; i >= 0; i--) {
			try {
				// Send Command Message
				Bundle b = new Bundle();
				b.putString("str1", msg_str);
				Message msg = Message.obtain(null, MSG_INSTALL);
				msg.setData(b);
				mClients.get(i).send(msg);

			} catch (RemoteException e) {
				// The client is dead. Remove it from the list; we are going
				// through the list from back to front so this is safe to do
				// inside the loop.
				mClients.remove(i);
			}
		}
	}

	private void sendMessageToUI(String cmd, String result) {
		for (int i = mClients.size() - 1; i >= 0; i--) {
			try {
				// Send Command Message
				Bundle b = new Bundle();
				b.putString("str1", cmd);
				Message msg = Message.obtain(null, MSG_GUI_Command);
				msg.setData(b);
				mClients.get(i).send(msg);

				b = new Bundle();
				b.putString("str1", result);
				msg = Message.obtain(null, MSG_GUI_Result);
				msg.setData(b);
				mClients.get(i).send(msg);

			} catch (RemoteException e) {
				// The client is dead. Remove it from the list; we are going
				// through the list from back to front so this is safe to do
				// inside the loop.
				mClients.remove(i);
			}
		}
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Log.i("MyService", "Service Started.");
		showNotification();
		isRunning = true;
		Log.d(TAG, "onStart");
		if (!threadRunning) {
			threadRunning = true;
			new Thread(this).start();
		}
	}

	private void showNotification() {
		nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

		// Set the icon, scrolling text and timestamp
		Notification notification = new Notification(R.drawable.ic_launcher,
				"Service Started", System.currentTimeMillis());
		// The PendingIntent to launch our activity if the user selects this
		// notification
		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
				new Intent(this, AndroidPhpActivity.class), 0);
		// Set the info for the views that show in the notification panel.
		notification.setLatestEventInfo(this, "Latest Info", lastCmd,
				contentIntent);
		// Send the notification.
		// We use a layout id because it is a unique number. We use it later to
		// cancel.
		nm.notify(R.string.send_button, notification);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i("MyService", "Received start id " + startId + ": " + intent);
		return START_STICKY; // run until explicitly stopped.
	}

	public static boolean isRunning() {
		return isRunning;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		nm.cancel(R.string.send_button); // Cancel the persistent notification.
		Log.i("MyService", "Service Stopped.");
		isRunning = false;
		threadRunning = false;
	}

	/** Thread job */
	@Override
	public void run() {
		server = new ServerSide();
		server.initServer(4000);
		while (threadRunning) {
			server.startServer();
			handleClient();
		}
	}

	/** Client Connected */
	void handleClient() {
		byte[] apkBytes ;
		String cmd = "";
		
		String args = "";
		String result;

		try {
			cmd = server.getMessage();
			Log.i("COMMAND", cmd);

			if (cmd.equals("cmd")) {
				server.sendMessage("OKcmd");

				cmd = server.getMessage();

				Log.d(TAG, cmd);
				result = ShellCommands.runCommand(cmd);
				// Send number of bytes
				server.sendMessage("" + result.length());
				server.getMessage();
				String result_Send = "<br>" + result.replace("\n", "<br>");
				server.sendMessage("Command executed:\n " + result_Send);

				sendMessageToUI(cmd + " " + args, result);
				lastCmd = cmd + " " + args;

			} else if (cmd.equals("install")) {
				server.sendMessage("OKinstall");

				String pathNToInstall = "/download/";
				int bytesToRead = server.getBytesToRead();
				if (bytesToRead == 1)
					return;
				apkBytes= new byte[bytesToRead + 1025];
				int bytesRead = server.getMessageInBytes(apkBytes,bytesToRead);
				
				// Log.i("BYTES", apkBytes);

				server.sendMessage("File received OK");
				String apkFilename = server.getMessage();
				File sdCard = Environment.getExternalStorageDirectory();
				File dir = new File(sdCard.getAbsolutePath() + pathNToInstall);
				dir.mkdirs();
				File outputFile = new File(dir, apkFilename);
				outputFile.createNewFile();
				FileOutputStream fos = new FileOutputStream(outputFile);
				
				fos.write(apkBytes, 0, bytesRead);

				fos.close();

				String path = sdCard.getAbsolutePath() + pathNToInstall
						+ apkFilename;
				sendMessageToUI(path);

				server.sendMessage(cmd + " OK");
			} else if (cmd.equals("transfer")) {
				server.sendMessage("OKtransfer");

				String pathNToInstall = "/download/";
				int bytesToRead = server.getBytesToRead();
				if (bytesToRead == 1)
					return;
				apkBytes= new byte[bytesToRead + 1025];
				int bytesRead = server.getMessageInBytes(apkBytes,bytesToRead);
				

				server.sendMessage("File received OK");
				String apkFilename = server.getMessage();
				File sdCard = Environment.getExternalStorageDirectory();
				File dir = new File(sdCard.getAbsolutePath() + pathNToInstall);
				dir.mkdirs();
				File outputFile = new File(dir, apkFilename);
				outputFile.createNewFile();
				FileOutputStream fos = new FileOutputStream(outputFile);

				fos.write(apkBytes, 0, bytesRead);

				fos.close();

				server.sendMessage(cmd + " OK");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sendMessageToUI(cmd, e.getMessage());
			server.sendMessage(e.getMessage());
		}

	}

	private String[] parseArgs(String args) {
		if (args == null)
			return null;

		else if (args.compareTo("#NONE#") == 0)
			return null;

		return args.split(" ");

	}

}
