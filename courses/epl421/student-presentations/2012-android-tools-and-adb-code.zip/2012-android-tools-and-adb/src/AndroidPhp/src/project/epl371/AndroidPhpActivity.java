package project.epl371;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class AndroidPhpActivity extends Activity implements OnClickListener {
	private static final String TAG = "MAIN";

	/** Called when the activity is first created. */
	boolean connected = false;
	TextView cmd_box;
	TextView result_box;

	/**
	 * Communication between service and main thread
	 * */
	Messenger mService = null;
	boolean mIsBound;
	final Messenger mMessenger = new Messenger(new IncomingHandler());

	class IncomingHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			String str1;
			switch (msg.what) {
			case MyService.MSG_GUI_Command:
				str1 = msg.getData().getString("str1");
				cmd_box.setText("Executed Command: " + str1);
				break;
			case MyService.MSG_GUI_Result:
				str1 = msg.getData().getString("str1");
				result_box.setText("Result: " + str1);
				break;
			case MyService.MSG_INSTALL:
				str1 = msg.getData().getString("str1");
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(Uri.fromFile(new File(str1)),
						"application/vnd.android.package-archive");
				startActivity(intent);
			default:
				super.handleMessage(msg);
			}
		}
	}

	private ServiceConnection mConnection = new ServiceConnection() {
		public void onServiceConnected(ComponentName className, IBinder service) {
			mService = new Messenger(service);
			try {
				Message msg = Message.obtain(null,
						MyService.MSG_REGISTER_CLIENT);
				msg.replyTo = mMessenger;
				mService.send(msg);
			} catch (RemoteException e) {
				// In this case the service has crashed before we could even do
				// anything with it
			}
		}

		public void onServiceDisconnected(ComponentName className) {
			// This is called when the connection with the service has been
			// unexpectedly disconnected - process crashed.
			mService = null;
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(policy);

		setContentView(R.layout.main);
		// postData("");
		View startBtn = findViewById(R.id.startService);
		View stopBtn = findViewById(R.id.stopService);
		View post = findViewById(R.id.ip_post);
		startBtn.setOnClickListener(this);
		stopBtn.setOnClickListener(this);
		post.setOnClickListener(this);
		cmd_box = (TextView) findViewById(R.id.cmd_text);
		result_box = (TextView) findViewById(R.id.result_text);

		CheckIfServiceIsRunning();

	}

	private void CheckIfServiceIsRunning() {
		// If the service is running when the activity starts, we want to
		// automatically bind to it.
		if (MyService.isRunning()) {
			doBindService();
		}
	}

	void doBindService() {
		bindService(new Intent(this, MyService.class), mConnection,
				Context.BIND_AUTO_CREATE);
		mIsBound = true;

	}

	void doUnbindService() {
		if (mIsBound) {
			// If we have received the service, and hence registered with it,
			// then now is the time to unregister.
			if (mService != null) {
				try {
					Message msg = Message.obtain(null,
							MyService.MSG_UNREGISTER_CLIENT);
					msg.replyTo = mMessenger;
					mService.send(msg);
				} catch (RemoteException e) {
					// There is nothing special we need to do if the service has
					// crashed.
				}
			}
			// Detach our existing connection.
			unbindService(mConnection);
			mIsBound = false;

		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		try {
			doUnbindService();
		} catch (Throwable t) {
			Log.e("MainActivity", "Failed to unbind from the service", t);
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.startService: {
			if (!MyService.isRunning()) {
				startService(new Intent(this, MyService.class));
				doBindService();
			} else {
				Toast.makeText(this, "Service Already running",
						Toast.LENGTH_SHORT).show();
			}
			break;
		}
		case R.id.stopService: {
			doUnbindService();
			stopService(new Intent(this, MyService.class));
			break;
		}
		case R.id.ip_post: {

			postData("MyIP");

			break;
		}
		}

	}

	public void postData(String toPost) {
		// Create a new HttpClient and Post Header

		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(
				"http://10.16.5.77/phpTutorials/testing.php");

		// This is the data to send
		String MyName = android.os.Build.MODEL; // any data to send

		try {
			// Add your data
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("action", MyName));

			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

			// Execute HTTP Post Request

			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			String response = httpclient.execute(httppost, responseHandler);

			// This is the response from a php application
			String reverseString = response;
			Toast.makeText(this, "response:\n" + reverseString, Toast.LENGTH_LONG)
					.show();
			Log.d(TAG, reverseString);
			

		} catch (ClientProtocolException e) {
			Toast.makeText(this, "CPE response " + e.toString(),
					Toast.LENGTH_LONG).show();
			// TODO Auto-generated catch block
		} catch (IOException e) {
			Toast.makeText(this, "IOE response " + e.toString(),
					Toast.LENGTH_LONG).show();
			// TODO Auto-generated catch block
		}

	}// end postData()

}