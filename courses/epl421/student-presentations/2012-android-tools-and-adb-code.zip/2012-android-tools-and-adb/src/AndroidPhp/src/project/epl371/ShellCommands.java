package project.epl371;

import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.util.Log;

public class ShellCommands {

	static Runtime runtime = Runtime.getRuntime();
	static String TAG = "CommandFunc";

	/**
	 * 
	 * @param command
	 *            to execute
	 * @return result
	 */
	public static String runCommand(String command) {
		String[] cmd = { "/system/bin/sh", "-c", command, };
		Process process;

		try {

			process = runtime.exec(cmd);

			// Reads stdout.
			// NOTE: You can write to stdin of the command using
			// process.getOutputStream().
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			int read;
			char[] buffer = new char[4096];
			StringBuffer output = new StringBuffer();
			while ((read = reader.read(buffer)) > 0) {
				output.append(buffer, 0, read);
			}
			reader.close();

			// Waits for the command to finish.
	
			return output.toString();
		} catch (IOException e) {
			Log.e(TAG, e.toString());
			return e.toString();
		}

	}

}