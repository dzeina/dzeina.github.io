package project.epl371;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import android.util.Log;

public class ServerSide {
	String TAG = "SERVER";
	ServerSocket listenSocket;
	public static int SERVERPORT = 4444;
	public static final int MAX_SIZE = 16000000; // ~ 1.5 Megabyte Max file
	Socket connection;
	String buf;
	String send = "Testing sock";
	OutputStream outStream;
	InputStream inStream;
	String message;

	public void initServer(int port) {
		SERVERPORT = port;
		try {
			listenSocket = new ServerSocket(SERVERPORT);
			Log.d(TAG, "Waiting for client...");
		} catch (Exception e) {
			System.out.println("S: Error");
			e.printStackTrace();
		}
	}

	public void startServer() {
		try {

			connection = listenSocket.accept();
			System.out.println("Client connected!");
			outStream = connection.getOutputStream();
			inStream = connection.getInputStream();
		} catch (Exception e) {
			System.out.println("S: Error");
			e.printStackTrace();
		}

	}

	/**
	 * Send a message to the server as String
	 * 
	 * @param msg
	 *            - the message
	 */
	public void sendMessage(String msg) {
		try {
			outStream.write(msg.getBytes(), 0, msg.length());
		} catch (Exception e) {
			Log.e("Sending ", "ERROR: ", e);
		}
	}

	/**
	 * Get a message from the server
	 * 
	 * @return the message the server send
	 * @throws IOException
	 */
	public String getMessage() throws IOException {
		String rtrn_string = "";
		byte[] buf = new byte[1024];
		int readBytes = 0;
		// while ((readBytes = inStream.read(buf, 0, 1024))>0)
		// {
		readBytes = inStream.read(buf, 0, 1024);
		String tmpString = new String(buf, 0, readBytes);
		rtrn_string += tmpString;

		// }
		return rtrn_string;
	}
	public int getBytesToRead() throws IOException
	{
		byte[] temp = new byte[1024];
		int readBytes = 0;
		int bytesToRead = 0;
		
		readBytes=inStream.read(temp);
		
		String tmpString = new String(temp, 0, readBytes);
		Log.d(TAG, tmpString);
		bytesToRead= Integer.parseInt(tmpString);		
		if (bytesToRead == 1)
			return 1;
		sendMessage("OK received "+bytesToRead+" Bytes");
		return bytesToRead;
	}
	public int getMessageInBytes(byte[] buf, int bytesToRead) throws IOException {
		int readBytes = 0;
		int read = 0;
		readBytes = 0;
		while (bytesToRead > readBytes)
		{			
			read = inStream.read(buf,readBytes,1024);
			readBytes+=read;
		}
		return readBytes;
	}

}
