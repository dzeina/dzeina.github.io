
     $('#tran').(function(){
	 var tran = this.val();
     	alert(tran);
     });
    
