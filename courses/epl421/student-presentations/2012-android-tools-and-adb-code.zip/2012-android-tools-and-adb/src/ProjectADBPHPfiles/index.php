
<form action="" method="get">
	
	<strong>Select Device to send your commands</br></strong> <br>
	
	<select name="sel_device">
	<?php
	/* Bring phones */
		
		$con = mysql_connect( 'localhost', 'root', '' );
		if( !$con ) {
			die( 'Could not connect: ' . mysql_error() );
		}
		mysql_select_db( '371Project', $con );

		$Ip=$_SERVER['REMOTE_ADDR'];
		echo "$Ip";
		$sql = "call GetAllPhones()";
		$retval = mysql_query( $sql, $con );
		$i=0;
		while ($row = mysql_fetch_array($retval, MYSQL_NUM))
		{
			if ($i == 0) {
				echo ("<option value=$row[1] selected=\"selected\" >$row[0]  </option>");
			} else {
				echo ("<option value=$row[1] >$row[0]  </option>");
			$i = 1;
        }
			
		}
		mysql_free_result($result);
		?>
	</select>
	<br><br>	
		
    	<strong>Please give me a shell command:</strong> <br>
		<input type="text" name="cmd" onmouseover="this.focus(); this.select();"><br> <br>
		
		<strong>Install an .apk file to your device.</br>Type in the path and the name of your apk(ex. /Desktop/apoel.apk): </strong> <br>
		<label for="file">Filename:</label>
		<input type="text" name="install" onmouseover="this.focus(); this.select();"><br> <br>
		
		<strong>Transfer a file to your device</br>Type in the path and the name of your file(ex. /Desktop/apoel.cs): </strong> <br>
		<label for="file">Filename:</label>
		<input type="text" name="transfer" onmouseover="this.focus(); this.select();"><br> <br>
		<!-- id="tran"-->
		<input type="submit" value="EXECUTE COMMAND"> <br><br>
        		
</form>

<!--
<script type="text/javascrpt" src="js/jQuery.js"> </script>
<script type="text/javascrpt" src="js/selector.js"> </script>
-->

<?php
function connect($selected){
	/* Get the port for the WWW service. */
	$service_port = 4000;
	
	/* Get the IP address for the target host. */
	$address = $selected;//'192.168.10.5';/
	
	/* Create a TCP/IP socket. */
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if ($socket === false) {
		echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
	} else {
		echo "OK.\n";
	}
	
	echo "Attempting to connect to '$address' on port '$service_port'...<br><br>";
	$result = socket_connect($socket, $address, $service_port);
	if ($result === false) {
		echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
	} else {
		echo "OK.\n";
	}
	return $socket;
}
function getfilename($path)
{
	$pos = strrpos($path,"\\");
	$filename=substr($path,$pos+1,strlen($path));
	return "$filename";
}

function command($cmd,$exec,$selected ){
	$socket = connect($selected );
	/* Send type of execution */
	socket_write($socket, $exec, strlen($exec));
	
	$out = socket_read($socket, 2048);
	echo "SERVER sent me: $out<br><br>";
	
	/* HERE IS THE DIFFERENCE IN PROTOCOLS */
	if ($out == "OKcmd"){
		/* Send Command */
		$in = $cmd;
		socket_write($socket, $in, strlen($in));
		echo "OK.<br><br>";
		
		$out = '';
		
		/* Get result bytes number */	
		echo "Trying to read number of bytes... <br><br>";
		$numbytes = socket_read($socket, 2048);
		echo "Result:<br> $numbytes <br><br>";
		
		/* Get result bytes number */	
		echo "Send O.K. <br><br>";
		$in="OK";
		socket_write($socket, $in, strlen($in));
		echo "OK Second Write.<br><br>";
		
		/* Get result response */	
		echo "Trying to read result... <br><br>";
		$readbytes=0;
		$result = "";
		while ($readbytes < $numbytes)
		{
			$out = socket_read($socket, 2048);
			$result = $result . $out;
			$readbytes= $readbytes + strlen($out);
		}
		
		str_replace("0","<br>",$result);
		echo "Result:<br> $result<br><br>";
		
	} else if ($out == "OKinstall"){
		
		if (file_exists($cmd)){
			$size = filesize($cmd);
			echo "$cmd : $size";
			$file_handle = fopen($cmd, 'r');					
			
			$contents = '';
			while (!feof($file_handle)) {
			  	$contents .= fread($file_handle, 8192);
			}
			
			/* Send number of bytes first */
			$in=$contents;
			$size =   strlen($in);
			echo "size = $size";
			socket_write($socket, $size, strlen($size));
			
			/* Get result response */	
			echo "Read OK.. # of bytes received <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";			
			
			$size =   strlen($in);
			socket_write($socket, $in, strlen($in));
			
			/* Get result response */	
			echo "Trying to read result... <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";			
			
			/* Send filename */
			$filename=getfilename($cmd);
			socket_write($socket, $filename, strlen($filename));
			
			/* Get result response */	
			echo "Trying to read result... <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";	
			
			fclose($file_handle);			
		}
		
		else
		{
			echo "File: $cmd Does not exists<br>";
			socket_write($socket, "1", strlen("1"));
		}
			
	}
	else if ($out == "OKtransfer"){
		
		if (file_exists($cmd)){
			$size = filesize($cmd);
			echo "$cmd : $size";
			$file_handle = fopen($cmd, 'r');					
			
			$contents = '';
			while (!feof($file_handle)) {
			  	$contents .= fread($file_handle, 8192);
			}
			
			/* Send number of bytes first */
			$in=$contents;
			$size =   strlen($in);
			echo "size = $size";
			socket_write($socket, $size, strlen($size));
			
			/* Get result response */	
			echo "Read OK.. # of bytes received <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";			
			
			$size =   strlen($in);
			socket_write($socket, $in, strlen($in));
			
			/* Get result response */	
			echo "Trying to read result... <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";			
			
			/* Send filename */
			$filename=getfilename($cmd);
			socket_write($socket, $filename, strlen($filename));
			
			/* Get result response */	
			echo "Trying to read result... <br><br>";
			$out = socket_read($socket, 2048);
			echo "Result:<br> $out<br><br>";	
			
			fclose($file_handle);			
		}
		
		else
		{
			echo "File: $cmd Does not exists<br>";
			socket_write($socket, "1", strlen("1"));
		}
			
	}
	
	
	/*
	while ($out = socket_read($socket, 2048)) {
		echo $out;
	}
	*/
	
	
	echo "Closing socket...";
	socket_close($socket);
	echo "OK.\n\n";
}
	
	$selected  =  $_GET['sel_device'];
	
	
	if ( isset($_GET['cmd']) ){
		$cmd = $_GET['cmd'];
		if (empty($cmd)){
			//echo 'Please fill in a command first!';
		}else{
			echo "You gave me : \"$cmd   \", right?<br>";
			command($cmd,"cmd",$selected );
		}
	}
	
	if ( isset($_GET['install']) ){
		$install = $_GET['install'];
		
		if (empty($install)){
			//echo 'Please fill in a command first!';
		}else{
			echo "You gave me : \"$install\", to install, right?<br>";
			command($install,"install",$selected );
		}
	}
	
	if ( isset($_GET['transfer']) ){
		$transfer = $_GET['transfer'];
		
		if (empty($transfer)){
			//echo 'Please fill in a command first!';
		}else{
			echo "You gave me : \"$transfer\", to transfer to mobile, right?<br>";
			command($transfer,"transfer",$selected );
		}
	}
	
?>
