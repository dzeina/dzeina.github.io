


<form action="" method="get">
    	<strong>Please give me a shell command:</strong> <br>
		<input type="text" name="cmd" onmouseover="this.focus(); this.select();"><br> <br>
        
		<strong>Command arguments separated by space character (ex. -a home/a ): </strong> <br>
		<input type="text" name="args" onmouseover="this.focus(); this.select();"><br>
		<input type="submit" value="Submit"> <br>
		
</form>

<?php
function connect($cmd,$args){
	/* Get the port for the WWW service. */
	$service_port = 4000;
	
	/* Get the IP address for the target host. */
	$address = '10.16.5.104';
	
	/* Create a TCP/IP socket. */
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if ($socket === false) {
		echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
	} else {
		echo "OK.\n";
	}
	
	echo "Attempting to connect to '$address' on port '$service_port'...<br><br>";
	$result = socket_connect($socket, $address, $service_port);
	if ($result === false) {
		echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
	} else {
		echo "OK.\n";
	}
	
	/* Send Command */
	$in = $cmd;
	socket_write($socket, $in, strlen($in));
	echo "OK.<br><br>";
	
	$out = '';
	
	/* Get OK response */	
	echo "Trying to read... <br><br>";
	$out = socket_read($socket, 2048);
	echo "SERVER sent me: $out<br><br>";

	echo "Trying to write arguments... <br><br>";
	$in=$args;
	socket_write($socket, $in, strlen($in));
	echo "OK Second Write.<br><br>";
	
	/* Get result response */	
	echo "Trying to read result... <br><br>";
	$out = socket_read($socket, 2048);
	echo "Result:<br> $out<br><br>";
	/*
	while ($out = socket_read($socket, 2048)) {
		echo $out;
	}
	*/
	
	
	echo "Closing socket...";
	socket_close($socket);
	echo "OK.\n\n";
}

if ( isset($_GET['cmd']) ){
		$cmd = $_GET['cmd'];
		$args= $_GET['args'];
		if (empty($cmd)){
			echo 'Please fill in a command first!';
		}else{
			
			if (empty($args))
			{
				$args = "#NONE#";
			}
			echo "You gave me : \"$cmd   $args\", right?<br>";
			connect($cmd,$args);
		}
	
		
	}
?>
