import collection.JavaConversions._
import twitter4j.TwitterFactory
import twitter4j.auth.AccessToken
import twitter4j.GeoLocation
import twitter4j.Query

trait TwitterInstance {
  val twitter = new TwitterFactory().getInstance
}
object TwitterGeo extends TwitterInstance {

  val AccessToken = "3081723986-5zmEga6Elx2rfDvNY3guqoYxm45KKweXC71lgSq";
  val AccessSecret = "bRI2mlIPMsKDImfR5lEIMh6xNddByTqXAIJw6n21vzY1a";
  val ConsumerKey = "KTTOXGbGubiBX5idcvEMkHgTl";
  val ConsumerSecret = "NOprOkWzdbuGCsrIcdXF7Mth8IAKzrxA4tiASKCYXgoflDd04u";


  def main(args: Array[String]) {

    //val twitter = new TwitterFactory().getInstance()
    twitter.setOAuthConsumer(ConsumerKey,ConsumerSecret)
    twitter.setOAuthAccessToken(new AccessToken(AccessToken,AccessSecret))
    var result = twitter.search(new Query().geoCode(new GeoLocation(35.144345,33.411364),50, "km"))
    var tweets = result.getTweets()
    tweets.foreach(status => println(status.getText + "\n"))

  }
}