package com.sparkteam.restapi
import java.io.File
import java.nio.charset.StandardCharsets
import spray.http.HttpHeaders._
import org.apache.commons.io.FileUtils
import akka.actor.Actor
import spray.routing._
import spray.http._
import MediaTypes._

// we don't implement our route structure directly in the service actor because
// we want to be able to test it independently, without having to spin up an actor
class MyServiceActor extends Actor with MyService {

  // the HttpService trait defines only one abstract member, which
  // connects the services environment to the enclosing actor or test
  def actorRefFactory = context

  // this actor only runs our route, but you could add
  // other things here, like request stream processing
  // or timeout handling
  def receive = runRoute(jsonroutes)
}


// this trait defines our service behavior independently from the service actor
trait MyService extends HttpService {

  val jsonroutes = {
    pathSingleSlash {
      get {
        respondWithMediaType(`text/html`) {
          complete {
            <html>
              <body>
                <h1>Say hello to <i>spray-routing</i> on <i>tomcat</i>!</h1>
              </body>
            </html>
          }
        }
      }
    } ~
    path("tags") {
      get {
        respondWithMediaType(`application/json`) {
		respondWithHeader(RawHeader("Access-Control-Allow-Origin","*")) {
          		complete {
            			val json = FileUtils.readFileToString(new File("/tmp/tags.json"), StandardCharsets.UTF_8)
            			json
          		}
        	}
	}
      }
    } ~
    path("geo") {
      get {
        respondWithMediaType(`application/json`) {
		respondWithHeader(RawHeader("Access-Control-Allow-Origin","*")) {          
			complete {
            			val json = FileUtils.readFileToString(new File("/tmp/geo.json"), StandardCharsets.UTF_8)
            			json
          	}
	   }
        }
      }
    }
  }
}
