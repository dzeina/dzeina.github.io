package com.sparkteam.spark

import java.io.File
import org.apache.spark.{Logging, SparkConf}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.ReceiverInputDStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import twitter4j.{Status, _}
import twitter4j.auth.{Authorization, NullAuthorization, OAuthAuthorization}
//import com.lambdaworks.jacks._
//import net.liftweb.json._
//import net.liftweb.json.Serialization.write
import org.json4s.native.Serialization.write
import org.json4s.DefaultFormats
import org.apache.commons.io.FileUtils


/** Bounding box to filter tweets by location. Units are degrees. */
case class BoundingBox(west: Double, south: Double, east: Double, north: Double)


object TwitterUti {
  def createStream(
    ssc: StreamingContext,
    twitterAuth: Option[Authorization],
    count: Int = 0,
    follow: Seq[Long] = Nil,
    track: Seq[String] = Nil,
    locations: Seq[BoundingBox] = Nil,
    storageLevel: StorageLevel = StorageLevel.MEMORY_AND_DISK_SER_2
  ): ReceiverInputDStream[Status] = {
    new TwitterInputDStream(ssc, twitterAuth, count, follow, track, locations, storageLevel)
  }
}

object popTags {

  val AccessToken = "222809371-cwLBQYQwlIjADkmT1U8J8SCGxDR9IIy7e2uwaXFs"
  val AccessSecret = "IZSXDK56qyJrOziNvSkMOAh9f6jo61gUeJGySbvgiWHVY"
  val ConsumerKey = "BUaTvDaDDIuMdzTyuKQFHomFM"
  val ConsumerSecret = "sWJ9N5L4JvEG4ExsU2LrJn1infoKJGW63ofNHYNh4RwvkqjYBt"

  def toStr(g: GeoLocation): Option[String] = {
    try {
      Some(g.getLatitude+","+g.getLongitude)
    } catch {
      // catch Exception to catch null 's'
      case e: Exception => None
    }
  }
  def main(args: Array[String]) {

    System.setProperty("twitter4j.oauth.consumerKey", ConsumerKey)
    System.setProperty("twitter4j.oauth.consumerSecret", ConsumerSecret)
    System.setProperty("twitter4j.oauth.accessToken", AccessToken)
    System.setProperty("twitter4j.oauth.accessTokenSecret", AccessSecret)

    val sparkConf = new SparkConf().setAppName("TwitterPopularTags").setMaster("local[2]")
    val ssc = new StreamingContext(sparkConf, Seconds(2))
    val count=0
    val follow = Seq(1L,2L,3L,4L)
    val filters = args.takeRight(args.length).toSeq
    //val locations = Seq((BoundingBox(34.35,32.25,35.42,34.35)))
    //val locations = Seq((BoundingBox(32.16,34.51,34.11,35.18)))
    val locations=Seq(BoundingBox(-77.330017,38.659188,-73.465576,41.010786))
    //val locations = Seq(BoundingBox(-180.0,-90.0,180.0,90.0))

    val storage = StorageLevel.MEMORY_AND_DISK_SER_2
    val authorization: Authorization = NullAuthorization.getInstance()
    val stream=TwitterUti.createStream(ssc,None, count, follow, filters, locations,storage)
    val hashTags=stream.flatMap(status => status.getText.toLowerCase().split(" ")).filter(_.startsWith("#")).filter(_.length>=4)
    val geoLocations=stream.flatMap(st => toStr(st.getGeoLocation))

    val topLocs=geoLocations.map((_,1)).reduceByKeyAndWindow(_ + _, Seconds(3600))
      .map{case (loc, loccount) => (loccount, loc)}
      .transform(_.sortByKey(false))

    val topCounts60 = hashTags.map((_, 1)).reduceByKeyAndWindow(_ + _, Seconds(3600))
      .map{case (topic, count) => (count, topic)}
      .transform(_.sortByKey(false))
    //Print popular hashtags

    topCounts60.foreachRDD(rdd => {
      val topList = rdd.take(10)
      println("\nPopular topics in last 60 seconds (%s total):".format(rdd.count()))
      topList.foreach{case (count, tag) => println("%s (%s tweets)".format(tag, count))}
      //val json = JacksMapper.writeValueAsString[Array[(Int,String)]](topList);
      implicit val formats = DefaultFormats
      val json = write(topList)
      FileUtils.writeStringToFile(new File("/tmp/tags.json"), json)
    })
    //Print popular locations topLocs
    topLocs.foreachRDD(rdd =>{
      val topLocationsList= rdd.take(10)
      println("\nPopular locations in last 60 seconds (%s total):".format(rdd.count()))
      topLocationsList.foreach{case (loccount,currloc) => println("%s (%s locations)".format(currloc,loccount))}
      //val json = JacksMapper.writeValueAsString[Array[(Int,String)]](topLocationsList);
      implicit val formats = DefaultFormats
      val json = write(topLocationsList)
      FileUtils.writeStringToFile(new File("/tmp/geo.json"), json)
    })

    ssc.start()
    ssc.awaitTermination()
  }
}
