package com.sparkteam.spark

import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.ReceiverInputDStream
import org.apache.spark.streaming.receiver.Receiver
import twitter4j.Status
import twitter4j.auth.{OAuthAuthorization, Authorization}
import twitter4j.conf.ConfigurationBuilder

class TwitterInputDStream(
                           @transient ssc_ : StreamingContext,
                           twitterAuth: Option[Authorization],
                           count: Int,
                           follow: Seq[Long],
                           track: Seq[String],
                           locations: Seq[BoundingBox],
                           storageLevel: StorageLevel
                           ) extends ReceiverInputDStream[Status](ssc_)  {

  private def createOAuthAuthorization(): Authorization = {
    new OAuthAuthorization(new ConfigurationBuilder().build())
  }

  private val authorization = twitterAuth.getOrElse(createOAuthAuthorization())

  override def getReceiver(): Receiver[Status] = {
    new TwitterReceiver(authorization, count, follow, track, locations, storageLevel)
  }
}
