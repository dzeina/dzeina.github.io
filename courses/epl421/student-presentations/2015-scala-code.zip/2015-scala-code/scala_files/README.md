Build and run spark module
-----
`sbt assembly`

~/Downloads/spark-1.3.1/bin/spark-submit --class "com.sparkteam.spark.popTags" target/scala-2.11/twitterExample-assembly-1.0.jar

Run Web Server
------

`sbt run`

and select `com.sparkteam.restapi.Boot` class

open `http://localhost:8080/tags` and `http://localhost:8080/geo` to test
