# sparkfront

This project is generated with [yo angular generator](https://github.com/yeoman/generator-angular)
version 0.11.1.

## Instructions
1. install nodejs

2. `npm install -g grunt-cli bower`

4. `npm install && bower install`

3. `grunt serve`
