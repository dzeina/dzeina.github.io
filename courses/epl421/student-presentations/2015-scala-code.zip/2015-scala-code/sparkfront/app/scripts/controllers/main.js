'use strict';

/**
 * @ngdoc function
 * @name sparkfrontApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sparkfrontApp
 */
angular.module('sparkfrontApp')
  .config(function($httpProvider){
    delete $httpProvider.defaults.headers.common['X-Requested-With'];
  })
  .controller('MainCtrl', function ($scope, $timeout, $http) {
    $scope.dataPoints=[];
    $scope.cyprus = {
      lat: 51.505,
      lng: -0.09,
      zoom: 3
    };

    $scope.layers = {
      baselayers: {
        osm: {
          name: 'OpenStreetMap',
          url: 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          type: 'xyz'
        },
        googleTerrain: {
          name: 'Google Terrain',
          layerType: 'TERRAIN',
          type: 'google'
        },
        googleHybrid: {
          name: 'Google Hybrid',
          layerType: 'HYBRID',
          type: 'google'
        },
        googleRoadmap: {
          name: 'Google Streets',
          layerType: 'ROADMAP',
          type: 'google'
        }
      }
    };
    var counter = 0;
    $scope.markers = {};
    var poll = function() {
      $timeout(function() {
        counter++;
        $scope.layers.overlays = {};
        $http.get('http://localhost:8080/geo').
          success(function(data) {
            var points = [];
            _.forEach(data, function(item, i){
              if (item && item._1 && item._2) {
                var mypoint = [];
                var loc = item._2.split(',');
                mypoint.push(parseFloat(loc[0]));
                mypoint.push(parseFloat(loc[1]));
                mypoint.push(item._1);
                points.push(mypoint);
                //$scope.markers[i+'m'] = {
                //  lat: mypoint[0],
                //  lng: mypoint[1],
                //  message: "Count: "+item._1
                //}
              }
            });
            $scope.layers.overlays = {
              "heatmap": {
                "name": "Heat Map"+Date.now(),
                "type": "webGLHeatmap",
                data: points,
                "visible": true
              }
            };
          });
        poll();
      }, 4000);
    };
    poll();
    var poll2 = function() {
      $timeout(function() {
        $http.get('http://localhost:8080/tags').
          success(function(data) {
            $scope.tags = data;
          });
        poll2();
      }, 2000);
    };
    poll2();

  });
