'use strict';

/**
 * @ngdoc function
 * @name sparkfrontApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the sparkfrontApp
 */
angular.module('sparkfrontApp')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
