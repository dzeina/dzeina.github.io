'use strict';

/**
 * @ngdoc overview
 * @name sparkfrontApp
 * @description
 * # sparkfrontApp
 *
 * Main module of the application.
 */
angular
  .module('sparkfrontApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'leaflet-directive'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
