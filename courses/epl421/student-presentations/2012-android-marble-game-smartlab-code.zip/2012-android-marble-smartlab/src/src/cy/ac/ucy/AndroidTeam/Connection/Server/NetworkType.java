package cy.ac.ucy.AndroidTeam.Connection.Server;


public enum NetworkType {
	Client, Server, Unknown

}
