
package cy.ac.ucy.AndroidTeam.Game;



import java.net.UnknownHostException;

import org.andengine.engine.Engine;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.extension.multiplayer.protocol.util.WifiUtils;
import org.andengine.ui.activity.BaseGameActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.AsyncTask.Status;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import cy.ac.ucy.AndroidTeam.R;
import cy.ac.ucy.AndroidTeam.Connection.Server.NetworkType;
import cy.ac.ucy.AndroidTeam.Connection.Server.PHPServerConnection;





public class ChooseOpponent extends BaseGameActivity
{

	// ===========================================================
	// Constants
	// ===========================================================

	private App						app;

	private static final String			TAG					= "AndEngine";


	private Camera						mCamera;

//	private Engine						mEngine;

	private EngineOptions				mEngineOptions;

	private boolean					isUserEnrolled;



	private SharedPreferences			mPlayerPreferences;

	//private SharedPreferences.Editor		mPlayerPreferencesEditor;

	//private UsersOnlineRefresherService	updaterService;

	private UsersOnlineInitializerReceiver	usersOnlineInitializerReceiver;

	private UserHasPickedOpponentReceiver	userHasPickedOpponentReceiver;

	private OpponentHasPickedMeReceiver	opponentHasPickedMeReceiver;

	/** Shows the online users */
	private static AlertDialog			showOnlineUsersListViewDialog;

	private AlertDialog.Builder			builder;

	private ListView					onlineUsersListView;

	private AlertDialog					opponentAlert;

	/** To force the phone stay awake all the time */
	protected PowerManager.WakeLock		mWakeLock;

	public boolean						alreadyPickedByOpponent	= false;

	private ProgressDialog				phpTasksProgressDialog;


	private DoPHP_Tasks					doPHP_Tasks;


	// @formatter:off
	private Runnable	mRunMultiplayerGame	= new Runnable() {

		public void run() {
				Intent myIntent = new Intent(ChooseOpponent.this, MultiplayerGame.class);
				// Launch the intent
				ChooseOpponent.this.startActivity(myIntent);
			}
	};
	// @formatter:on



	@Override
	public EngineOptions onCreateEngineOptions() {

		/** Make the screen stay active */
		final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		this.mWakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK,
				TAG);
		this.mWakeLock.acquire();

		doPHP_Tasks = new DoPHP_Tasks();

		app = (App) getApplication();

		phpTasksProgressDialog = ProgressDialog.show(ChooseOpponent.this,
				"Connecting to Server",
				"Please wait...");

		phpTasksProgressDialog.setCancelable(true);

		phpTasksProgressDialog.show();

		phpTasksProgressDialog.setOnCancelListener(
				new OnCancelListener() {

					@Override
					public void onCancel(DialogInterface dialog) {
						if (doPHP_Tasks != null)
							doPHP_Tasks.cancel(true);
						destroyService();
						unregisterReceivers();
						finish();


					}
				});


		this.mCamera = new Camera(0, 0, App.CAMERA_WIDTH, App.CAMERA_HEIGHT);


		this.mEngineOptions = new EngineOptions(true,
				ScreenOrientation.LANDSCAPE_FIXED,
				new RatioResolutionPolicy(App.CAMERA_WIDTH,
						App.CAMERA_HEIGHT),
				this.mCamera);


		this.mEngine = new Engine(mEngineOptions);

		mPlayerPreferences = PreferenceManager
				.getDefaultSharedPreferences(this);



		// Register & Initialize Receivers
		initializeReceivers();
		registerReceivers();

		// Create the URL's needed for the script, based on Users
		// choses Server
		// Server List(Host of PHP's):
		// Ucy Students Profile Server
		// 1FreeHost server
		setAllUrlsNeeded();

		// Execute an Async Task in Background
		doPHP_Tasks.execute();

		return this.mEngineOptions;
	}





	/**
	 * Puts all online users to list
	 * 
	 * @param pUser
	 *             who will see all online users, except himself
	 */
	private void getOnlineUsersToList(final User pUser) {


		// Build an alert dialog
		builder = new AlertDialog.Builder(this);
		builder.setTitle("Pick your opponent");


		// The list with the online users
		onlineUsersListView = new ListView(this);

		onlineUsersListView.destroyDrawingCache();
		onlineUsersListView.setVisibility(ListView.INVISIBLE);
		onlineUsersListView.setVisibility(ListView.VISIBLE);


		// Put users using our customized Adapter (UserAdapter)
		UserAdapter userAdapter = new UserAdapter(this,
				R.layout.opponent_row,
				PHPServerConnection.getOnlineUsers());


		// Set adapter to the list view

		onlineUsersListView.setAdapter(userAdapter);

		// We want to get the opponents data from th
		onlineUsersListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int pos, long id) {

				// User picked up opponent: Set Servers Opponent
				app.setOpponent((User) (onlineUsersListView
						.getItemAtPosition(pos)));

				// Send a broadcast!
				sendBroadcast(new Intent(App.REC_USERS_HAS_PICKED_OPPONENT));


			}
		});






		builder.setView(onlineUsersListView);

		builder.setNegativeButton(R.string.buttonCancelRefreshingUsersOnline,
				new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						ChooseOpponent.this.destroyService();
						ChooseOpponent.this.onGameDestroyed();
						System.exit(0);

					}
				});

		DisplayMetrics metrics = new DisplayMetrics();
		this.getWindowManager().getDefaultDisplay().getMetrics(metrics);
		int screenX = metrics.widthPixels;
		int screenY = metrics.heightPixels;



		// if existed before, dismiss it
		if (showOnlineUsersListViewDialog != null){
			showOnlineUsersListViewDialog.dismiss();
		}

		// Create and show the dialog
		showOnlineUsersListViewDialog = builder.create();



		// Dismiss wait PHP Dialog
		// if (app.getWaitForPHPsDialog().isShowing())
		// app.getWaitForPHPsDialog().dismiss();

		showOnlineUsersListViewDialog.show();



		showOnlineUsersListViewDialog
				.setOnCancelListener(new OnCancelListener() {

					@Override
					public void onCancel(DialogInterface dialog) {
						destroyService();
						unregisterReceivers();
						finish();

					}
				});

		// Dynamically adjust Dialogs size, according to mobile devices
		// screen size
		showOnlineUsersListViewDialog.getWindow().setLayout(
				screenX / 7 * 6, screenY / 10 * 9);

		userAdapter.notifyDataSetChanged();


	}







	@Override
	public void onCreateResources(
			OnCreateResourcesCallback pOnCreateResourcesCallback)
			throws Exception {







		pOnCreateResourcesCallback.onCreateResourcesFinished();

	}





	@Override
	public void onCreateScene(OnCreateSceneCallback pOnCreateSceneCallback)
			throws Exception {

		// this.mEngine.registerUpdateHandler(new FPSLogger());
		/** Our scene */
		final Scene scene = new Scene();
		// Change background
		scene.setBackground(new Background(0.415686275f, 0.352941176f,
				0.803921569f, 0.0f));

		pOnCreateSceneCallback.onCreateSceneFinished(scene);
	}





	/**
	 * */
	@Override
	public void onPopulateScene(Scene pScene,
			OnPopulateSceneCallback pOnPopulateSceneCallback)
			throws Exception {








		pOnPopulateSceneCallback.onPopulateSceneFinished();
	}






	// /////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////
	// ///////////////// Overrides /////////////////
	// /////////////////////////////////////////////////////////////////////


	@Override
	public synchronized void onResumeGame() {
		super.onResumeGame();
		// Register receivers
		registerReceivers();


	}





	@Override
	public synchronized void onPauseGame() {
		super.onPauseGame();
		// Unregister the receiver
		unregisterReceivers();

	}





	@Override
	protected void onStop() {
		super.onStop();
		// Unregister the receiver
		unregisterReceivers();


	}









	@Override
	protected void onDestroy() {
		this.mWakeLock.release();
		destroyService();

		super.onDestroy();

	}





	// /////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////
	// ///////////////// Methods /////////////////
	// /////////////////////////////////////////////////////////////////////


	/**
	 * Set all URLs needed and saves then in our app
	 */
	private void setAllUrlsNeeded() {
		this.saveInAppURLfullRefresh();
		this.saveInAppURLopponentChecker();
		this.saveInAppURLremoveOpponent();
		this.saveInAppURLuserOnline();
		this.saveInAppURLusersEnrollment();
		this.saveInAppURLwriteOpponent();
		this.saveInAppURLcleanUsersOnline();

	}





	/** Clean Users Online URL */
	public void saveInAppURLcleanUsersOnline() {

		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");

		App.setmURLCleanUsersOnline(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "clean.php");

	}





	/** Users Online URL */
	public void saveInAppURLuserOnline() {

		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");


		app.setmURLusersOnline(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "usersOnline");

	}





	/** Full Refresh URL */
	public void saveInAppURLfullRefresh() {
		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");

		app.setmURLfullRefresh(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "fullrefresh.php");



	}





	/** Main Script URL */
	public void saveInAppURLusersEnrollment() {

		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");

		app.setmURLusersEnrollment(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "php1.php");

	}





	/** Get Write Opponent Script URL */
	public void saveInAppURLwriteOpponent() {
		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");

		app.setmURLwriteOpponent(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "writeOpponent.php");

	}





	/** Get Remove Opponent Script URL */
	public void saveInAppURLremoveOpponent() {
		//
		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");


		app.setmURLremoveOpponent(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "removeOpponent.php");

	}





	/** Get Remove Opponent Script URL */
	public void saveInAppURLopponentChecker() {
		//
		String server = this.mPlayerPreferences.getString(
				App.PREFS_MAIN_PLAYER_PREFERRED_SERVER,
				"wrong.server");


		app.setmURLopponentChecker(App.HTTP_TAG + server
				+ App.PHP_PATH_TO_SCRIPT + "opponents/");

	}





	private void destroyService() {

		// Dismis waiting first contact to server(first refresh)
		if (phpTasksProgressDialog.isShowing())
			phpTasksProgressDialog.dismiss();

		// Dismiss dialog first
		if (showOnlineUsersListViewDialog != null)
			showOnlineUsersListViewDialog.dismiss();
		Log.d(TAG, "Service Destroyed!");
		stopService(new Intent(this, UsersOnlineRefresherService.class));


	}





	/** ignore back button??? */
	@Override
	public boolean onKeyUp(final int pKeyCode, final KeyEvent pEvent) {
		switch (pKeyCode) {
			case KeyEvent.KEYCODE_BACK:
				this.finish();
				return true;
		}
		return super.onKeyUp(pKeyCode, pEvent);
	}











	/** unregister all receivers */
	private void unregisterReceivers() {

		try{

			if (usersOnlineInitializerReceiver != null){
				unregisterReceiver(usersOnlineInitializerReceiver);
				usersOnlineInitializerReceiver = null;
			}

			if (userHasPickedOpponentReceiver != null){
				unregisterReceiver(userHasPickedOpponentReceiver);
				userHasPickedOpponentReceiver = null;
			}

			if (opponentHasPickedMeReceiver != null){
				unregisterReceiver(opponentHasPickedMeReceiver);
				opponentHasPickedMeReceiver = null;
			}
		}

		catch (IllegalArgumentException e){
			// Receivers weren't registered
			// Do nothing
		}

	}





	private void initializeReceivers() {

		usersOnlineInitializerReceiver = new UsersOnlineInitializerReceiver();
		userHasPickedOpponentReceiver = new UserHasPickedOpponentReceiver();
		opponentHasPickedMeReceiver = new OpponentHasPickedMeReceiver();
	}





	/** Register all receivers */
	private void registerReceivers() {


		try{

			registerReceiver(usersOnlineInitializerReceiver,
					new IntentFilter(App.REC_USERS_ONLINE_INITIALIZED));

			registerReceiver(userHasPickedOpponentReceiver,
					new IntentFilter(App.REC_USERS_HAS_PICKED_OPPONENT));

			registerReceiver(opponentHasPickedMeReceiver,
					new IntentFilter(App.REC_OPPONENT_HAS_PICKED_ME));
		}
		catch (IllegalArgumentException e){
			// Receivers were already registered
			// Do nothing
		}

	}








	/**
	 * @param opponent
	 */
	private void createOpponentConfirmationDialog(User opponent) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(
				opponent.getmUserGame()
						+ " wants to play with you. Do you?")

				.setCancelable(true)

				.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int id) {
								// Delete the battle from cloud, so wont
								// be
								// notified again
								PHPServerConnection.removeOpponent(app
										.getUser());
								// User has accepted, and will be client
								// In that case user will be client,
								// will start to
								// communicate with server
								app.setUserAccepted(true);
								app.setUserNetworkType(NetworkType.Client);

								// Create client with START GAME REPLY
								// Starting MultiPlayer Game
								finish();
								app.getmHandler().post(
										mRunMultiplayerGame);
							}

						}



				)
				.setNegativeButton("No", new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// Delete the battle from cloud, so wont be
						// notified again
						PHPServerConnection.removeOpponent(app.getUser());
						// User declined and will be client
						// In that case user will be client, and send the
						// negative
						// answer to the server, who will wait for users
						// reply
						app.setUserAccepted(false);
						app.setUserNetworkType(NetworkType.Client);


						// Starting MultiPlayer Game
						finish();

						app.getmHandler().post(mRunMultiplayerGame);


					}
				});


		builder.setOnCancelListener(new OnCancelListener() {

			@Override
			public void onCancel(DialogInterface dialog) {

				// Delete the battle from cloud
				PHPServerConnection.removeOpponent(app.getUser());

			}
		});


		opponentAlert = builder.create();

		opponentAlert.show();
	}




	/**
	 * Async Task that executes all the PHP Scripts required so the User is
	 * enrolled to Online Users cloud file. Also this resolves problems of ""
	 * 
	 * 
	 * @author paschalis
	 * 
	 */
	public class DoPHP_Tasks extends
			AsyncTask<Object, Object, Object> {

		@Override
		protected void onCancelled() {
			super.onCancelled();
			// Dismiss waiting dialog
			if (phpTasksProgressDialog.isShowing())
				phpTasksProgressDialog.dismiss();
		}





		@Override
		protected void onPostExecute(Object result) {
			super.onPostExecute(result);

		}





		@Override
		protected Object doInBackground(Object... params) {



			User user = null;
			String userLocalIP = "";

			try{

				userLocalIP = WifiUtils
						.getWifiIPv4Address(ChooseOpponent.this);

			}
			catch (UnknownHostException e){
				// Failed to get local IP
				e.printStackTrace();
			}


			String usersEmail = mPlayerPreferences.getString(
					App.PREFS_MAIN_PLAYER_GOOG_ACCOUND_LIST_PREF, "");
			String usersUsergame = mPlayerPreferences.getString(
					App.PREFS_MAIN_PLAYER_USERGRAME, "");

			// Contains basic info: Usergame, GMail, and Local IP
			user = new User(usersUsergame, usersEmail, userLocalIP);

			if (usersUsergame.equals("") || usersEmail.equals("")
					|| userLocalIP.equals("")){
				Log.e(TAG, "Preferences or Local IP Detection Error");
			}

			isUserEnrolled = false;




			// Run the PHP Scripts
			switch (PHPServerConnection
					.fullRefresh(user)) {
				case SUCCESS:
					// Successfully refreshed the online users
					Log.i(TAG, "Successfully refreshed");


					switch (PHPServerConnection
							.enrollUserToUsersOnline(user)) {
						case SUCCESS:
							Log.i(TAG,
									"User's uniq record have successfully enroled");
							isUserEnrolled = true;
							break;
						case NOT_UNIQ_RECORD:
							Log.d(TAG, "Users Record exists in Server");
							isUserEnrolled = true;
							break;
						case FAILURE_WHILE_PROCESSING_TEXT:
							Log.d(TAG,
									"Failure while processing in Server");
							// In this case, something messed up, so run
							// clean
							PHPServerConnection
									.cleanUsersOnline(App
											.getmURLCleanUsersOnline());

							break;
						case FAILURE:
							Log.d(TAG,
									"Failure while processing in Server");

							break;
						default:
							Log.d(TAG, "Failed to enroll User in Server");
							break;
					}


					break;
				case FAILURE:
					// If we have a network connection means server is down
					if (PHPServerConnection
							.haveNetworkConnection(getApplicationContext())){
						Log.e(TAG,
								"Internal error occured. Try again later.");
						// Print a toast message
						// MultiplayerConnect.this.unregisterReceivers();
						// MultiplayerConnect.this.finish();
					}
					else{

						// We managed to have internet connection before
						// entering this Activity
						// What a Terrible Failure log
						Log.wtf(TAG,
								"Again, no internet connection. Exiting");
						// MultiplayerConnect.this.unregisterReceivers();
						// MultiplayerConnect.this.finish();

					}


				default:
					break;
			}


			// User has successfully enrolled
			if (isUserEnrolled){

				// Set the user to the app, so service can find it
				app.setUser(user);
				// Start the Service to collect Online Users
				startService(new Intent(ChooseOpponent.this,
						UsersOnlineRefresherService.class));


			}
			else
			{
				Log.d(TAG, "Failed to enroll User in Server");
				// Print a toast message
				ChooseOpponent.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						Toast.makeText(
								ChooseOpponent.this,
								"Failed to enroll User in Server\n"
										+ "Try again later",
								Toast.LENGTH_LONG).show();
					}
				});




				ChooseOpponent.this.destroyService();
				ChooseOpponent.this.unregisterReceivers();
				ChooseOpponent.this.finish();

			}



			return null;
		}

	}










	/**
	 * Inner Class: We set a broadcast receiver for the OnlineUsers Initializer
	 * we use the most appropriate way to get notified
	 * 
	 * @author paschalis
	 * 
	 */
	public class UsersOnlineInitializerReceiver extends BroadcastReceiver {


		@Override
		public void onReceive(Context context, Intent intent) {


			// Download new data from Server
			getOnlineUsersToList(ChooseOpponent.this.app.getUser());


			// Dismiss wait PHP Dialog
			if (phpTasksProgressDialog.isShowing())
				phpTasksProgressDialog.dismiss();
		}

	}




	/**
	 * Inner Class: We set a broadcast receiver for the decision of user to
	 * pick up opponent
	 * 
	 * @author paschalis
	 * 
	 */
	public class UserHasPickedOpponentReceiver extends BroadcastReceiver {


		@Override
		public void onReceive(Context context, Intent intent) {

			// Send a "magical" notification to opponent
			PHPServerConnection.writeOpponent(app.getUser(),
					app.getOpponent());


			// Stop the service
			destroyService();


			// If PHP Async Task Runs, terminate it!
			if (doPHP_Tasks.getStatus() != Status.FINISHED)
				doPHP_Tasks.cancel(true);



			app.setUserNetworkType(NetworkType.Server);

			// Starting the Multiplayer Game
			finish();
			app.getmHandler().post(mRunMultiplayerGame);

		}
	}









	/**
	 * Inner Class: We set a broadcast receiver whether another user has chosen
	 * this user, to play game with
	 * 
	 * @author paschalis
	 * 
	 */
	public class OpponentHasPickedMeReceiver extends BroadcastReceiver {


		@Override
		public void onReceive(Context context, Intent intent) {


			if (!alreadyPickedByOpponent){

				// Stop the service
				destroyService();

				// Start the new Activity
				createOpponentConfirmationDialog(App.tempOpponent);

				// Save that public temporary opponent,
				// To clients field, in Application
				app.setOpponent(App.tempOpponent);

				alreadyPickedByOpponent = true;
			}





		}

	}









}
