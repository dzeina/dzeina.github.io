
package cy.ac.ucy.AndroidTeam.Game;



/**
 * The user that will play the game
 * 
 * @author paschalis
 * 
 */
public class User {

	/** Usergame of user */
	private String	mUserGame;

	/** Gmail of user */
	private String	mGmail;



	private String	mTimestamp;

	/** External IP Address of user */
	private String	mExternalIP;

	/** Local IP of user */
	private String	mLocalIP;





	public User() {

	}





	/**
	 * User Constructor
	 * 
	 * @param pUsergame
	 *             of user
	 * @param pGmail
	 *             of user
	 */
	public User(String pUsergame, String pGmail, String pLocalIP) {
		this.mUserGame = pUsergame;
		this.mGmail = pGmail;
		this.mLocalIP = pLocalIP;
	}





	/**
	 * User Full Constructor
	 * 
	 * @param pUsergame
	 *             of user
	 * @param pGmail
	 *             of user
	 * @param pIP
	 *             of user
	 * @param pTime
	 *             in milliseconds from 1970 that user has enrolled himself to
	 *             Users Online Cloud File
	 */
	public User(String pUsergame, String pGmail, String pExternalIP,
			String pLocalIP, String pTime) {
		this.mUserGame = pUsergame;
		this.mGmail = pGmail;
		this.setmExternalIP(pExternalIP);
		this.setmLocalIP(pLocalIP);
		this.setmTimestamp(pTime);
	}





	public String getmUserGame() {
		return mUserGame;
	}





	public void setmUserGame(String mUserGame) {
		this.mUserGame = mUserGame;
	}





	public String getmGmail() {
		return mGmail;
	}





	public void setmGmail(String mGmail) {
		this.mGmail = mGmail;
	}








	public String getmTimestamp() {
		return mTimestamp;
	}





	public void setmTimestamp(String mTimestamp) {
		this.mTimestamp = mTimestamp;
	}





	public String getmExternalIP() {
		return mExternalIP;
	}





	public void setmExternalIP(String mExternalIP) {
		this.mExternalIP = mExternalIP;
	}





	public String getmLocalIP() {
		return mLocalIP;
	}





	public void setmLocalIP(String mLocalIP) {
		this.mLocalIP = mLocalIP;
	}





}
