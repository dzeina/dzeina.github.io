
package cy.ac.ucy.AndroidTeam.Connection.Server;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;

import org.andengine.extension.multiplayer.protocol.util.WifiUtils;

import cy.ac.ucy.AndroidTeam.Game.App;
import cy.ac.ucy.AndroidTeam.Game.User;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.text.format.DateUtils;
import android.util.Log;







/**
 * @author paschalis
 * 
 */
/**
 * @author paschalis
 *
 */
/**
 * @author paschalis
 * 
 */
public class PHPServerConnection {

	private static final String		TAG	= PHPServerConnection.class
											.getSimpleName();


	/** A Buffered Reader of the Online Users Cloud File */
	private static BufferedReader		usersOnlineBuffer;



	/** Array List of the Online Users information */
	private static ArrayList<User>	mOnlineUsers;





	/**
	 * @return the External IP, using whatismyip.com script
	 */
	private static String getUsersIP() {

		URL whatismyip;
		try{
			whatismyip = new URL(
					"http://automation.whatismyip.com/n09230945.asp");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					whatismyip.openStream()));

			// Save IP as a string
			return in.readLine();


		}
		catch (Exception e){
			return null;
		}


	}





	/**
	 * @param context
	 *             our application context
	 * @return true if data connectivity is enabled
	 */
	public static boolean haveNetworkConnection(Context context) {
		ConnectivityManager connectivity = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null){
			NetworkInfo[] info = connectivity.getAllNetworkInfo();
			if (info != null){
				for (int i = 0; i < info.length; i++){
					if (info[i].getState() == NetworkInfo.State.CONNECTED){ return true; }
				}
			}
		}
		return false;
	}





	/**
	 * @param pStringURL
	 *             the URL to open it
	 * @return message if connection was okay or not
	 */
	private static PHPMessages requestURL(String pStringURL) {



		URL url = null;

		HttpURLConnection conn = null;
		/* Open URL connection */
		try{

			// Create new URL to the String given
			url = new URL(pStringURL);

			// Try to open connection
			conn = (HttpURLConnection) url.openConnection();

			// If connection opened successfully
			if (conn.getResponseCode() == HttpURLConnection.HTTP_OK){

				return PHPMessages.SUCCESS;

			}
			else{
				return PHPMessages.FAILURE;

			}


		}
		catch (IOException e){
			return PHPMessages.FAILURE;
		}


	}





	/**
	 * @param user
	 *             the user will perform the refresh
	 * @return message about the operation succession
	 */
	public static PHPMessages fullRefresh(User user) {

		// Build the URL
		String fullRefreshRunURL;
		fullRefreshRunURL = App.getmURLfullRefresh() + "?"
				+ App.PHP_EMAIL_TAG + user.getmGmail() +
				"&" + App.PHP_USERGAME_TAG + user.getmUserGame() +
				"&" + App.PHP_LOCAL_IP_TAG + user.getmLocalIP();
		
	

		return requestURL(fullRefreshRunURL);


	}







	/**
	 * 
	 * Builds the String to the file that user is waiting for opponents to
	 * challenge him
	 */
	private static String getBattleRequestsFile(User pUser) {


		// Build the URL
		String fullCheckForBattlesFILEURL;

		fullCheckForBattlesFILEURL = App.getmURLopponentChecker()
				+ pUser.getmUserGame() + "_" + pUser.getmGmail();


		return fullCheckForBattlesFILEURL;
	}









	/**
	 * Writes a file on server, to inform the opponent that user has selected
	 * him
	 * 
	 * @param user
	 *             The user will choose its opponent
	 * @param opponent
	 *             The opponent chosen
	 * @return message about the operation succession
	 */
	public static PHPMessages writeOpponent(User user, User opponent) {


		// Build the URL
		String fullWriteOpponentUrl;
		fullWriteOpponentUrl = App.getmURLwriteOpponent() + "?"
				+ App.PHP_MY_USERGAME + user.getmUserGame() +
				"&" + App.PHP_MY_GMAIL + user.getmGmail() +
				"&" + App.PHP_OPP_USER + opponent.getmUserGame() +
				"&" + App.PHP_OPP_GMAIL + opponent.getmGmail();

		return requestURL(fullWriteOpponentUrl);
	}








	public static PHPMessages removeOpponent(User opponent) {


		// Build the URL
		String fullRemoveOpponentUrl;
		fullRemoveOpponentUrl = App.getmURLremoveOpponent() + "?"
				+ App.PHP_OPP_USER + opponent.getmUserGame() +
				"&" + App.PHP_OPP_GMAIL + opponent.getmGmail();
		

		return requestURL(fullRemoveOpponentUrl);
	}






	/**
	 * Opens the users online cloud file
	 * 
	 * @return a message about the attemp to open the Users Online Cloud File
	 */
	private static PHPMessages openUsersOnlineUsersFile() {

		// Create a URL for the desired page
		URL url;
		try{
			url = new URL(App.getmURLusersOnline());

			usersOnlineBuffer = new BufferedReader(new InputStreamReader(
					url.openStream()));


		}
		catch (MalformedURLException e){
			// Print error log
			Log.e(TAG, e.toString());


			return PHPMessages.FAILURE;
		}
		catch (IOException e){
			// Print error log
			return PHPMessages.FAILURE;
		}

		// Correct
		return PHPMessages.SUCCESS;
	}








	/**
	 * Opens the users online cloud file of the battle of specific user, if
	 * exist
	 * 
	 * @return a message about the attemp to open the Users Online Cloud File
	 */
	public static PHPMessages openUsersBattlesFile(User pUser) {

		BufferedReader battleRequests;

		// Create a URL for the desired page
		URL url;
		try{
			url = new URL(getBattleRequestsFile(pUser));

			battleRequests = new BufferedReader(new InputStreamReader(
					url.openStream()));


		}
		catch (MalformedURLException e){
			// Print error log
			Log.e(TAG, e.toString());


			return PHPMessages.FAILURE;
		}
		catch (IOException e){
			// Print error log
			return PHPMessages.FAILURE;
		}

		String strOpponentsUsergame;
		String strOpponentsGmail;

		try{

			// Get Opponents data
			if (((strOpponentsUsergame = battleRequests.readLine()) != null)
					&& ((strOpponentsGmail = battleRequests.readLine()) != null)){
				

				for (User iUser : mOnlineUsers){
					if(iUser.getmGmail().equals(strOpponentsGmail))
						if(iUser.getmUserGame().equalsIgnoreCase(strOpponentsUsergame)){
							App.tempOpponent=iUser;
							
							return PHPMessages.OPPONENT_FOUND;
						}
				}
				
				
				Log.i(TAG, "Opponent found, but doesnt exists in Online Users");
				return PHPMessages.OPPONENT_FOUND_BUT_DOESNT_EXISTS_IN_ONLINE_USERS;
				
				
			}
			else{
				return PHPMessages.OPPONENTS_FILE_IS_WRONG;
			}


		}
		catch (IOException e){
			return PHPMessages.FAILURE_WHILE_PROCESSING_TEXT;
		}


	}







	/**
	 * @param strUsergame
	 *             usergame
	 * @return NOT_UNIQ_RECORD, NOT_UNIQ_IP, FAILURE_WHILE_PROCESSING_TEXT,
	 *         UNIQ_RECORD
	 */
	private static PHPMessages isUniqueRecord(String pUsergame, String pEmail,
			String pLocalIP) {

		// Open Online Users Cloud file
		openUsersOnlineUsersFile();

		String strTime;
		String strExternalIP;
		String strLocalIP;
		String strEmail;
		String strUsergame;


		// Get the users IP Address
		String userIp = getUsersIP();

		// Failed to retreive ip
		if (userIp == null) return PHPMessages.FAILURE;



		try{

			// Get users IP

			while (((strTime = usersOnlineBuffer.readLine()) != null)
					&& ((strExternalIP = usersOnlineBuffer.readLine()) != null)
					&& ((strLocalIP = usersOnlineBuffer.readLine()) != null)
					&& ((strEmail = usersOnlineBuffer.readLine()) != null)
					&& ((strUsergame = usersOnlineBuffer.readLine()) != null)){

				// If the IP is the same, return
				// One player per device is allowed!

				// With different IP, but same gmail & usergame
				// means the whole record is the same
				if (strEmail.equals(pEmail)
						&& strExternalIP.equals(userIp)
						&& strLocalIP.equals(pLocalIP)
						&& strUsergame.equals(pUsergame)){
					// Not unique record
					return PHPMessages.NOT_UNIQ_RECORD;
				}


			}
		}
		catch (IOException e){
			return PHPMessages.FAILURE_WHILE_PROCESSING_TEXT;
		}


		return PHPMessages.UNIQ_RECORD;
	}







	/**
	 * @param user
	 *             All user information needed, as passed to this method
	 */
	public static PHPMessages enrollUserToUsersOnline(User user) {
		/** Message about the uniqueness of user */
		PHPMessages msg = isUniqueRecord(user.getmUserGame(),
				user.getmGmail(), user.getmLocalIP());

		switch (msg) {
		// If user is a uniq record, save it to Online Users
			case UNIQ_RECORD:


				// Build the URL
				String fullRunURL;
				fullRunURL = App.getmURLusersEnrollment() + "?"
						+ App.PHP_EMAIL_TAG + user.getmGmail() +
						"&" + App.PHP_USERGAME_TAG + user.getmUserGame() +
						"&" + App.PHP_LOCAL_IP_TAG + user.getmLocalIP();


				// Run the PHP script, with the appropriate parameters
				// So user enrolls itself to onlineUsers
				// If we failed to enroll, return the failure
				msg = requestURL(fullRunURL);

				// Return the enrollment message!
				return msg;

			default:
				// User hasnt uniq record, or other error occured
				// return it
				return msg;
		}
	}






	/**
	 * Users by running this function, they manage to download all other
	 * available users, but also, the clean and maintain the cloud file of all
	 * users.
	 * 
	 * Also they update each time their timestamp, so they wont be
	 * "knocked out" after the 5 minutes passed.
	 * 
	 * @param user
	 *             the User that will download all other online users
	 * @return Message according to success or failure of this procedure
	 */
	public static PHPMessages downloadOnlineUsersData(User user) {
		PHPMessages msg;

		fullRefresh(user);



		// Refresh the list, so old opponents will be removed
		msg = requestURL(App.getmURLfullRefresh());
		if (msg != PHPMessages.SUCCESS) return msg;


		// Open Online Users Cloud file
		msg = openUsersOnlineUsersFile();
		if (msg != PHPMessages.SUCCESS) return msg;

		user.setmExternalIP(getUsersIP());


		String strTime;
		String strExternalIP;
		String strLocalIP;
		String strEmail;
		String strUsergame;



		try{
			// Find out users IP Address
			InetAddress userIp = InetAddress.getLocalHost();

			mOnlineUsers = new ArrayList<User>();

			while (((strTime = usersOnlineBuffer.readLine()) != null)
					&& ((strExternalIP = usersOnlineBuffer.readLine()) != null)
					&& ((strLocalIP = usersOnlineBuffer.readLine()) != null)
					&& ((strEmail = usersOnlineBuffer.readLine()) != null)
					&& ((strUsergame = usersOnlineBuffer.readLine()) != null)){


				// We make sure we get data for the player himself
				if (!((user.getmUserGame().equals(strUsergame))
						&& (user.getmGmail().equals(strEmail))
						&& (user.getmLocalIP().equals(strLocalIP))
						&& (user.getmExternalIP().equals(strExternalIP))))
				{

					// Convert the timestamp to Human Readable format

					User opponent = new User(strUsergame, strEmail,
							strExternalIP, strLocalIP,
							makeTimeStampHumanReadble(strTime));


					mOnlineUsers.add(opponent);

				}
			}
		}
		catch (IOException e){
			return PHPMessages.FAILURE;
		}

		return PHPMessages.SUCCESS;

	}






	/**
	 * @param pTimestamp
	 *             the time stamp given in seconds from 1/1/1970 (in PHP time
	 *             returns in seconds, so we convert it to millicents below) to
	 *             process it further
	 * @return humar readable format of date
	 */
	private static String makeTimeStampHumanReadble(String pTimestamp) {

		Long time = (new Long(pTimestamp) * 1000);
		CharSequence humansTime = DateUtils
				.getRelativeTimeSpanString(time);

		return humansTime.toString();
	}














	public static ArrayList<User> getOnlineUsers() {
		return mOnlineUsers;
	}





	public static void setOnlineUsers(ArrayList<User> onlineUsers) {
		PHPServerConnection.mOnlineUsers = onlineUsers;
	}





	public static void cleanUsersOnline(String pCleanURL) {
		//Clean the users online file
		requestURL(pCleanURL);
		
	}

}