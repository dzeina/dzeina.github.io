package cy.ac.ucy.AndroidTeam.Connection.Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.server.ServerMessage;


public class ServerSendGameLevel  extends ServerMessage implements
		ServerMessageFlags {

	/* Score of Server  */
	private int	mSelectedLevel;





	// Default constructor
	public ServerSendGameLevel() {

	}





	public ServerSendGameLevel(int pLvl) {
		this.setmSelectedLevel(pLvl);
	}








	/** Returns the flag of the level send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_SERVER_SEND_SELECTED_LEVEL;
	}





	/**
	 * Read the Level of Server
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {


		this.setmSelectedLevel(pDataInputStream.readInt());



	}





	/**
	 * Write the Level of Server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {

		pDataOutputStream.writeInt(mSelectedLevel);
	}





	public int getmSelectedLevel() {
		return mSelectedLevel;
	}





	public void setmSelectedLevel(int mSelectedLevel) {
		this.mSelectedLevel = mSelectedLevel;
	}













}