
package cy.ac.ucy.AndroidTeam.Game;



import java.util.ArrayList;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.util.Log;
import android.widget.Toast;
import cy.ac.ucy.AndroidTeam.R;





public class PlayerPreferences extends PreferenceActivity implements
		SharedPreferences.OnSharedPreferenceChangeListener
{


	private static final String	TAG	= PlayerPreferences.class
										.getSimpleName();

	private App				app;

	SharedPreferences			mPlayerPrefs;

	private Editor				mPlayerPrefsEditor;





	// SharedPreferences.Editor layerPrefsEditor;





	@Override
	protected void onCreate(Bundle icicle)
	{
		super.onCreate(icicle);

		// Set landscape orientation
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

		app = (App) getApplication();

		this.mPlayerPrefs = PreferenceManager
				.getDefaultSharedPreferences(this);

		this.mPlayerPrefsEditor = this.mPlayerPrefs.edit();



		// Load the dynamic preferences
		setPreferenceScreen(createPreferenceHierarchy());
		addPreferencesFromResource(R.xml.player_prefs);



		this.setTheme(R.style.marble_style2);

		getPreferenceManager().getSharedPreferences().
				registerOnSharedPreferenceChangeListener(this);






	}





	@Override
	protected void onResume()
	{
		super.onResume();
	}





	@Override
	protected void onDestroy()
	{
		// Unregister the listener for preferences changes
		getPreferenceManager().getSharedPreferences()
				.unregisterOnSharedPreferenceChangeListener(this);
		super.onDestroy();
	}





	@Override
	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
			String key)
	{

		Log.d(TAG, "Preferences Changed");
		// If user has set usergame
		if ((!this.mPlayerPrefs
				.getString(App.PREFS_MAIN_PLAYER_USERGRAME, "").equals(""))
				// User has choosen gmail
				&& (!this.mPlayerPrefs.getString(
						App.PREFS_MAIN_PLAYER_GOOG_ACCOUND_LIST_PREF, "")
						.equals(""))){

			this.mPlayerPrefsEditor.putBoolean(
					App.PREFS_MAIN_PLAYER_ALL_SET, true);
			this.mPlayerPrefsEditor.commit();
			Toast.makeText(this,
					"Preferences accepted.\nPress Back to continue",
					Toast.LENGTH_SHORT).show();

		}

		else
		{
			this.mPlayerPrefsEditor.putBoolean(
					App.PREFS_MAIN_PLAYER_ALL_SET, false);
			this.mPlayerPrefsEditor.commit();
			Log.d(TAG, "User hasnt chosen correctly preferences");

		}

	}





	/**
	 * 
	 * 
	 * 
	 * @return the Dynamically Created Preference Screen
	 * 
	 * 
	 * 
	 */
	private PreferenceScreen createPreferenceHierarchy() {

		// Create a Dynamic Preference Screen
		PreferenceScreen root = getPreferenceManager()
				.createPreferenceScreen(this);


		// // Dialog based preferences
		PreferenceCategory dialogBasedPrefCat = new PreferenceCategory(this);
		dialogBasedPrefCat.setTitle(R.string.prefs_please_choose_your_prefs);
		root.addPreference(dialogBasedPrefCat);

		// List preference About google accounts of user
		ListPreference googPref = new ListPreference(this);

		// Get the users Google Accounts
		ArrayList<String> gmailAccounds = app.getMgmailAccountsStr();

		CharSequence[] googEntries = (CharSequence[]) gmailAccounds
				.toArray(new CharSequence[gmailAccounds.size()]);


		CharSequence[] googValues = (CharSequence[]) gmailAccounds
				.toArray(new CharSequence[gmailAccounds.size()]);

		googPref.setEntries(googEntries);
		googPref.setEntryValues(googValues);

		googPref.setDialogTitle(R.string.prefs_choose_google_account);
		googPref.setKey(App.PREFS_MAIN_PLAYER_GOOG_ACCOUND_LIST_PREF);
		googPref.setTitle(R.string.prefs_google_accound);
		googPref.setSummary(R.string.prefs_choose_google_account);
		dialogBasedPrefCat.addPreference(googPref);


		// List preference about the server
		ListPreference listPref = new ListPreference(this);


		CharSequence[] serverURLentries = { "Ucy", "FreeHost", "HelioHost" };


		CharSequence[] serverURLentryValues = { App.PREF_PHP_UCY_CS_URL,
				App.PREF_PHP_FREE_HOSTING_URL, App.PREF_PHP_HELIO_HOST_URL };

		listPref.setEntries(serverURLentries);
		listPref.setEntryValues(serverURLentryValues);

		listPref.setDefaultValue(App.PREF_PHP_UCY_CS_URL);

		listPref.setDialogTitle(R.string.prefs_choose_server);
		listPref.setKey(App.PREFS_MAIN_PLAYER_PREFERRED_SERVER);
		listPref.setTitle(R.string.prefs_preferred_server);
		listPref.setSummary(R.string.prefs_summary_server);
		dialogBasedPrefCat.addPreference(listPref);

		return root;
	}








}
