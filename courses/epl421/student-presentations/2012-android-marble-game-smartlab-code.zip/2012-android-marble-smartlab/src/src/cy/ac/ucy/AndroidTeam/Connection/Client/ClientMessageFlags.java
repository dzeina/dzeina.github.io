
package cy.ac.ucy.AndroidTeam.Connection.Client;

import org.andengine.extension.multiplayer.protocol.adt.message.IMessage;



/**
 * @author paschalis
 * 
 * All flags of messages that client sends to server
 *
 */
public interface ClientMessageFlags {


	/* Connection Flags. */
	public static final short	FLAG_MESSAGE_CLIENT_CONNECTION_CLOSE		= Short.MIN_VALUE;

	public static final short	FLAG_MESSAGE_CLIENT_CONNECTION_ESTABLISH	= FLAG_MESSAGE_CLIENT_CONNECTION_CLOSE + 1;

	public static final short	FLAG_MESSAGE_CLIENT_CONNECTION_PING		= FLAG_MESSAGE_CLIENT_CONNECTION_ESTABLISH + 1;

	public static final short	FLAG_MESSAGE_CLIENT_SEND_COORDINATES		= FLAG_MESSAGE_CLIENT_CONNECTION_PING + 1;

	public static final short	FLAG_MESSAGE_CLIENT_SEND_CONNECTION_REPLY	= FLAG_MESSAGE_CLIENT_SEND_COORDINATES + 1;
	
	public static final short	FLAG_MESSAGE_CLIENT_SEND_SCORE	= FLAG_MESSAGE_CLIENT_SEND_CONNECTION_REPLY + 1;
	
	public static final short	FLAG_MESSAGE_CLIENT_SEND_FINISHED_LEVEL	= FLAG_MESSAGE_CLIENT_SEND_SCORE + 1;

}
