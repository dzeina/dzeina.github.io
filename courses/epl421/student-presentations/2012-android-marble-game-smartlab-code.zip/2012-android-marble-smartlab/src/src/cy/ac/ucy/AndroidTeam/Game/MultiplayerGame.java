package cy.ac.ucy.AndroidTeam.Game;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.ArrayList;

import org.andengine.engine.Engine;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.IEntity;
import org.andengine.entity.modifier.AlphaModifier;
import org.andengine.entity.modifier.IEntityModifier.IEntityModifierListener;
import org.andengine.entity.modifier.MoveModifier;
import org.andengine.entity.modifier.ParallelEntityModifier;
import org.andengine.entity.modifier.RotationModifier;
import org.andengine.entity.modifier.ScaleModifier;
import org.andengine.entity.modifier.SequenceEntityModifier;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.sprite.Sprite;
import org.andengine.entity.text.Text;
import org.andengine.extension.multiplayer.protocol.adt.message.IMessage;
import org.andengine.extension.multiplayer.protocol.adt.message.client.IClientMessage;
import org.andengine.extension.multiplayer.protocol.adt.message.server.IServerMessage;
import org.andengine.extension.multiplayer.protocol.client.IServerMessageHandler;
import org.andengine.extension.multiplayer.protocol.client.connector.ServerConnector;
import org.andengine.extension.multiplayer.protocol.client.connector.SocketConnectionServerConnector;
import org.andengine.extension.multiplayer.protocol.client.connector.SocketConnectionServerConnector.ISocketConnectionServerConnectorListener;
import org.andengine.extension.multiplayer.protocol.server.IClientMessageHandler;
import org.andengine.extension.multiplayer.protocol.server.SocketServer;
import org.andengine.extension.multiplayer.protocol.server.SocketServer.ISocketServerListener;
import org.andengine.extension.multiplayer.protocol.server.connector.ClientConnector;
import org.andengine.extension.multiplayer.protocol.server.connector.SocketConnectionClientConnector;
import org.andengine.extension.multiplayer.protocol.server.connector.SocketConnectionClientConnector.ISocketConnectionClientConnectorListener;
import org.andengine.extension.multiplayer.protocol.shared.SocketConnection;
import org.andengine.extension.multiplayer.protocol.util.MessagePool;
import org.andengine.extension.physics.box2d.PhysicsConnector;
import org.andengine.extension.physics.box2d.PhysicsFactory;
import org.andengine.extension.physics.box2d.PhysicsWorld;
import org.andengine.extension.physics.box2d.util.Vector2Pool;
import org.andengine.input.sensor.acceleration.AccelerationData;
import org.andengine.input.sensor.acceleration.IAccelerationListener;
import org.andengine.input.touch.TouchEvent;
import org.andengine.opengl.font.Font;
import org.andengine.opengl.font.FontFactory;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.bitmap.BitmapTexture;
import org.andengine.opengl.texture.region.ITextureRegion;
import org.andengine.opengl.texture.region.TextureRegionFactory;
import org.andengine.opengl.vbo.VertexBufferObjectManager;
import org.andengine.ui.activity.BaseGameActivity;
import org.andengine.util.adt.io.in.IInputStreamOpener;
import org.andengine.util.debug.Debug;
import org.andengine.util.modifier.IModifier;
import org.andengine.util.modifier.ease.EaseBounceOut;
import org.andengine.util.modifier.ease.EaseElasticIn;
import org.andengine.util.modifier.ease.EaseElasticInOut;
import org.andengine.util.modifier.ease.EaseElasticOut;
import org.andengine.util.modifier.ease.EaseQuadOut;
import org.xml.sax.Attributes;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Manifold;

import cy.ac.ucy.AndroidTeam.R;
import cy.ac.ucy.AndroidTeam.Connection.Client.ClientMessageFlags;
import cy.ac.ucy.AndroidTeam.Connection.Client.ClientSendEndedLevel;
import cy.ac.ucy.AndroidTeam.Connection.Client.ClientSendGameReply;
import cy.ac.ucy.AndroidTeam.Connection.Client.ClientSendScore;
import cy.ac.ucy.AndroidTeam.Connection.Server.ConnectionCloseServerMessage;
import cy.ac.ucy.AndroidTeam.Connection.Server.NetworkType;
import cy.ac.ucy.AndroidTeam.Connection.Server.PHPServerConnection;
import cy.ac.ucy.AndroidTeam.Connection.Server.ServerMessageFlags;
import cy.ac.ucy.AndroidTeam.Connection.Server.ServerSendEndedLevel;
import cy.ac.ucy.AndroidTeam.Connection.Server.ServerSendGameLevel;
import cy.ac.ucy.AndroidTeam.Connection.Server.ServerSendScore;
import cy.ac.ucy.AndroidTeam.Game.App.SpriteType;
import cy.ac.ucy.AndroidTeam.Game.App.TargetType;
import cy.ac.ucy.AndroidTeam.SAX.Bison.Kick.BKConstants;
import cy.ac.ucy.AndroidTeam.SAX.Bison.Kick.BKLoader;
import cy.ac.ucy.AndroidTeam.SAX.Bison.Kick.BKLoader.IBKEntityLoader;

public class MultiplayerGame extends BaseGameActivity implements
		ClientMessageFlags, ServerMessageFlags, BKConstants,
		IAccelerationListener {

	// ===========================================================
	// Constants
	// ===========================================================

	private App app;

	private static final String TAG = MultiplayerGame.class.getSimpleName();

	private Camera mCamera;

	private Engine mEngine;

	private EngineOptions mEngineOptions;

	private ClientServerReceiver clientServerReceiver;

	private BitmapTexture mTexture;

	private ITextureRegion mTargetSimpleStarTextureRegion;

	// ===========================================================
	// Fields
	// ===========================================================

	private ProgressDialog mServerWaitsForClient;

	private boolean mConnectionEstablished = false;

	// ///////////////////////////////////////////////////////////////////////////////////////////////////
	private BKLoader bkLoader;

	private int mTotalTargets = 0;

	private Integer mScoreMineInt = 0;

	private Integer mScoreOpponetInt = 0;

	private Text mScoreMineInfoText;

	private Text mScoreOpponentInfoText;

	private Text mScoreMineIntText;

	private Text mScoreOpponentIntText;

	private Text mTitleChooseLevel;

	/** The texture using for our fonts */
	private Texture mFontMineStaticTexture;
	private Texture mFontMineScoreTexture;

	/** The texture using for our opponent fonts */
	private Texture mFontOpponentStaticTexture;
	private Texture mFontOpponentScoreTexture;

	/** Fonts for displaying Players score */
	private Font mFontMineStatic;
	private Font mFontMineScore;

	/** Fonts for displaying Players Opponent score */
	private Font mFontOpponentStatic;
	private Font mFontOpponentScore;

	//private Sprite marbleOpponent;

	// ///Fields

	private ITextureRegion mEdgeUpTextureRegion;

	private ITextureRegion mEdgeGroundTextureRegion;

	private ITextureRegion mEdgeLeftTextureRegion;

	private ITextureRegion mEdgeRightTextureRegion;

	private ITextureRegion mMarbleTextureRegion;

	//private ITextureRegion mLooseHolesTextureRegion;

	private ITextureRegion mWallNonElasticTextureRegion;

	private ITextureRegion mWallElasticTextureRegion;

	private PhysicsWorld mPhysicsWorld;

	private float mX, mY;

	private float mWidth, mHeight;

	private float mRotation;

	private BodyType mBodyType;

	private String mShape;

	private String mPhysicsAndID;

	private float mDensity;

	private float mFriction;

	private float mElasticity;

	private String mID;

	//private float PtoM = PhysicsConstants.PIXEL_TO_METER_RATIO_DEFAULT;

	private VertexBufferObjectManager vertexBufferObjectManager;

	// private DataChangeReceiver dataChangeReceiver;

	private ArrayList<Sprite> targetSprites = new ArrayList<Sprite>();

	/** Messages Pool */
	private final MessagePool<IMessage> mMessagePool = new MessagePool<IMessage>();

	/** Connection of Client to server */
	private ServerConnector<SocketConnection> mClientConnectionToServer;

	/** Connection of Server to client */
	private SocketServer<SocketConnectionClientConnector> mSocketServer;

	private ServerSendScore mServerSendScore;
	private ClientSendScore mClientSendScore;

	private ServerSendEndedLevel mServerSendEndedLevel;

	private ClientSendEndedLevel mClientSendEndedLevel;

	private boolean mTriedAgainToExitGameLevel = false;

	/** I terminated the programm */
	private boolean iTerminated = false;

	/** Levels that server-user can pick */
	private ArrayList<Sprite> level = new ArrayList<Sprite>();

	/** Restore's back to false, that user wants to terminate */
	private Runnable mRunRestoreTriesToExitGameLevel = new Runnable() {
		@Override
		public void run() {
			mTriedAgainToExitGameLevel = false;
		}
	};

	private Runnable mRunCheckIfConnectionEstablished = new Runnable() {
		@Override
		public void run() {

			terminateConnectionsIfNotConnectedYet();

		}
	};

	private Runnable mRunSelectLevelAgain = new Runnable() {
		@Override
		public void run() {

			loadSelectLevelScene();

		}
	};

	// @formatter:off
	private Scene mScene;

	//private boolean mWasPlaying = false;

	private boolean isServer = false;

	/**
	 * Initialized the message pull TODO CHECK
	 */
	private void initMessagePool() {

		// If its server
		if (isServer) {
			mMessagePool.registerMessage(FLAG_MESSAGE_CLIENT_SEND_SCORE,
					ClientSendScore.class);
		} else {
			mMessagePool.registerMessage(FLAG_MESSAGE_SERVER_SEND_SCORE,
					ServerSendScore.class);
		}

	}

	@Override
	public EngineOptions onCreateEngineOptions() {

		app = (App) getApplication();

		if (app.getUserNetworkType().equals(NetworkType.Server))
			this.isServer = true;

		// If its server, wait for clients answer
		if (isServer) {
			mServerWaitsForClient = ProgressDialog.show(MultiplayerGame.this,
					"Wait for Client's answer", "Please wait "
							+ app.getOpponent().getmUserGame()
							+ " to answer...");

			mServerWaitsForClient.show();

			mServerWaitsForClient.setCancelable(true);

			mServerWaitsForClient.setOnCancelListener(new OnCancelListener() {

				@Override
				public void onCancel(DialogInterface dialog) {

					mSocketServer.terminate();

					unregisterReceivers();
					finish();

				}
			});

		}

		// Initialize & Register receiver
		// dataChangeReceiver = new DataChangeReceiver();
		clientServerReceiver = new ClientServerReceiver();
		registerReceivers();

		// Ran task in one minute to check if connection was established.
		// If not, terminate connections (40 seconds)
		app.getmHandler().postDelayed(this.mRunCheckIfConnectionEstablished,
				App.CHECK_CONNECTION_ESTABLISHED_TIME);

		this.mCamera = new Camera(0, 0, App.CAMERA_WIDTH, App.CAMERA_HEIGHT);

		this.mEngineOptions = new EngineOptions(true,
				ScreenOrientation.LANDSCAPE_FIXED, new RatioResolutionPolicy(
						App.CAMERA_WIDTH, App.CAMERA_HEIGHT), this.mCamera);

		this.mEngine = new Engine(mEngineOptions);

		this.initMessagePool();

		return this.mEngineOptions;
	}

	// ===========================================================
	// Constants
	// ===========================================================
	@Override
	public void onCreateResources(
			OnCreateResourcesCallback pOnCreateResourcesCallback)
			throws Exception {

		/* Create resources for fonts */
		FontFactory.setAssetBasePath("font/");

		// Create fonts to display Score
		this.mFontMineStaticTexture = new BitmapTextureAtlas(
				getTextureManager(), 128, 128,
				TextureOptions.BILINEAR_PREMULTIPLYALPHA);

		mFontMineStatic = FontFactory.createFromAsset(getFontManager(),
				mFontMineStaticTexture, getAssets(), "edo.ttf", 30, true,
				android.graphics.Color.RED);
		mFontMineStaticTexture.load();
		mFontMineStatic.load();

		this.mFontOpponentStaticTexture = new BitmapTextureAtlas(
				getTextureManager(), 128, 128,
				TextureOptions.BILINEAR_PREMULTIPLYALPHA);

		mFontOpponentStatic = FontFactory.createFromAsset(getFontManager(),
				mFontOpponentStaticTexture, getAssets(), "edo.ttf", 25, true,
				android.graphics.Color.GRAY);

		mFontOpponentStaticTexture.load();
		mFontOpponentStatic.load();

		this.mFontMineScoreTexture = new BitmapTextureAtlas(
				getTextureManager(), 256, 256,
				TextureOptions.BILINEAR_PREMULTIPLYALPHA);
		mFontMineScore = FontFactory.createFromAsset(getFontManager(),
				mFontMineScoreTexture, getAssets(), "edo.ttf", 30, true,
				android.graphics.Color.GRAY);
		mFontMineScoreTexture.load();
		mFontMineScore.load();

		this.mFontOpponentScoreTexture = new BitmapTextureAtlas(
				getTextureManager(), 256, 256,
				TextureOptions.BILINEAR_PREMULTIPLYALPHA);
		mFontOpponentScore = FontFactory.createFromAsset(getFontManager(),
				mFontOpponentScoreTexture, getAssets(), "edo.ttf", 25, true,
				android.graphics.Color.GRAY);
		mFontOpponentScoreTexture.load();
		mFontOpponentScore.load();

		/* ********* Create all the Texture Regions needed ********** */
		try {
			// ******* 1) Create the texture for the marble
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.marble);
						}
					});

			// Extract from Texture the TextureRegion of Marble
			this.mMarbleTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			// Load the texture for the marble
			this.mTexture.load();

			// *** 3 Create all 4 Edge Texture Region's
			// Create Up Edge
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.edge_up);
						}
					});

			this.mEdgeUpTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			this.mTexture.load();

			// Create Ground Edge
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.edge_ground);
						}
					});

			this.mEdgeGroundTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			this.mTexture.load();

			// Create Left Edge
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.edge_left);
						}
					});

			this.mEdgeLeftTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			this.mTexture.load();

			// Create Right Edge
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.edge_right);
						}
					});

			this.mEdgeRightTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			this.mTexture.load();

			// *** 4) Create the texture for the Non Elastic Obstacles
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.wall_not_elastic);
						}
					});

			// 4) Extract from Texture the TextureRegion of Marble
			this.mWallNonElasticTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			// Load the texture for the glass
			this.mTexture.load();

			// *** 5) Create the texture for the Elastic Obstacles
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.wall_elastic);
						}
					});

			// 4) Extract from Texture the TextureRegion of Marble
			this.mWallElasticTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			// Load the texture for the glass
			this.mTexture.load();

			// ****** Create Texture for the targets
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.star_simple);
						}
					});

			// 4) Extract from Texture the TextureRegion of Marble
			this.mTargetSimpleStarTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			// Load the texture for the glass
			this.mTexture.load();

		} catch (IOException e) {
			Debug.e(e);
		}

		this.vertexBufferObjectManager = this.getVertexBufferObjectManager();

		pOnCreateResourcesCallback.onCreateResourcesFinished();

	}

	// ===========================================================
	// Constants
	// ===========================================================
	@Override
	public void onCreateScene(OnCreateSceneCallback pOnCreateSceneCallback)
			throws Exception {

		// Re-Initialize the physics world
		mPhysicsWorld = new PhysicsWorld(new Vector2(0,
				SensorManager.GRAVITY_EARTH), false);

		// this.mEngine.registerUpdateHandler(new FPSLogger());
		/** Our scene */
		mScene = new Scene();

		mScene.setBackground(new Background(0.415686275f, 0.352941176f,
				0.803921569f, 0.0f));

		this.mEngine.setScene(mScene);

		loadSelectLevelScene();

		if (isServer) {
			// Initialization of Server
			initServer();

		}

		else {
			// Initialization of Client
			initClient();
			Log.e(TAG, "Client AFTER INITED info about server : servextip"
					+ app.getOpponent().getmExternalIP() + " servintip "
					+ app.getOpponent().getmLocalIP());
		}

		// We wont call the callback as normally we should
		// Instead of this, we 'll save it, and call it, when
		// connection between a client and a server is established

		mEngine.setScene(mScene);

		app.setOnCreateResourcesCallback(pOnCreateSceneCallback, mScene);
	}

	/**
	 * 
	 * Cleans the Scene
	 * 
	 * 
	 */
	private void cleanScene() {
		// Clean the Scene
		try {
			mEngine.getScene().unregisterUpdateHandler(mPhysicsWorld);
		} catch (Exception e) {
			// do noth
		}

		mEngine.getScene().detachChildren();
		mEngine.getScene().clearTouchAreas();
		mEngine.getScene().clearUpdateHandlers();

	}

	/**
	 * 
	 * 
	 * Loads the Level Selection Scene
	 * 
	 * 
	 */
	private void loadSelectLevelScene() {

		// Clean scene
		cleanScene();

		//mWasPlaying = false;

		String picker;

		if (isServer) {
			picker = app.getUser().getmUserGame();

		} else {
			picker = app.getOpponent().getmUserGame();
		}

		mTitleChooseLevel = new Text(0.30f * App.CAMERA_WIDTH, 50.0f,
				mFontMineStatic, picker + " chooses level",
				this.getVertexBufferObjectManager());
		// mScoreMineInfoText.setAlpha(0.6f);
		mScene.attachChild(mTitleChooseLevel);

		mTitleChooseLevel.registerEntityModifier(new ParallelEntityModifier(
				new IEntityModifierListener() {

					@Override
					public void onModifierStarted(IModifier<IEntity> pModifier,
							IEntity pItem) {
					}

					@Override
					public void onModifierFinished(
							IModifier<IEntity> pModifier, IEntity pItem) {
					}
				}, new AlphaModifier(2.0f, 0.0f, 1.0f, EaseElasticInOut
						.getInstance()), new ScaleModifier(2.0f, 5.0f, 1.0f,
						EaseElasticOut.getInstance())));

		// server should choose level
		level.add(new Sprite(mCamera.getWidth() / 6
				- mTargetSimpleStarTextureRegion.getWidth(), 150,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(1);

					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								1);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);


						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));

					} catch (final IOException e) {
						Debug.e(e);
					}
				}
				return true;
			}

		});

		level.add(new Sprite(mCamera.getWidth() / 6 * 2
				- mTargetSimpleStarTextureRegion.getWidth(), 150,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(2);
					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								2);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);

						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));
					} catch (final IOException e) {
						Debug.e(e);
					}

				}
				return true;
			}

		});

		level.add(new Sprite(mCamera.getWidth() / 6 * 3
				- mTargetSimpleStarTextureRegion.getWidth(), 150,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(3);
					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								3);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);

						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));
					} catch (final IOException e) {
						Debug.e(e);
					}
				}
				return true;
			}

		});

		level.add(new Sprite(mCamera.getWidth() / 6 * 4
				- mTargetSimpleStarTextureRegion.getWidth(), 150,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(4);
					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								4);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);

						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));
					} catch (final IOException e) {
						Debug.e(e);
					}

				}
				return true;
			}

		});
		// level 5
		level.add(new Sprite(mCamera.getWidth() / 6 * 5
				- mTargetSimpleStarTextureRegion.getWidth(), 150,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(5);
					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								5);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);

						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));
					} catch (final IOException e) {
						Debug.e(e);
					}

				}
				return true;
			}

		});

		// level 6
		level.add(new Sprite(mCamera.getWidth() / 6 * 1
				- mTargetSimpleStarTextureRegion.getWidth(), 300,
				this.mTargetSimpleStarTextureRegion, this
						.getVertexBufferObjectManager()) {

			@Override
			public boolean onAreaTouched(final TouchEvent pAreaTouchEvent,
					final float pTouchAreaLocalX, final float pTouchAreaLocalY) {

				switch (pAreaTouchEvent.getAction()) {
				case TouchEvent.ACTION_UP:
					// Save & Send the level
					app.setmPlayLevelByServer(6);
					try {
						// Create a new reply about the clients
						// message
						final ServerSendGameLevel sendGameLevel = new ServerSendGameLevel(
								6);
						mSocketServer.sendBroadcastServerMessage(sendGameLevel);

						// Run the level
						sendBroadcast(new Intent(
								App.REC_SERVER_SEND_SELECTED_LEVEL));
					} catch (final IOException e) {
						Debug.e(e);
					}

				}
				return true;
			}

		});

		for (Sprite iLevel : level) {
			iLevel.setScale(0.7f);
			mScene.attachChild(iLevel);
			if (isServer)
				mScene.registerTouchArea(iLevel);
		}


	}

	private void resetStats() {
		mScoreMineInt = 0;
		mScoreOpponetInt = 0;
		mTotalTargets = 0;

		mPhysicsWorld = new PhysicsWorld(new Vector2(0,
				SensorManager.GRAVITY_EARTH), false);
		// Re initialize targets
		targetSprites = new ArrayList<Sprite>();

		// Detect Collisions
		this.mPhysicsWorld.setContactListener(new ContactListener() {

			@Override
			public void preSolve(Contact contact, Manifold oldManifold) {

			}

			@Override
			public void postSolve(Contact contact, ContactImpulse impulse) {

			}

			@Override
			public void endContact(Contact contact) {

			}

			@Override
			public void beginContact(Contact contact) {
				// Get 1st colliding body
				Body bodyA = contact.getFixtureA().getBody();
				// Get 2nd colliding body
				Body bodyB = contact.getFixtureB().getBody();

				// Get user data of that body
				String idA = (String) bodyA.getUserData();
				String idB = (String) bodyB.getUserData();

				// If the Marble touches a Target
				if ((isMyMarble(idA) && isTarget(idB))
						|| (isMyMarble(idB) && isTarget(idA))) {
					// Collect the target
					if (isTarget(idA))
						collectMyPoints(bodyA);
					else
						collectMyPoints(bodyB);

				}

			}

		});

	}

	/**
	 * Called after the calle
	 */
	private void loadLiveGameSelectedLevelScene() {

		//mWasPlaying = true;

		// Reset everything
		cleanScene();
		resetStats();

		/** Bison Kick Loader */
		bkLoader = new BKLoader();
		bkLoader.setAssetBasePath("level/");

		// Parse the Bison-Kick Format XML File, using SAXml
		this.parseBK_XML();

		try {
			// Load the level from asset file, and create all Entities needed
			bkLoader.loadLevelFromAsset(getAssets(),// pAssetPath)
					// (getApplicationContext(),
					"level" + app.getmPlayLevelByServer() + ".lvl");
		} catch (Exception e) {
			Log.e(TAG, e.toString());
		}

		// Show my Score
		mScoreMineInfoText = new Text(0.50f * App.CAMERA_WIDTH, 10.0f,
				mFontMineStatic, app.getUser().getmUserGame(),
				this.getVertexBufferObjectManager());
		mScoreMineInfoText.setAlpha(0.6f);
		mScene.attachChild(mScoreMineInfoText);

		mScoreMineIntText = new Text(0.75f * App.CAMERA_WIDTH, 10.0f,
				mFontMineScore, "       0", this.getVertexBufferObjectManager());
		mScoreMineIntText.setAlpha(0.6f);
		mScene.attachChild(mScoreMineIntText);

		// Show the score of Opponent
		mScoreOpponentInfoText = new Text(0.50f * App.CAMERA_WIDTH, 40.0f,
				mFontOpponentStatic, app.getOpponent().getmUserGame(),
				this.getVertexBufferObjectManager());
		mScoreOpponentInfoText.setAlpha(0.6f);
		mScene.attachChild(mScoreOpponentInfoText);

		mScoreOpponentIntText = new Text(0.75f * App.CAMERA_WIDTH, 40.0f,
				mFontOpponentScore, "       0",
				this.getVertexBufferObjectManager());
		mScoreOpponentIntText.setAlpha(0.6f);
		mScene.attachChild(mScoreOpponentIntText);

		mScene.registerUpdateHandler(mPhysicsWorld);

		// Enable sensor
		this.enableAccelerationSensor(this);

	}

	// ===========================================================
	// Constants
	// ===========================================================
	/**
	 * We implemented this way, so if connection is not established, the game
	 * flow doesn't reach in here!
	 * */
	@Override
	public void onPopulateScene(Scene pScene,
			OnPopulateSceneCallback pOnPopulateSceneCallback) throws Exception {

		// Here the Server and Client are connected!

		// If its Server
		if (!isServer) {
			// Client will send a Reply about its decision
			// (Play with server, or dont)
			try {
				// Create a new reply about the clients message
				final ClientSendGameReply clientSendGameReply = new ClientSendGameReply(
						app.isUserAccepted());

				// Send the Reply Message to Server
				mClientConnectionToServer
						.sendClientMessage(clientSendGameReply);

			} catch (final IOException e) {
				Debug.e(e);
			}
		}

		pOnPopulateSceneCallback.onPopulateSceneFinished();

	}

	// /////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////
	// ///////////////// Overrides /////////////////
	// /////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////
	/** Not used */
	@Override
	public void onAccelerationAccuracyChanged(AccelerationData pAccelerationData) {

	}

	/** When user tilts his/her device */
	@Override
	public void onAccelerationChanged(AccelerationData pAccelerationData) {
		final Vector2 gravity = Vector2Pool.obtain(pAccelerationData.getX(),
				pAccelerationData.getY());
		mPhysicsWorld.setGravity(gravity);
		Vector2Pool.recycle(gravity);

	}

	@Override
	public synchronized void onResumeGame() {
		super.onResumeGame();
		// Register the receiver
		registerReceivers();
		this.enableAccelerationSensor(this);

	}

	@Override
	public synchronized void onPauseGame() {
		super.onPauseGame();
		// Unregister the receiver
		unregisterReceivers();

		this.disableAccelerationSensor();
	}

	@Override
	protected void onStop() {
		super.onStop();
		unregisterReceivers();

	}

	/** Destroy the socket??? WHEN? */
	@Override
	protected void onDestroy() {
		// if user didnt accept challenge, destroy connections
		if (mSocketServer != null) {
			try {
				mSocketServer
						.sendBroadcastServerMessage(new ConnectionCloseServerMessage());
			} catch (final IOException e) {
				Debug.e(e);
			}
			mSocketServer.terminate();
		}
		// termatizoume ton connector
		if (mClientConnectionToServer != null) {
			mClientConnectionToServer.terminate();
		}

		if (isServer) {
			PHPServerConnection.removeOpponent(app.getOpponent());
		}

		super.onDestroy();
	}

	/** ignore back button??? */
	@Override
	public boolean onKeyUp(final int pKeyCode, final KeyEvent pEvent) {
		switch (pKeyCode) {
		case KeyEvent.KEYCODE_BACK:

			if (isServer) {
				if (mTriedAgainToExitGameLevel) {

					iTerminated = true;
					this.terminateConnections();
				} else {

					showToastShort("Press again to walk away");
					app.getmHandler().postDelayed(
							mRunRestoreTriesToExitGameLevel,
							App.DELAY_RESTORE_USER_WANTS_TO_TERMINATE);

					mTriedAgainToExitGameLevel = true;
				}

			} else {
				if (mTriedAgainToExitGameLevel) {
					iTerminated = true;
					this.terminateConnections();
					// mTriedAgainToExitGameLevel=false;//Needed?
				} else {
					showToastShort("Press again to walk away");

					app.getmHandler().postDelayed(
							mRunRestoreTriesToExitGameLevel,
							App.DELAY_RESTORE_USER_WANTS_TO_TERMINATE);
					mTriedAgainToExitGameLevel = true;
				}

			}

			return true;
		}
		return true;
	}

	// ===========================================================
	// Methods
	// ===========================================================

	/** Initialization of server */
	private void initServer() {

		// Early Initialization of Exchange Messages
		mServerSendScore = new ServerSendScore();
		mServerSendEndedLevel = new ServerSendEndedLevel(true);

		// Create the Socket Server
		mSocketServer = new SocketServer<SocketConnectionClientConnector>(
				App.SERVER_PORT, new ExampleClientConnectorListener(),
				new ExampleServerStateListener()) {

			@Override
			protected SocketConnectionClientConnector newClientConnector(
					final SocketConnection pSocketConnection)
					throws IOException {

				final SocketConnectionClientConnector clientConnector = new SocketConnectionClientConnector(
						pSocketConnection);

				// Server: Now we register messages that are received from
				// Client

				/* Register about Clients Desicion (Play or not the game) */
				clientConnector.registerClientMessage(
						FLAG_MESSAGE_CLIENT_SEND_CONNECTION_REPLY,
						ClientSendGameReply.class,
						new IClientMessageHandler<SocketConnection>() {

							@Override
							public void onHandleMessage(
									final ClientConnector<SocketConnection> pClientConnector,
									final IClientMessage pClientMessage)
									throws IOException {

								final ClientSendGameReply clientSendGameReply = (ClientSendGameReply) pClientMessage;

								// Opponent(client) Accepted
								if (clientSendGameReply.getReply() == true) {

									sendBroadcast(new Intent(
											App.REC_SERVER_RECEIVED_CLIENT_POSITIVE_REPLY));

								}

								else {
									showToastLong(app.getOpponent()
											.getmUserGame() + " declined! :(");
									// Terminate server and this
									// activity
									mSocketServer.terminate();
									finish();
								}

							}
						});


				/* Register about Clients Score Messages */
				clientConnector.registerClientMessage(
						FLAG_MESSAGE_CLIENT_SEND_SCORE, ClientSendScore.class,
						new IClientMessageHandler<SocketConnection>() {

							@Override
							public void onHandleMessage(
									final ClientConnector<SocketConnection> pClientConnector,
									final IClientMessage pClientMessage)
									throws IOException {

								final ClientSendScore clientSendScore = (ClientSendScore) pClientMessage;

								collectOpponentPoints(clientSendScore
										.getmPointCode());
							}
						});

				/* Register about Clients Finished Level */
				clientConnector.registerClientMessage(
						FLAG_MESSAGE_CLIENT_SEND_FINISHED_LEVEL,
						ClientSendEndedLevel.class,
						new IClientMessageHandler<SocketConnection>() {

							@Override
							public void onHandleMessage(
									final ClientConnector<SocketConnection> pClientConnector,
									final IClientMessage pClientMessage)
									throws IOException {
								// Lost
								makeLoseMovements();

								// Select a level (again)
								app.getmHandler().postDelayed(
										mRunSelectLevelAgain,
										App.DELAY_SELECT_LEVEL_AGAIN);

							}
						});

				return clientConnector;

			}
		};

		mSocketServer.start();

	}

	/**
	 * Initialization of Client 8ETOUME LISTENER EDW GIA NA PERIMENEI TA MSGS
	 * TOU SERVER!
	 */
	private void initClient() {
		try {
			// Find whether we are in same network or in different network
			// If we are in same, client will connect to Local IP
			// Otherwise client will connect to external IP
			String useIP;

			// Early initialization of Exchange Messages
			mClientSendScore = new ClientSendScore();
			mClientSendEndedLevel = new ClientSendEndedLevel(true);

			if (app.getOpponent().getmExternalIP()
					.equals(app.getUser().getmExternalIP())) {
				// In Same Network

				useIP = app.getOpponent().getmLocalIP();
			} else {
				// Or needs some info also from the internal?
				useIP = app.getOpponent().getmExternalIP();

			}



			// Connect to server--> to opponents IP
			mClientConnectionToServer = new SocketConnectionServerConnector(
					new SocketConnection(new Socket(useIP, App.SERVER_PORT)),
					new ExampleServerConnectorListener());



			/* Register about Server's Score Code Messages */
			mClientConnectionToServer.registerServerMessage(
					FLAG_MESSAGE_SERVER_SEND_SCORE, ServerSendScore.class,
					new IServerMessageHandler<SocketConnection>() {

						@Override
						public void onHandleMessage(
								final ServerConnector<SocketConnection> pServerConnector,
								final IServerMessage pServerMessage)
								throws IOException {
							// Save the message received
							final ServerSendScore serverSendScore = (ServerSendScore) pServerMessage;

							collectOpponentPoints(serverSendScore
									.getmPointCode());

						}
					});

			/* Register about Server's Finished Level Messages */
			mClientConnectionToServer.registerServerMessage(
					FLAG_MESSAGE_SERVER_SEND_FINISHED_LEVEL,
					ServerSendEndedLevel.class,
					new IServerMessageHandler<SocketConnection>() {

						@Override
						public void onHandleMessage(
								final ServerConnector<SocketConnection> pServerConnector,
								final IServerMessage pServerMessage)
								throws IOException {

							makeLoseMovements();

							showToastShort("Wait "
									+ app.getOpponent().getmUserGame()
									+ " to choose next level");

							// Select a level (again)
							app.getmHandler().postDelayed(mRunSelectLevelAgain,
									App.DELAY_SELECT_LEVEL_AGAIN);

						}
					});

			/* Register about Server's Chosen Level Messages */
			mClientConnectionToServer.registerServerMessage(
					FLAG_MESSAGE_SERVER_SEND_SELECTED_LEVEL,
					ServerSendGameLevel.class,
					new IServerMessageHandler<SocketConnection>() {

						@Override
						public void onHandleMessage(
								final ServerConnector<SocketConnection> pServerConnector,
								final IServerMessage pServerMessage)
								throws IOException {
							// Save the message received
							final ServerSendGameLevel serverSendGameLevel = (ServerSendGameLevel) pServerMessage;

							// Save the level in Application
							// So this level will be loaded in Play Live
							// Level Activity
							app.setmPlayLevelByServer(serverSendGameLevel
									.getmSelectedLevel());

							// Unregister receivers of client
							// unregisterReceivers();

							// Start the Play Live Level
							sendBroadcast(new Intent(
									App.REC_SERVER_SEND_SELECTED_LEVEL));

							showToastShort(app.getOpponent().getmUserGame()
									+ " selected level "
									+ app.getmPlayLevelByServer()
									+ ". Have fun!");

							// a//app.getmHandler().post(mRunPlayLiveLevel);

						}
					});

			/*
			 * Register for the message when server closes! WHen it does, we
			 * call finish!
			 */
			mClientConnectionToServer.registerServerMessage(
					FLAG_MESSAGE_SERVER_CONNECTION_CLOSE,
					ConnectionCloseServerMessage.class,
					new IServerMessageHandler<SocketConnection>() {

						@Override
						public void onHandleMessage(
								final ServerConnector<SocketConnection> pServerConnector,
								final IServerMessage pServerMessage)
								throws IOException {
							// CALL FINISH
							MultiplayerGame.this.finish();
						}
					});

			mClientConnectionToServer.getConnection().start();


		} catch (final Throwable t) {
			Debug.e(t);
		}
	}

	/**
	 * Make all appropriate Loose Movement if user has lost
	 */
	private void makeLoseMovements() {
		mScoreOpponentInfoText
				.registerEntityModifier(new ParallelEntityModifier(
						new MoveModifier(
								2.0f,
								mScoreOpponentInfoText.getX(),
								App.CAMERA_WIDTH / 2
										- mScoreOpponentInfoText.getWidth() / 2,
								mScoreOpponentInfoText.getY(),
								App.CAMERA_HEIGHT / 2
										- mScoreOpponentInfoText.getWidth() / 2,
								EaseBounceOut.getInstance()),
						new ScaleModifier(2.0f, 1.0f, 3.0f, EaseElasticOut
								.getInstance())));

		showToastShort("You Lost :(");
	}

	/**
	 * Make all appropriate Win Movements if user has won
	 */
	private void makeWinMovements() {
		mScoreMineInfoText
				.registerEntityModifier(new ParallelEntityModifier(
						new MoveModifier(2.0f, mScoreMineInfoText.getX(),
								App.CAMERA_WIDTH / 2
										- mScoreMineInfoText.getWidth() / 2,
								mScoreOpponentInfoText.getY(),
								App.CAMERA_HEIGHT / 2
										- mScoreMineInfoText.getWidth() / 2,
								EaseElasticOut.getInstance()),
						new ScaleModifier(2.0f, 1.0f, 3.0f, EaseQuadOut
								.getInstance())));

		showToastShort("You won! :)");
	}

	/**
	 * 
	 * Terminates all active connections, if still didnt connected
	 * 
	 */
	private void terminateConnectionsIfNotConnectedYet() {

		// If connection hasnt established within 1 minute
		// terminate it
		if (!mConnectionEstablished) {
			terminateConnections();
			// Show a message
			showToastLong("Connection will not be established.");
		}

	}

	/**
	 * 
	 * Terminates all active connections
	 * 
	 */
	private void terminateConnections() {

		// If connection hasnt established within 1 minute
		// terminate it
		if (mServerWaitsForClient != null) {
			if (mServerWaitsForClient.isShowing())
				mServerWaitsForClient.dismiss();
		}
		if (mSocketServer != null) {
			mSocketServer.terminate();
		} else if (mClientConnectionToServer != null) {
			mClientConnectionToServer.terminate();
		}

		// Unregister receivers
		unregisterReceivers();

		// Finish activity
		this.finish();

	}

	// ===========================================================
	// Inner and Anonymous Classes
	// ===========================================================

	/**
	 * Inner Class: We set a broadcast receiver for the Connection Establishment
	 * so we use the most appropriate way to get notified, when the connection
	 * was established
	 * 
	 * @author paschalis
	 * 
	 */
	public class ClientServerReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			// Connection Established
			if (intent.getAction().equals(App.REC_CONNECTION_ESTABLISHED)) {
				//
				Log.i(TAG, app.getUserNetworkType() + "Connection established");

				MultiplayerGame.this.mConnectionEstablished = true;

				// Run the callback so we can reach the onPopulateScene
				MultiplayerGame.this.app.runOnCreateResourcesCallback();
			}
			// If client informed about servers level
			else if (intent.getAction().equals(
					App.REC_SERVER_SEND_SELECTED_LEVEL)) {


				level.get(app.getmPlayLevelByServer() - 1)
						.registerEntityModifier(
								new ParallelEntityModifier(
										new IEntityModifierListener() {

											@Override
											public void onModifierStarted(
													IModifier<IEntity> pModifier,
													IEntity pItem) {
											}

											@Override
											public void onModifierFinished(
													IModifier<IEntity> pModifier,
													IEntity pItem) {
												// Run the level
												loadLiveGameSelectedLevelScene();
											}
										}, new ScaleModifier(1.0f, 1.0f, 3.0f,
												EaseQuadOut.getInstance()),
										new AlphaModifier(1.0f, 1.0f, 0.0f,
												EaseQuadOut.getInstance()),
										new RotationModifier(1.0f, 0.0f, 360f,
												EaseElasticOut.getInstance())));

			}
			// If server was informed about clients answer
			else if (intent.getAction().equals(
					App.REC_SERVER_RECEIVED_CLIENT_POSITIVE_REPLY)) {
				// Dismiss the waiting dialog
				if (mServerWaitsForClient != null)
					if (mServerWaitsForClient.isShowing())
						mServerWaitsForClient.dismiss();

				showToastShort("Select Level");

			}

		}
	}

	/**
	 * Listener, when server started, or stopped
	 * 
	 * @author paschalis
	 * 
	 */
	class ExampleServerStateListener implements
			ISocketServerListener<SocketConnectionClientConnector> {

		@Override
		public void onStarted(
				final SocketServer<SocketConnectionClientConnector> pSocketServer) {
			Log.d(TAG, "SERVER: Started");
		}

		@Override
		public void onTerminated(
				final SocketServer<SocketConnectionClientConnector> pSocketServer) {
			Log.d(TAG, "SERVER: terminated");
		}

		@Override
		public void onException(
				final SocketServer<SocketConnectionClientConnector> pSocketServer,
				final Throwable pThrowable) {
			Debug.e(pThrowable);
			Log.d(TAG, "SERVER: Exception" + pThrowable);

		}
	}

	/**
	 * 
	 * 
	 * I enwsi pou ginete p tin plevra tou client
	 * 
	 * 
	 * */
	class ExampleServerConnectorListener implements
			ISocketConnectionServerConnectorListener {

		@Override
		public void onStarted(final ServerConnector<SocketConnection> pConnector) {


			// We send a broadcast, within our application so the game flow
			// can move onPopulateScene method
			sendBroadcast(new Intent(App.REC_CONNECTION_ESTABLISHED));
		}

		@Override
		public void onTerminated(
				final ServerConnector<SocketConnection> pConnector) {
			Log.d(TAG, "Client: Disconnected to server.");
			MultiplayerGame.this.finish();
			if (!iTerminated)
				showToastLong(app.getOpponent().getmUserGame()
						+ " runned away!");
		}
	}

	/**
	 * 
	 * 
	 * I enwsi pou ginete apo tin plevra tou SERVER
	 * 
	 * 
	 * */
	class ExampleClientConnectorListener implements
			ISocketConnectionClientConnectorListener {

		@Override
		public void onStarted(final ClientConnector<SocketConnection> pConnector) {
			// We send a broadcast, within our application so the game flow
			// can move onPopulateScene method
			sendBroadcast(new Intent(App.REC_CONNECTION_ESTABLISHED));
		}

		@Override
		public void onTerminated(
				final ClientConnector<SocketConnection> pConnector) {
			// CHANGE to log.d
			Log.e(TAG, "Server: client disconnected from me: ");
			if (!iTerminated)
				showToastLong(app.getOpponent().getmUserGame()
						+ " runned away!");
			terminateConnections();
		}
	}

	// /////////////////////////////////////////////////////////////////// //
	// /////////////////////////////////////////////////////////////////// //
	// *********************** Extra Help Methods ************************ //
	// /////////////////////////////////////////////////////////////////// //
	// /////////////////////////////////////////////////////////////////// //

	/**
	 * 
	 */
	private void registerReceivers() {

		// Both for client and server
		registerReceiver(clientServerReceiver, new IntentFilter(
				App.REC_CONNECTION_ESTABLISHED));

		// registerReceiver(dataChangeReceiver, new IntentFilter(
		// App.REC_DATA_CHANGED_SCORE));

		registerReceiver(clientServerReceiver, new IntentFilter(
				App.REC_SERVER_SEND_SELECTED_LEVEL));

		// If it's Server
		if (isServer) {
			// Register Server to wait for clients answer for its decision
			// playin' or not
			registerReceiver(clientServerReceiver, new IntentFilter(
					App.REC_SERVER_RECEIVED_CLIENT_POSITIVE_REPLY));

		}
		// If it's Client
		// else{
		//
		// }

		//

		// TODO FUTURE COORDINATES
	}

	/**
	 * 
	 */
	private void unregisterReceivers() {
		try {
			// unregisterReceiver(dataChangeReceiver);
			// Both for client and server
			unregisterReceiver(clientServerReceiver);

			// If it's Server
			if (isServer) {
				// TODO

				// Remove also waiting dialog
				if (mServerWaitsForClient != null)
					if (mServerWaitsForClient.isShowing())
						mServerWaitsForClient.dismiss();

			}

		} catch (IllegalArgumentException e) {
			// Receivers weren't registered
			// Do nothing
		}

	}

	/** Show a Short Toast Messsage */
	private void showToastShort(final String Message) {
		MultiplayerGame.this.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(MultiplayerGame.this, Message,
						Toast.LENGTH_SHORT).show();
			}
		});
	}

	/** Show a Long Toast Messsage */
	private void showToastLong(final String Message) {
		MultiplayerGame.this.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(MultiplayerGame.this, Message, Toast.LENGTH_LONG)
						.show();
			}
		});
	}

	/**
	 * Collects our points when got a Target in the game
	 * 
	 * @param pBody
	 *            the body we collected
	 */
	private void collectMyPoints(Body pBody) {
		// Get the body data
		String bodyData = (String) pBody.getUserData();
		Sprite matchedSprite = findSprite(bodyData);

		// TODO FUTURE make a nice graphical function for the below line
		matchedSprite.detachSelf();
		// That body is not inactive
		pBody.setActive(false);

		mTotalTargets--;

		// Store the Point Code
		byte pointCode = App.getTargetPointCode(bodyData);

		mScoreMineInt += App.getScoreFromCode(pointCode);

		mScoreMineIntText.setText(mScoreMineInt.toString());
		mScoreMineIntText.registerEntityModifier(new SequenceEntityModifier(

		new ScaleModifier(0.5f, 1.0f, 1.5f, EaseElasticIn.getInstance()),
				new ScaleModifier(0.5f, 1.5f, 1.0f, EaseElasticOut
						.getInstance())));

		// Inform Opponent about our achievement
		if (isServer) {
			// new ServerInformClientAboutScore(pointCode).execute();

			mServerSendScore.setmPointCode(pointCode);

			// Send it to client
			try {
				mSocketServer.sendBroadcastServerMessage(mServerSendScore);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		else {
			// new ClientInformServerAboutScore(pointCode).execute();
			mClientSendScore.setmPointCode(pointCode);

			try {
				mClientConnectionToServer.sendClientMessage(mClientSendScore);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (mTotalTargets == 0) {

			makeWinMovements();

			if (isServer) {

				// Send it to client
				try {
					mSocketServer
							.sendBroadcastServerMessage(mServerSendEndedLevel);
				} catch (IOException e) {
					e.printStackTrace();
				}

				// Select a level (again)
				app.getmHandler().postDelayed(mRunSelectLevelAgain,
						App.DELAY_SELECT_LEVEL_AGAIN);

			} else {

				// Send it to server
				try {
					mClientConnectionToServer
							.sendClientMessage(mClientSendEndedLevel);
				} catch (IOException e) {
					e.printStackTrace();
				}
				// Select a level (again)
				app.getmHandler().postDelayed(mRunSelectLevelAgain,
						App.DELAY_SELECT_LEVEL_AGAIN);
			}
		}

	}

	/**
	 * Update opponents points
	 * 
	 * @param pPointCode
	 *            to get its points
	 */
	private void collectOpponentPoints(byte pPointCode) {

		mScoreOpponetInt += App.getScoreFromCode(pPointCode);

		mScoreOpponentIntText.setText(mScoreOpponetInt.toString());
		mScoreOpponentIntText
				.registerEntityModifier(new SequenceEntityModifier(

						new ScaleModifier(0.5f, 1.0f, 1.5f, EaseElasticIn
								.getInstance()), new ScaleModifier(0.5f, 1.5f,
								1.0f, EaseElasticOut.getInstance())));

	}

	/**
	 * @param id
	 *            given
	 * @return the sprite that matches with that id
	 */
	private Sprite findSprite(String id) {
		for (Sprite s : targetSprites) {
			if (s.getUserData().equals(id))
				return s;
		}
		// Not found
		return null;
	}

	/**
	 * Select the appropriate Texture Region and return it
	 * 
	 * @param ShapeType
	 *            what shape is it (square, circle, polygon)
	 * @param id
	 *            of the object
	 * @return
	 */
	private ITextureRegion selectTexture(Object pShapeType, String pID) {

		// The shape is square
		if (pShapeType.equals(TAG_SHAPE_VALUE_SQUARE)) {
			/** is true if it is Edge (Four edges of screen) */

			// If its one of the four Edges
			if (isEdge(pID)) {
				// Switch to appropriate Texture Region
				switch (getEdgeType(pID)) {
				case Up:
					return mEdgeUpTextureRegion;
				case Ground:
					return mEdgeGroundTextureRegion;
				case Left:
					return mEdgeLeftTextureRegion;
				case Right:
					return mEdgeRightTextureRegion;
				default:
					Log.e(TAG, "selectTexture: Returned null for TR");
					return null;

				}

			}
			// If it's a wall
			else if (isWall(pID)) {
				// If its elastic wall
				if (isElastic(SpriteType.Wall, pID)) {
					return this.mWallElasticTextureRegion;
				}
				// If its not elastic wall
				else {
					return this.mWallNonElasticTextureRegion;
				}

			}

		}

		// The shape is circle
		else if (pShapeType.equals(TAG_SHAPE_VALUE_CIRCLE)) {
			// If its the marble
			if (isMyMarble(pID)) {
				return mMarbleTextureRegion;
			} else if (isOpponentsMarble(pID)) {
				// TODO FUTURE CHANGE THIS
				return mMarbleTextureRegion;
			}

			else if (isTarget(pID)) {
				switch (getTargetType(pID)) {
				case Simple:
					return mTargetSimpleStarTextureRegion;

				default:
					break;
				}

			}


		}

		Log.e(TAG, "None Texture Region Matched the ID(" + pID + ")");
		return null;

	}

	/**
	 * @param pStr
	 *            the ID of the shape
	 * @return the type of the target
	 * 
	 *         Targets: what user can collect, to increase his/hers points
	 */
	private TargetType getTargetType(String pStr) {
		String t = pStr.substring(6);

		if (t.contains("simple")) {
			return TargetType.Simple;
		}
		// if (t.contains("finish"))
		// return TargetType.FinishLevel;
		else {
			Log.e(TAG, "getTargetType: unknown target type");
			return TargetType.Unknown;
		}

	}

	/**
	 * @param type
	 * @param pStr
	 * @return true if its elastic
	 */
	private boolean isElastic(SpriteType type, String pStr) {
		if (type.equals(SpriteType.Wall)) {
			return pStr.substring(4, 6).equals("el");
		}
		// CASES FOR OTHER SPRITES THAT ARE ELASTIC?
		else {
			Log.e(TAG, "Type is not wall!!");
		}

		return false;
	}

	/**
	 * @param pStr
	 *            details of Shape
	 * @return true if its a Edge
	 */
	private boolean isEdge(String pStr) {
		return pStr.substring(0, 4).equals("EDGE");
	}

	/**
	 * @param pStr
	 *            details of Shape
	 * @return true if its a Target
	 */
	private boolean isTarget(String pStr) {
		return pStr.substring(0, 6).equals("TARGET");
	}

	/**
	 * @param pStr
	 * @return the Edge type: if its up, ground, left, right
	 */
	private App.EdgeType getEdgeType(String pStr) {

		if (pStr.substring(4).equals("up"))
			return App.EdgeType.Up;
		if (pStr.substring(4).equals("ground"))
			return App.EdgeType.Ground;
		if (pStr.substring(4).equals("left"))
			return App.EdgeType.Left;
		if (pStr.substring(4).equals("right"))
			return App.EdgeType.Right;

		Log.e(TAG, "Uknown Edge type!");
		return App.EdgeType.Unknown;

	}

	/**
	 * @param pStr
	 *            details of Shape
	 * @return true if its an Obstacle
	 */
	private boolean isWall(String pStr) {
		return pStr.substring(0, 4).equals("WALL");
	}

	/**
	 * @param pStr
	 *            details of Shape
	 * @return true if its my the marble
	 */
	private boolean isMyMarble(String pStr) {
		return pStr.equals("marblemy");
	}

	/**
	 * @param pStr
	 *            details of Shape
	 * @return true if its opponents the marble
	 */
	private boolean isOpponentsMarble(String pStr) {
		return pStr.equals("marbleopp");
	}

	/**
	 * @param value
	 *            the whole string
	 * @return the mID produced
	 */
	public static String trimQuotes(String value) {
		if (value == null)
			return value;
		value = value.trim();
		if (value.startsWith("\'") && value.endsWith("\'"))
			return value.substring(1, value.length() - 1);

		return value;
	}

	/**
	 * Loads all the Bison Kick Tags Which are:
	 * 
	 * Using BisonKick by Jacobs Schatz Official Website:
	 * www.jacobschatz.com/bisonkick-beta/
	 * 
	 */
	private void parseBK_XML() {
		bkLoader.registerEntityLoader(TAG_LEVEL, new IBKEntityLoader() {

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String mStringBuilder) {

			}

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

		});

		// Most important things happen in here
		// In here, we create the Sprites, the Bodies (as read from XML)
		// bind bodies to Sprites and finally attach them to Scene
		bkLoader.registerEntityLoader(TAG_BODY, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;

			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {
				/** The texture region of the sprite */
				ITextureRegion spriteTR;
				/** The sprite */
				Sprite sprite = null;
				/**
				 * The body of the sprite With the attributes parsed from XML
				 */
				Body body = null;

				// If the Shape read before from the same xml, is square
				if (mShape.equals(TAG_SHAPE_VALUE_SQUARE)) {

					// Select Texture for square shapes, based on id
					spriteTR = selectTexture(TAG_SHAPE_VALUE_SQUARE, mID);

					sprite = new Sprite(mX - spriteTR.getWidth() / 2, mY
							- spriteTR.getHeight() / 2, spriteTR,
							MultiplayerGame.this.vertexBufferObjectManager);
					// Scale the sprite it at the size of the texture
					// region
					sprite.setScaleX(mWidth / spriteTR.getWidth());
					sprite.setScaleY(mHeight / spriteTR.getHeight());

					if (mRotation != 0.0f) {
						sprite.setRotation(mRotation * DIVISION_FIX);
					}

					// Create the square(box) body
					body = PhysicsFactory.createBoxBody(mPhysicsWorld, sprite,
							mBodyType, PhysicsFactory.createFixtureDef(
									mDensity, mElasticity, mFriction));

				}

				// If the Shape read before from the same xml, is circle
				else if (mShape.equals(TAG_SHAPE_VALUE_CIRCLE)) {

					spriteTR = selectTexture(TAG_SHAPE_VALUE_CIRCLE, mID);
					// Create the sprite, based on the position given
					sprite = new Sprite(mX - spriteTR.getWidth() / 2, mY
							- spriteTR.getHeight() / 2, spriteTR,
							MultiplayerGame.this.vertexBufferObjectManager);

					// Scale the sprite it at the size of the texture
					// region
					sprite.setScaleX(mWidth / spriteTR.getWidth());
					sprite.setScaleY(mHeight / spriteTR.getHeight());

					// Check If its the marble
					if (isMyMarble(mID) || isOpponentsMarble(mID)) {
						// Make a transition from double size, to half
						sprite.registerEntityModifier(new ScaleModifier(1.0f,
								sprite.getScaleX() * 10, mWidth
										/ spriteTR.getWidth(), sprite
										.getScaleX() * 10, mHeight
										/ spriteTR.getHeight(), EaseQuadOut
										.getInstance()));
						sprite.setScaleX(mWidth / spriteTR.getWidth());
						sprite.setScaleY(mHeight / spriteTR.getHeight());

					}

					// Scale it to fit TR's size
					sprite.setScaleX(mWidth / spriteTR.getWidth());
					sprite.setScaleY(mHeight / spriteTR.getHeight());

					// Save the user data, so we can retreive later this
					// sprite
					sprite.setUserData(mID);

					if (mRotation != 0.0f) {
						sprite.setRotation(mRotation * DIVISION_FIX);
					}

					// If its opponents marble, then it wont have a Body!
					// if (!isOpponentsMarble(mID)) {
					// Create the circle body of the sprite
					body = PhysicsFactory.createCircleBody(mPhysicsWorld,
							sprite, mBodyType, PhysicsFactory.createFixtureDef(
									mDensity, mElasticity, mFriction));
					// }

					// Save the sprite (if its a target)
					if (isTarget(mID)) {
						targetSprites.add(sprite);
					}

				}
				// EXTRA
				// If the Shape read before from the same xml, is polygon
				// else if (mShape.equals(TAG_SHAPE_VALUE_POLYGON)) {
				// // unimplemented
				// Log.d(TAG, "Implement this!!");
				// }
				else {
					throw new IllegalArgumentException();
				}

				// Attach Sprite to scene
				mScene.attachChild(sprite);

				// Connect Sprites with Bodies
				// if (!isOpponentsMarble(mID)) {

				mPhysicsWorld.registerPhysicsConnector(new PhysicsConnector(
						sprite, body, true, true));

				// }
				// Save as user data the ID
				// To find out later in collisions, who is who!
				body.setUserData(mID);

			}
		});

		// Save X coordinate
		bkLoader.registerEntityLoader(TAG_X, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {
				mX = new Float(pValue);

			}
		});
		// Save Y coordinate
		bkLoader.registerEntityLoader(TAG_Y, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {
				mY = new Float(pValue);

			}
		});
		// Save width
		bkLoader.registerEntityLoader(TAG_WIDTH, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;

			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String mValue) {
				mWidth = new Float(mValue);

			}
		});

		// Save height
		bkLoader.registerEntityLoader(TAG_HEIGHT, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;

			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String mValue) {
				mHeight = new Float(mValue);

			}
		});

		// Save rotation
		bkLoader.registerEntityLoader(TAG_ROTATION, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;

			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String mValue) {
				mRotation = new Float(mValue);

			}
		});

		// Save if its dynamic or not
		bkLoader.registerEntityLoader(TAG_ISDYNAMIC, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {

				if (pValue.equals("false")) {
					// mIsDynamic = false;
					mBodyType = BodyType.StaticBody;
				} else {
					// mIsDynamic = true;
					mBodyType = BodyType.DynamicBody;
				}

			}
		});

		bkLoader.registerEntityLoader(TAG_SHAPE, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {
				mShape = pValue;

			}
		});

		// Save ID, and Density, Elasticity, and Friction
		bkLoader.registerEntityLoader(TAG_PHYSICSANDID, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {
				// INFO we do tokenize and get density, friction,
				// elasticity, and ID
				mPhysicsAndID = pValue;
				final String[] physTokens = mPhysicsAndID.split(",");
				// Get Density, Friction and Elasticity
				mDensity = Float.valueOf(physTokens[1]).floatValue();
				mFriction = Float.valueOf(physTokens[0]).floatValue();
				mElasticity = Float.valueOf(physTokens[2]).floatValue();
				mID = trimQuotes(physTokens[3]);

				// INFO something when find items we want!
				// eg. if (mID.equals("vamp")){
				// numHeads++;
				// }

				if (isTarget(mID)) {
					mTotalTargets++;

				}

			}
		});

		// Save verts
		bkLoader.registerEntityLoader(TAG_VERTS, new IBKEntityLoader() {

			@Override
			public IEntity onLoadEntity(String pEntityName,
					Attributes pAttributes) {
				return null;
			}

			@Override
			public void onLoadEntity(String pEntityName,
					Attributes pAttributes, String pValue) {

			}
		});
	}

	// ////////////// Broadcast receiver about Opponents change

	// public class DataChangeReceiver extends BroadcastReceiver {
	//
	// @Override
	// public void onReceive(Context context, Intent intent) {
	// // We have to update opponents score
	// // CHECK HERE
	// //Opponent has won!
	// if (intent.getAction().equals(App.REC_DATA_CHANGED_OPPONENT_FINISHED)) {
	// //CHANGE
	// mScoreOpponentInfoText.registerEntityModifier(new ScaleModifier(1.0f,
	// 1.0f, 2.0f));
	//
	// showToast("You Loose :(");
	//
	// //TODO go back to pick up levels
	//
	// }
	//
	// }
	// }
}
