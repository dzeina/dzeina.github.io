package cy.ac.ucy.AndroidTeam.Connection.Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.server.ServerMessage;


public class ServerSendEndedLevel  extends ServerMessage implements
		ServerMessageFlags {

	/* Coordinates of Servers Marble */
	private boolean mEndedLevel;





	// Default constructor
	public ServerSendEndedLevel() {

	}





	public ServerSendEndedLevel(boolean pEnded) {
		this.mEndedLevel = pEnded;
	}








	/** Returns the flag of the message send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_SERVER_SEND_FINISHED_LEVEL;
	}





	/**
	 * Read the coordinates of Server's marble
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {

		// Save the two coordinate numbers

		this.setmEndedLevel(pDataInputStream.readBoolean());



	}





	/**
	 * Write the coordinates of Server's marble to server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {

		pDataOutputStream.writeBoolean(mEndedLevel);
	}





	// Getters & Setters
	public boolean getmEndedLevel() {
		return mEndedLevel;
	}





	public void setmEndedLevel(boolean mEndedLevel) {
		this.mEndedLevel = mEndedLevel;
	}
















}