package cy.ac.ucy.AndroidTeam.Game;

import java.util.ArrayList;

import org.andengine.engine.Engine;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.menu.MenuScene;
import org.andengine.opengl.font.Font;
import org.andengine.opengl.texture.ITexture;
import org.andengine.ui.IGameInterface.OnCreateSceneCallback;
import org.andengine.ui.IGameInterface.OnPopulateSceneCallback;

import android.app.Application;
import android.os.Handler;
import cy.ac.ucy.AndroidTeam.Connection.Server.NetworkType;

public class App extends Application {

	// /////////////////////////////////////////////////// //
	// Constants //
	// /////////////////////////////////////////////////// //

	/* **** Communication Constants **** */
	/** Broadcast Receiver Constant */
	protected final static String REC_CONNECTION_ESTABLISHED = "cy.ac.ucy.AndroidTeam.connection_established";

	protected final static String REC_USERS_ONLINE_INITIALIZED = "cy.ac.ucy.AndroidTeam.users_online_initialized";

	protected final static String REC_USERS_HAS_PICKED_OPPONENT = "cy.ac.ucy.AndroidTeam.user_picked_opponent";

	public final static String REC_OPPONENT_HAS_PICKED_ME = "cy.ac.ucy.AndroidTeam.opponent_has_picked_me";

	public static final String REC_SERVER_RECEIVED_CLIENT_POSITIVE_REPLY = "cy.ac.ucy.AndroidTeam.client_sent_reply";

	public static final String REC_SERVER_SEND_SELECTED_LEVEL = "cy.ac.ucy.AndroidTeam.server_send_level";

	public static final String REC_DATA_CHANGED_SCORE = "cy.ac.ucy.AndroidTeam.data_changed_score";

	public static final String REC_DATA_CHANGED_COORDINATES = "cy.ac.ucy.AndroidTeam.data_changed_coordinates";

	public static final String REC_DATA_CHANGED_OPPONENT_FINISHED = "cy.ac.ucy.AndroidTeam.data_changed_opponent_finished";

	/** Local Host */
	protected static final String LOCALHOST_IP = "127.0.0.1";

	protected static final String HTTP_TAG = "http://";

	protected static final String PREF_PHP_UCY_CS_URL = "www.cs.ucy.ac.cy/~pmpeis01/";

	protected static final String PREF_PHP_FREE_HOSTING_URL = "www.paschalis.goodluckwith.us/";

	public static final String PREF_PHP_HELIO_HOST_URL = "www.paschalis.heliohost.org/";

	protected static final String PHP_PATH_TO_SCRIPT = "secret98765/game/";

	public static final String PHP_EMAIL_TAG = "email=";

	public static final String PHP_USERGAME_TAG = "usergame=";

	public static final String PHP_LOCAL_IP_TAG = "localip=";

	public static final String PHP_MY_USERGAME = "myuser=";

	public static final String PHP_MY_GMAIL = "mygmail=";

	public static final String PHP_OPP_USER = "oppuser=";

	public static final String PHP_OPP_GMAIL = "oppgmail=";

	/** Port number of the sockets */
	protected static final int SERVER_PORT = 4444;

	/* **** Engine Constants **** */
	/** Camera Width */
	protected static final int CAMERA_WIDTH = 800;

	/** Camera Height */
	protected static final int CAMERA_HEIGHT = 480;

	/* **** Menu Constants **** */
	protected static final int MENU_PLAY_LIVE = 1;

	// protected static final int MENU_PLAY_SINGLE = ;

	protected static final int MENU_OPTIONS = MENU_PLAY_LIVE + 1;

	protected static final int MENU_CREDITS = MENU_OPTIONS + 1;

	protected static final int MENU_SCORES = MENU_CREDITS + 1;

	protected static final int MENU_EXIT_MENU = MENU_SCORES + 1;

	protected static final int MENU_IGNORE = MENU_EXIT_MENU + 1;

	protected static final int MENUEXIT_EXIT = MENU_IGNORE + 1;

	protected static final int MENUEXIT_BACK = MENUEXIT_EXIT + 1;

	protected static final int MENU_NO_WIFI = MENUEXIT_BACK + 1;

	public static final int MENU_NO_PREFERENCES_SET = MENU_NO_WIFI + 1;

	/* Preferences Constants */
	protected static final String PREFS_MAIN_PLAYER = "main_player_prefs";

	protected static final String PREFS_MAIN_PLAYER_ALL_SET = "player_prefs_all_done_and_set";

	protected static final String PREFS_MAIN_PLAYER_GOOG_ACCOUND_LIST_PREF = "player_prefs_google_account_list_preference";

	protected static final String PREFS_MAIN_PLAYER_USERGRAME = "player_prefs_usergame";

	protected static final String PREFS_MAIN_PLAYER_PREFERRED_SERVER = "player_prefs_preferred_server";

	protected static final int DELAY_FETCH_USERS_ONLINE_INTERVAL = 5000;

	protected static final int DELAY_SELECT_LEVEL_AGAIN = 2000;
	
	protected static final int DELAY_RESTORE_USER_WANTS_TO_TERMINATE = 3000;

	// TODO CHANGE BACK TO 5000
	protected static final int DELAY_SPLASH_TIME = 2000;

	// /////////////////////////////////////////////////// //
	// Fields //
	// /////////////////////////////////////////////////// //

	/** Camera of the game */
	private Camera mCamera;

	/** Engine of the game */
	private Engine mEngine;

	/** Engine Options of the game */
	private EngineOptions mEngineOptions;

	/** Hanlder of the game */
	private Handler mHandler;

	// ///// The Scenes of the game
	/** Splash Screen Scene */
	private Scene sceneSplashScreen;

	/** Main menu scene(after splash screen) */
	private Scene sceneMainMenu;

	/***/
	private Scene scenePickLevel;

	/** Options Scene */
	private Scene sceneOptions;

	/** Game Over Scene */
	private Scene sceneGameOver;

	/** MenuScene for main menu */
	private MenuScene menuSceneMainMenu;

	/**
	 * Multi Player Connection Scene CHECK if this should be merged with level
	 * scene!
	 */
	private Scene multiPlayerConnectScene;

	private OnCreateSceneCallback mOnCreateResourcesCallback;

	private OnPopulateSceneCallback mOnPopulateSceneCallback;

	// //// Fonts
	/** font texture */
	private ITexture mFontMenuTexture;

	/** Fonts for Main Menu */
	private Font mFontMenu;

	private ArrayList<String> mgmailAccountsStr;

	/** The User that owns the device */
	private User mySelf;

	/**
	 * The Opponent that user has picked up CHECK make sure to set it to null
	 * AGAIN if user change his mind, or other cases!
	 */
	private User opponent;

	public static User tempOpponent;

	private static String mURLusersOnline;

	private static String mURLfullRefresh;

	private static String mURLusersEnrollment;

	private static String mURLwriteOpponent;

	private static String mURLremoveOpponent;

	private static String mURLopponentChecker;

	private static String mURLCleanUsersOnline;

	private int mPlayLevelByServer;

	/**
	 * Fields in case User is the client (chosen by opponent who will be server)
	 */
	/** What is user? Client? or Server? */
	private NetworkType userNetworkType = NetworkType.Unknown;

	private boolean userAccepted = false;

	private int mOpponentScore = 0;

	public void runOnCreateResourcesCallback() {
		if (mOnCreateResourcesCallback != null)
			mOnCreateResourcesCallback
					.onCreateSceneFinished(multiPlayerConnectScene);
	}

	public void setOnCreateResourcesCallback(
			OnCreateSceneCallback pOnCreateSceneCallback, Scene pScene) {
		this.mOnCreateResourcesCallback = pOnCreateSceneCallback;
		this.multiPlayerConnectScene = pScene;
	}

	public Scene getSceneSplashScreen() {
		return sceneSplashScreen;
	}

	public void setSceneSplashScreen(Scene sceneSplashScreen) {
		this.sceneSplashScreen = sceneSplashScreen;
	}

	public Scene getSceneMainMenu() {
		return sceneMainMenu;
	}

	public void setSceneMainMenu(Scene sceneMainMenu) {
		this.sceneMainMenu = sceneMainMenu;
	}

	public Scene getSceneOptions() {
		return sceneOptions;
	}

	public void setSceneOptions(Scene sceneOptions) {
		this.sceneOptions = sceneOptions;
	}

	public Scene getSceneGameOver() {
		return sceneGameOver;
	}

	public void setSceneGameOver(Scene sceneGameOver) {
		this.sceneGameOver = sceneGameOver;
	}

	public ITexture getmFontMenuTexture() {
		return mFontMenuTexture;
	}

	public void setmFontMenuTexture(ITexture mFontMenuTexture) {
		this.mFontMenuTexture = mFontMenuTexture;
	}

	public Font getmFontMenu() {
		return mFontMenu;
	}

	public void setmFontMenu(Font mFontMenu) {
		this.mFontMenu = mFontMenu;
	}

	public MenuScene getMenuSceneMainMenu() {
		return menuSceneMainMenu;
	}

	public void setMenuSceneMainMenu(MenuScene menuSceneMainMenu) {
		this.menuSceneMainMenu = menuSceneMainMenu;
	}

	public Camera getmCamera() {
		if (mCamera == null)
			this.mCamera = new Camera(0, 0, App.CAMERA_WIDTH, App.CAMERA_HEIGHT);

		return mCamera;
	}

	public void setmCamera(Camera mCamera) {
		this.mCamera = mCamera;
	}

	public Engine getmEngine() {
		if (mEngine == null)
			mEngine = new Engine(getmEngineOptions());

		return mEngine;
	}

	public void setmEngine(Engine mEngine) {
		this.mEngine = mEngine;
	}

	public EngineOptions getmEngineOptions() {
		if (mEngineOptions == null)
			this.mEngineOptions = new EngineOptions(true,
					ScreenOrientation.LANDSCAPE_FIXED,
					new RatioResolutionPolicy(App.CAMERA_WIDTH,
							App.CAMERA_HEIGHT), this.mCamera);
		return mEngineOptions;
	}

	public void setmEngineOptions(EngineOptions mEngineOptions) {
		this.mEngineOptions = mEngineOptions;
	}

	public Scene getScenePickLevel() {
		return scenePickLevel;
	}

	public void setScenePickLevel(Scene scenePickLevel) {
		this.scenePickLevel = scenePickLevel;
	}

	public Handler getmHandler() {
		return mHandler;
	}

	public void setmHandler(Handler mHandler) {
		this.mHandler = mHandler;
	}

	public ArrayList<String> getMgmailAccountsStr() {
		return mgmailAccountsStr;
	}

	public void setMgmailAccountsStr(ArrayList<String> mgmailAccoundsStr) {
		this.mgmailAccountsStr = mgmailAccoundsStr;
	}

	public User getUser() {
		return mySelf;
	}

	public void setUser(User mySelf) {
		this.mySelf = mySelf;
	}

	public User getOpponent() {
		return opponent;
	}

	public void setOpponent(User opponent) {
		this.opponent = opponent;
	}

	public NetworkType getUserNetworkType() {
		return userNetworkType;
	}

	public void setUserNetworkType(NetworkType userNetworkType) {
		this.userNetworkType = userNetworkType;
	}

	public static String getmURLusersOnline() {
		return mURLusersOnline;
	}

	public void setmURLusersOnline(String mURLusersOnline) {
		App.mURLusersOnline = mURLusersOnline;
	}

	public static String getmURLfullRefresh() {
		return mURLfullRefresh;
	}

	public void setmURLfullRefresh(String mURLfullRefresh) {
		App.mURLfullRefresh = mURLfullRefresh;
	}

	public static String getmURLusersEnrollment() {
		return mURLusersEnrollment;
	}

	public void setmURLusersEnrollment(String mURLusersEnrollment) {
		App.mURLusersEnrollment = mURLusersEnrollment;
	}

	public static String getmURLwriteOpponent() {
		return mURLwriteOpponent;
	}

	public void setmURLwriteOpponent(String mURLwriteOpponent) {
		App.mURLwriteOpponent = mURLwriteOpponent;
	}

	public static String getmURLremoveOpponent() {
		return mURLremoveOpponent;
	}

	public void setmURLremoveOpponent(String mURLremoveOpponent) {
		App.mURLremoveOpponent = mURLremoveOpponent;
	}

	public static String getmURLopponentChecker() {
		return mURLopponentChecker;
	}

	public void setmURLopponentChecker(String mURLopponentChecker) {
		App.mURLopponentChecker = mURLopponentChecker;
	}

	public boolean isUserAccepted() {
		return userAccepted;
	}

	public void setUserAccepted(boolean userAccepted) {
		this.userAccepted = userAccepted;
	}

	public static String getmURLCleanUsersOnline() {
		return mURLCleanUsersOnline;
	}

	public static void setmURLCleanUsersOnline(String mURLCleanUsersOnline) {
		App.mURLCleanUsersOnline = mURLCleanUsersOnline;
	}

	public int getmPlayLevelByServer() {
		return mPlayLevelByServer;
	}

	public void setmPlayLevelByServer(int mPlayLevelByServer) {
		this.mPlayLevelByServer = mPlayLevelByServer;
	}

	public CharSequence getmOpponentScore() {
		return new Integer(mOpponentScore).toString();
	}

	public void setmOpponentScore(int mOpponentScore) {
		this.mOpponentScore = mOpponentScore;
	}

	public OnPopulateSceneCallback getmOnPopulateSceneCallback() {
		return mOnPopulateSceneCallback;
	}

	public void setmOnPopulateSceneCallback(
			OnPopulateSceneCallback mOnPopulateSceneCallback) {
		this.mOnPopulateSceneCallback = mOnPopulateSceneCallback;
	}

	// ///////////////////////////////////////////////////////////////
	// //////// INNER CLASSES //////////////////////////////
	// ///////////////////////////////////////////////////////////////
	protected enum EdgeType {
		Up, Ground, Right, Left, Unknown
	}

	public enum SpriteType {
		Square, Circle, Wall, Edge, marble, LooseHole

	}

	public enum WallType {
		Elastic, NonElastic, Unknown

	}

	// /////////////////////////////////////////////////
	// /////////////// Game Scoring ///////////////////
	// /////////////////////////////////////////////////

	// Scores in the game

	public static final byte POINT_CODE_MARBLE_SIMPLE = 1;

	public static final byte POINT_CODE_MARBLE_EXTENDED_1 = 2;

	public static final byte POINT_CODE_MARBLE_ERROR = -1;

	public static final long CHECK_CONNECTION_ESTABLISHED_TIME = 30000;

	protected class GamePoints {

		public static final int SIMPLE_STAR_POINTS = 10;

		public static final int FINISH_LEVEL_POINTS = 1;

	}

	protected enum TargetType {
		Simple, Extended1, Extended2, Unknown
	}

	/**
	 * @param pStr
	 *            the ID of the shape
	 * @return the code of the target
	 * 
	 *         Targets: what user can collect, to increase his/hers points
	 */
	public static byte getTargetPointCode(String pStr) {

		String t = pStr.substring(6);

		if (t.contains("simple")) {
			return POINT_CODE_MARBLE_SIMPLE;
		}
		// if (t.contains("finish"))
		//
		// return TargetType.FinishLevel;
		else {
			return POINT_CODE_MARBLE_ERROR;
		}

	}

	/**
	 * @param code
	 *            the code of score
	 * @return the int value that matches with that score
	 */
	public static int getScoreFromCode(byte code) {
		switch (code) {
		case POINT_CODE_MARBLE_SIMPLE:
			return 10;
		case POINT_CODE_MARBLE_EXTENDED_1:
			return 20;

		default:
			return POINT_CODE_MARBLE_ERROR;
		}

	}

}
