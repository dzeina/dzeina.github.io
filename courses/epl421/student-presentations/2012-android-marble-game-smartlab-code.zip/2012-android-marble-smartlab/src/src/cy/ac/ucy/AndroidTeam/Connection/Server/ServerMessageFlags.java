
package cy.ac.ucy.AndroidTeam.Connection.Server;



public interface ServerMessageFlags {

	// ===========================================================
	// Final Fields
	// ===========================================================

	/* Connection Flags. */
	public static final short	FLAG_MESSAGE_SERVER_CONNECTION_CLOSE					= Short.MIN_VALUE;

	public static final short	FLAG_MESSAGE_SERVER_CONNECTION_ESTABLISHED				= FLAG_MESSAGE_SERVER_CONNECTION_CLOSE + 1;


	public static final short	FLAG_MESSAGE_SERVER_CONNECTION_REJECTED_PROTOCOL_MISSMATCH	= FLAG_MESSAGE_SERVER_CONNECTION_ESTABLISHED + 1;

	public static final short	FLAG_MESSAGE_SERVER_CONNECTION_PONG					= FLAG_MESSAGE_SERVER_CONNECTION_REJECTED_PROTOCOL_MISSMATCH + 1;

	public static final short	FLAG_MESSAGE_SERVER_SEND_COORDINATES					= FLAG_MESSAGE_SERVER_CONNECTION_PONG + 1;

	public static final short	FLAG_MESSAGE_SERVER_SEND_SCORE					= FLAG_MESSAGE_SERVER_SEND_COORDINATES + 1;


	public static final short	FLAG_MESSAGE_SERVER_SEND_FINISHED_LEVEL					= FLAG_MESSAGE_SERVER_SEND_SCORE + 1;

	public static final short	FLAG_MESSAGE_SERVER_SEND_SELECTED_LEVEL					= FLAG_MESSAGE_SERVER_SEND_FINISHED_LEVEL + 1;

}
