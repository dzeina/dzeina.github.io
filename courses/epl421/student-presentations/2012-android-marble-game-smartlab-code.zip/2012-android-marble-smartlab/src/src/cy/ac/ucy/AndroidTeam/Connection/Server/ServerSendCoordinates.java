
package cy.ac.ucy.AndroidTeam.Connection.Server;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.server.ServerMessage;

import android.view.InflateException;





public class ServerSendCoordinates extends ServerMessage implements
		ServerMessageFlags {

	/* Coordinates of Servers Marble */
	private float	x;

	private float	y;





	// Default constructor
	public ServerSendCoordinates() {

	}





	public ServerSendCoordinates(float pX, float pY) {
		this.x = pX;
		this.y = pY;
	}








	/** Returns the flag of the message send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_SERVER_SEND_COORDINATES;
	}





	/**
	 * Read the coordinates of Server's marble
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {

		// Save the two coordinate numbers

		this.setX(pDataInputStream.readFloat());
		this.setY(pDataInputStream.readFloat());



	}





	/**
	 * Write the coordinates of Server's marble to server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {

		pDataOutputStream.writeFloat(x);
		pDataOutputStream.writeFloat(y);

	}





	// Getters & Setters



	public float getX() {
		return x;
	}





	public void setX(float x) {
		this.x = x;
	}





	public float getY() {
		return y;
	}





	public void setY(float y) {
		this.y = y;
	}






}