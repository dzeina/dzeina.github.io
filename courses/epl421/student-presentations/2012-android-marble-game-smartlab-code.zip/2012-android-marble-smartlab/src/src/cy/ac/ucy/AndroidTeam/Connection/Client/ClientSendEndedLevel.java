
package cy.ac.ucy.AndroidTeam.Connection.Client;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.client.ClientMessage;
import org.andengine.extension.multiplayer.protocol.adt.message.client.IClientMessage;





public class ClientSendEndedLevel extends ClientMessage implements
		ClientMessageFlags,
		IClientMessage {

	/** boolean whether the client has finished the level */
	private boolean	mEndedLevel;





	// Default constructor
	public ClientSendEndedLevel() {

	}





	public ClientSendEndedLevel(boolean pEnded) {
		this.setmEndedLevel(pEnded);
	}






	public void set(final boolean pEnded) {
		this.set(pEnded);
	}





	/** Returns the flag of the message send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_CLIENT_SEND_FINISHED_LEVEL;
	}





	/**
	 * Read the boolean where client has ended the level
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {

		this.setmEndedLevel(pDataInputStream.readBoolean());
	}





	/**
	 * Write the decision if  of Client to server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {
		pDataOutputStream.writeBoolean(this.getmEndedLevel());
	}





	public boolean getmEndedLevel() {
		return mEndedLevel;
	}





	public void setmEndedLevel(boolean mEndedLevel) {
		this.mEndedLevel = mEndedLevel;
	}



}