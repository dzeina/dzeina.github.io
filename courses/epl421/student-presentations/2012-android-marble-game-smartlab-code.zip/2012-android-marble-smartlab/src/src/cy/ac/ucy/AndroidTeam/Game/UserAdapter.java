package cy.ac.ucy.AndroidTeam.Game;

import java.util.List;

import cy.ac.ucy.AndroidTeam.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;



/**
 * @author paschalis
 * 
 * Our customized adapter, to show the data to the opponent's row, as WE like!
 * 
 * Binds usergame & timestamp to the appropriate TextView in the opponent's row
 *
 */
public class UserAdapter extends ArrayAdapter<User> {

   int resource;
   String response;
   Context context;
   
   
   //Initialize adapter
   public UserAdapter(Context context, int resource, List<User> items) {
       super(context, resource, items);
       this.resource=resource;

   }

   @Override
   public View getView(int position, View convertView, ViewGroup parent)
   {
       LinearLayout userView;
       //Get the current alert object
       User user = getItem(position);

       //Inflate the view
       if(convertView==null)
       {
     	  userView = new LinearLayout(getContext());
           String inflater = Context.LAYOUT_INFLATER_SERVICE;
           LayoutInflater vi;
           vi = (LayoutInflater)getContext().getSystemService(inflater);
           vi.inflate(resource, userView, true);
       }
       else
       {
     	  userView = (LinearLayout) convertView;
       }
       
       //Bind those to the appropriate places in opponents row
       //Get the text boxes from the listitem.xml file
       TextView usergame =(TextView)userView.findViewById(R.id.textViewUsergame);
       TextView timestamp =(TextView)userView.findViewById(R.id.textViewTimeStamp);

       //Assign the appropriate data from our alert object above
       usergame.setText(user.getmUserGame());
       timestamp.setText(user.getmTimestamp());

       return userView;
   }

}