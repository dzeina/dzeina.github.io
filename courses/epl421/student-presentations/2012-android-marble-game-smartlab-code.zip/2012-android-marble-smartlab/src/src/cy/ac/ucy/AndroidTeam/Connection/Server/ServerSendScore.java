
package cy.ac.ucy.AndroidTeam.Connection.Server;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.server.ServerMessage;





public class ServerSendScore extends ServerMessage implements
		ServerMessageFlags {

	/* Score of Server  */
	private byte mPointCode;





	// Default constructor
	public ServerSendScore() {

	}





	public ServerSendScore(byte pPointCode) {
		this.mPointCode = pPointCode;
	}








	/** Returns the flag of the message send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_SERVER_SEND_SCORE;
	}





	/**
	 * Read the Score of Server
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {


		this.setmPointCode(pDataInputStream.readByte());



	}





	/**
	 * Write the Score of Server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {

		pDataOutputStream.writeByte(mPointCode);
	}





	// Getters & Setters

	public byte getmPointCode() {
		return mPointCode;
	}





	public void setmPointCode(byte pPointCode) {
		this.mPointCode = pPointCode;
	}












}