package cy.ac.ucy.AndroidTeam.Connection.Server;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class contains useful static methods for reading user input.
 * It makes sure that the input is "valid" for some definition of the term.
 * 
 */
public class ValidInputReader {
	// global shared console scanner
	private static final Scanner CONSOLE = new Scanner(System.in);


	/**
	 * Prompts the user to input an integer, reads and returns it,
	 * re-prompting as necessary until the number is in the given range.
	 * @pre prompt != null, min <= max
	 * 
	 * @param prompt message to display while reading input
	 * @param min minimum allowed value, inclusive
	 * @param max maximum allowed value, inclusive
	 * @return the integer that was read; guaranteed to be between min and max inclusive
	 * @throws FileNotFoundException if prompt is null or min > max
	 */
	public static int getValidInt(String prompt, int min, int max) {
		if (prompt == null || min > max) {
			throw new IllegalArgumentException();
		}
		while (true) {
			System.out.print(prompt + " ");
			if (CONSOLE.hasNextInt()) {
				int input = CONSOLE.nextInt();
				CONSOLE.nextLine();
				if (min <= input && input <= max) {
					// a good value; return it
					return input;
				} else {
					// out of range
					System.out.println("Invalid number.  Must be between " + min + " and " + max + ".");
				}
			} else {
				CONSOLE.nextLine();  // throw away the non-int token
				System.out.println("Invalid input.  Must be an integer between " + min + " and " + max + ".");
			}
		}
	}
	
	

	/**
	 * Prompts the user to input a line of input as a string, reads and returns it,
	 * re-prompting as necessary until the line matches the given regular expression.
	 * @pre prompt != null, regex != null
	 * 
	 * @param prompt message to display while reading input
	 * @param regex regular expression that the line must match before returning
	 * @return the integer that was read; guaranteed to match the given regex
	 * @throws FileNotFoundException if prompt or regex is null
	 */
	public static String getValidString(String prompt, String regex) {
		if (prompt == null || regex == null) {
			throw new IllegalArgumentException();
		}
		while (true) {
			System.out.print(prompt + " ");
			String input = CONSOLE.nextLine();
			if (input.matches(regex)) {
				return input;
			} else {
				System.out.println("Invalid input.  Please try again.");
			}
		}
	}


}