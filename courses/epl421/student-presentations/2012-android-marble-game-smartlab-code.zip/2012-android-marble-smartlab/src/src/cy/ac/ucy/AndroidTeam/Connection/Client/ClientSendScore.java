
package cy.ac.ucy.AndroidTeam.Connection.Client;



import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.client.ClientMessage;





public class ClientSendScore extends ClientMessage implements
		ClientMessageFlags {

	/* Coordinates of Clients Marble */
	private byte	mPointCode;




	// Default constructor
	public ClientSendScore() {

	}





	public ClientSendScore(byte pPointCode) {
		mPointCode = pPointCode;
	}








	/** Returns the flag of the message send */
	@Override
	public short getFlag() {

		return FLAG_MESSAGE_CLIENT_SEND_SCORE;
	}





	/**
	 * Read the score of client marble
	 * */
	@Override
	protected void onReadTransmissionData(
			final DataInputStream pDataInputStream) throws IOException {

		// Save the score
		mPointCode = pDataInputStream.readByte();

	}





	/**
	 * Write the score of Client to server
	 * */
	@Override
	protected void onWriteTransmissionData(
			final DataOutputStream pDataOutputStream)
			throws IOException {

		pDataOutputStream.writeByte(mPointCode);

	}


	// Getters & Setters


	public byte getmPointCode() {
		return mPointCode;
	}





	public void setmPointCode(byte pPointCode) {
		this.mPointCode = pPointCode;
	}





	



	





}