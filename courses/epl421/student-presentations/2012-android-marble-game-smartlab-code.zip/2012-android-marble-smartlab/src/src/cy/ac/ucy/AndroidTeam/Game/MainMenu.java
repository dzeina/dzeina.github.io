
package cy.ac.ucy.AndroidTeam.Game;



import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.andengine.engine.Engine;
import org.andengine.engine.camera.Camera;
import org.andengine.engine.options.EngineOptions;
import org.andengine.engine.options.ScreenOrientation;
import org.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.andengine.entity.IEntity;
import org.andengine.entity.modifier.AlphaModifier;
import org.andengine.entity.modifier.IEntityModifier.IEntityModifierListener;
import org.andengine.entity.modifier.ParallelEntityModifier;
import org.andengine.entity.modifier.RotationModifier;
import org.andengine.entity.modifier.ScaleModifier;
import org.andengine.entity.modifier.SequenceEntityModifier;
import org.andengine.entity.scene.Scene;
import org.andengine.entity.scene.background.Background;
import org.andengine.entity.scene.menu.MenuScene;
import org.andengine.entity.scene.menu.MenuScene.IOnMenuItemClickListener;
import org.andengine.entity.scene.menu.item.IMenuItem;
import org.andengine.entity.scene.menu.item.TextMenuItem;
import org.andengine.entity.scene.menu.item.decorator.ColorMenuItemDecorator;
import org.andengine.entity.scene.menu.item.decorator.ScaleMenuItemDecorator;
import org.andengine.entity.sprite.Sprite;
import org.andengine.opengl.font.FontFactory;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.bitmap.BitmapTexture;
import org.andengine.opengl.texture.region.ITextureRegion;
import org.andengine.opengl.texture.region.TextureRegionFactory;
import org.andengine.ui.activity.BaseGameActivity;
import org.andengine.util.adt.io.in.IInputStreamOpener;
import org.andengine.util.color.Color;
import org.andengine.util.debug.Debug;
import org.andengine.util.modifier.IModifier;
import org.andengine.util.modifier.ease.EaseBackOut;
import org.andengine.util.modifier.ease.EaseElasticInOut;
import org.andengine.util.modifier.ease.EaseElasticOut;
import org.andengine.util.modifier.ease.EaseQuintOut;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.opengl.GLES20;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;
import cy.ac.ucy.AndroidTeam.R;
import cy.ac.ucy.AndroidTeam.Connection.Server.PHPServerConnection;






public class MainMenu extends BaseGameActivity implements
		IOnMenuItemClickListener {








	protected static final String	TAG	= MainMenu.class.getSimpleName();

	/** Marble Application */
	App					app;

	private Camera			mCamera;

	private Engine			mEngine;

	private Scene			mScene;
	
	private EngineOptions	mEngineOptions;

	// This Activity Textures
	private ITextureRegion	mSplashBackgroundTextureRegion;

	private BitmapTexture	mTexture;

	/** Background Sprite */
	private Sprite			mBackgroundSprite;

	
	// Menu Items
	/** Exit menu items*/
	private IMenuItem playLiveMenuItem;
	private IMenuItem scoresMenuItem;
	private IMenuItem optionsMenuItem;
	private IMenuItem creditsMenuItem;
	private IMenuItem exitMenuItem;
	
	
	private SharedPreferences mPlayerprefs;
	
	private AlertDialog exitAlert;


	/* ***** Runnable to start the Main Menu ***** */
	// @formatter:off
	private Runnable	mRunShowMainMenu	= new Runnable() {

		public void run() {
			//app.getmEngine().setScene(app.getSceneMainMenu());
			app.getSceneSplashScreen().setChildScene(app.getMenuSceneMainMenu());
			}
	};
	
	
	private Runnable	mRunChooseOpponent	= new Runnable() {

		public void run() {
				Intent myIntent = new Intent(MainMenu.this, ChooseOpponent.class);
				// Launch the intent
				MainMenu.this.startActivity(myIntent);
			}
	};
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	private Runnable	mRunOpenWifiSettings	= new Runnable() {

		public void run() {
			//Open wifi settings
			final Intent intent = new Intent(Intent.ACTION_MAIN, null);
			
			intent.addCategory(Intent.CATEGORY_LAUNCHER);
			final ComponentName cn = new ComponentName(
					"com.android.settings",
					"com.android.settings.wifi.WifiSettings");
			intent.setComponent(cn);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);

		
		}
	};
	
	
	
	private Runnable mRunOpenPlayerPreferences = new Runnable() {
		
		@Override
		public void run() {
			// Open preferences activity
			Intent myIntent = new Intent(getApplicationContext(),
					PlayerPreferences.class);
			startActivity(myIntent);
			
		}
	};
	
	
	
	
	
	
	
	
	
	private Runnable mRunRestoreInitialMainMenu = new Runnable() {
		
		@Override
		public void run() {
			//restore back the initial scene
			buildInitialMainMenuScene();
			
		}
	};

	
	
	
	private Runnable mRunRestorePlayLiveMenuItemMovement = new Runnable() {
		
		@Override
		public void run() {
			//restore the movement of the play Live Menu Item Movement
			restoreMovementMenuItem(playLiveMenuItem);
			
		}
	};

	
//	private Runnable mRunRestoreExitMenuItemMovement = new Runnable() {
//		
//		@Override
//		public void run() {
//			//restore the movement of the play Live Menu Item Movement
//			restoreMovementMenuItem(exitMenuItem);
//			
//		}
//	
//	};
	

	
	// @formatter:on


	/**
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
	public EngineOptions onCreateEngineOptions() {

		app = (App) getApplication();

		this.mCamera = new Camera(0, 0, App.CAMERA_WIDTH, App.CAMERA_HEIGHT);

		app.setmCamera(mCamera);

		app.setmHandler(new Handler());

		this.mEngineOptions = new EngineOptions(true,
				ScreenOrientation.LANDSCAPE_FIXED,
				new RatioResolutionPolicy(App.CAMERA_WIDTH,
						App.CAMERA_HEIGHT),
				this.mCamera);

		app.setmEngineOptions(mEngineOptions);

		mEngine = new Engine(mEngineOptions);

		app.setmEngine(mEngine);

		// Get the preferences
		mPlayerprefs = PreferenceManager.getDefaultSharedPreferences(this);
		// mPlayerPrefsEditor = mPlayerprefs.edit();


		// Save User's Google Accounts
		app.setMgmailAccountsStr(new ArrayList<String>());

		Account[] allAccounds = AccountManager.get(this).getAccountsByType(
				"com.google");

		for (Account account : allAccounds){
			// Add only the google accound username (not the @gmail.com)
			app.getMgmailAccountsStr().add(account.name.split("@")[0]);
		}


		return mEngine.getEngineOptions();
	}





	/**
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
	@Override
	public void onCreateResources(
			OnCreateResourcesCallback pOnCreateResourcesCallback)
			throws Exception {

		try{
			// ******* 1) Create the texture for the marble
			this.mTexture = new BitmapTexture(getTextureManager(),
					new IInputStreamOpener() {

						@Override
						public InputStream open() throws IOException {
							return getResources().openRawResource(
									R.drawable.splash);
						}
					});

			// Extract from Texture the TextureRegion of Marble
			this.mSplashBackgroundTextureRegion = TextureRegionFactory
					.extractFromTexture(this.mTexture);
			// Load the texture for the marble
			this.mTexture.load();
		}
		catch (IOException e){
			Debug.e(e);
		}


		FontFactory.setAssetBasePath("font/");
		// Create and load the font texture
		app.setmFontMenuTexture(new BitmapTextureAtlas(getTextureManager(),
				512,
				512, TextureOptions.BILINEAR_PREMULTIPLYALPHA));


		// Create fonts to display our score
		app.setmFontMenu(FontFactory.createFromAsset(getFontManager(),
				app.getmFontMenuTexture(),
				getAssets(), "edo.ttf", 60, true,
				android.graphics.Color.WHITE));

		this.getTextureManager().loadTexture(app.getmFontMenuTexture());

		// app.getmFontMenuTexture().load();
		app.getmFontMenu().load();


		pOnCreateResourcesCallback.onCreateResourcesFinished();
	}





	@Override
	public void onCreateScene(OnCreateSceneCallback pOnCreateSceneCallback)
			throws Exception {

		// Create a new scene
		mScene = new Scene();
		// Save also to App
		app.setSceneSplashScreen(mScene);

		mScene.setBackground(new Background(0.415686275f, 0.352941176f,
				0.803921569f, 0.0f));

		float centerX = App.CAMERA_WIDTH / 2
				- mSplashBackgroundTextureRegion.getWidth() / 2;
		float centerY = App.CAMERA_HEIGHT / 2
				- mSplashBackgroundTextureRegion.getHeight() / 2;

		// Create the background
		mBackgroundSprite = new Sprite(centerX,
				centerY,
				mSplashBackgroundTextureRegion, this
						.getVertexBufferObjectManager());

		// Attach a background
		mScene.attachChild(mBackgroundSprite);

		mBackgroundSprite.registerEntityModifier(new SequenceEntityModifier
				(new ParallelEntityModifier(new ScaleModifier(2.5f, 0.5f,
						2f, EaseBackOut.getInstance()),
						new RotationModifier(2f, 0.0f, 180.0f,
								EaseElasticOut.getInstance()),
						new AlphaModifier(2f, 1.0f, 0.2f, EaseElasticOut
								.getInstance()))
						,
						new ParallelEntityModifier(new ScaleModifier(
								2.5f, 2f, 0.4f, EaseBackOut
										.getInstance()),
								new RotationModifier(2f, 180.0f,
										360.0f, EaseElasticOut
												.getInstance()),
								new AlphaModifier(2f, 0.2f, 0.1f,
										EaseElasticOut.getInstance())
						)

						,
						new ScaleModifier(
								0.5f, 0.4f, 1.5f, EaseBackOut
										.getInstance())
				)
				);






		pOnCreateSceneCallback.onCreateSceneFinished(mScene);
	}





	@Override
	public void onPopulateScene(Scene pScene,
			OnPopulateSceneCallback pOnPopulateSceneCallback)
			throws Exception {


		// Load new resources and scenes ** Nice ;) **
		createResources();
		createScenes();

		// Switch to Main Menu Scene
		app.getmHandler().postDelayed(mRunShowMainMenu, App.DELAY_SPLASH_TIME);

		pOnPopulateSceneCallback.onPopulateSceneFinished();
	}





	// ===========================================================
	// Methods
	// ===========================================================
	/**
	 * 
	 * 
	 * 
	 * Create all the resources needed for the game (as the user watches the
	 * splash screen)
	 * 
	 * 
	 * 
	 * */
	public void createResources() {

		// menu resources

		// help resources

		// pick level resources
		// game resources
	}





	public void createScenes() {

		// Create a new scene
		createMainMenuScene();
		// mMenuScene = new Scene();
		// Set the menu scenes background!
		// mMenuScene.setBackground(new Background(0, 0, 128));


		// help scene
		// pick level scene
		// game scene
	}









	/* ***** Creating Scenes ***** */

	/**
	 * 
	 * 
	 * 
	 * Creates the Scene for the Main Menu of the game Main Menu Scene, is
	 * shown when Splash Screen Ends!
	 * 
	 * 
	 * 
	 */
	private void createMainMenuScene() {

		app.setSceneMainMenu(new Scene());

		app.getSceneMainMenu().setBackground(
				new Background(0.415686275f, 0.352941176f, 0.803921569f,
						0.0f));
		// Create the new menuScene
		app.setMenuSceneMainMenu(new MenuScene(mCamera));

		// Create menu items, which are scalable and change their color too
		playLiveMenuItem = new ScaleMenuItemDecorator(
				new ColorMenuItemDecorator(
						new TextMenuItem(App.MENU_PLAY_LIVE,
								app.getmFontMenu(), "Play Live",
								this.getVertexBufferObjectManager()),
						new Color(
								Color.WHITE), new Color(0.098039216f,
								0.098039216f,
								0.439215686f)), 1.5f, 1.0f);

		playLiveMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		// The rest are the same
		this.createBasicMainMenuScene();


	}





	/**
	 * 
	 * 
	 * 
	 * In case user hasn't set his preferences
	 * 
	 * 
	 * 
	 */

	private void createNoPreferencesSetMenuScene() {
		app.setSceneMainMenu(new Scene());

		app.getSceneMainMenu().setBackground(
				new Background(0.415686275f, 0.352941176f, 0.803921569f,
						0.0f));
		// Create the new menuScene
		app.setMenuSceneMainMenu(new MenuScene(mCamera));

		// Create menu items, which are scalable and change their color too
		playLiveMenuItem = new ColorMenuItemDecorator(new TextMenuItem(
				App.MENU_NO_PREFERENCES_SET,
				app.getmFontMenu(), "No Preferences Set",
				this.getVertexBufferObjectManager()),
				Color.RED, Color.RED);

		playLiveMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		// The rest are the same
		this.createBasicMainMenuScene();
	}





	/**
	 * 
	 * 
	 * 
	 * In case no network has detected
	 * 
	 * 
	 * 
	 * */
	private void createMainNoWifiMenuScene() {
		app.setSceneMainMenu(new Scene());

		app.getSceneMainMenu().setBackground(
				new Background(0.415686275f, 0.352941176f, 0.803921569f,
						0.0f));
		// Create the new menuScene
		app.setMenuSceneMainMenu(new MenuScene(mCamera));

		// Create menu items, which are scalable and change their color too
		playLiveMenuItem = new ColorMenuItemDecorator(new TextMenuItem(
				App.MENU_NO_WIFI,
				app.getmFontMenu(), "No Network Access",
				this.getVertexBufferObjectManager()),
				Color.RED, Color.RED);

		playLiveMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		// The rest are the same
		this.createBasicMainMenuScene();
	}





	/**
	 * 
	 * 
	 * 
	 * 
	 * The basic Item menus, that dont change
	 * 
	 * 
	 * 
	 * */
	private void createBasicMainMenuScene() {

		scoresMenuItem = new ScaleMenuItemDecorator(
				new ColorMenuItemDecorator(
						new TextMenuItem(App.MENU_SCORES,
								app.getmFontMenu(), "Scores",
								this.getVertexBufferObjectManager()),
						new Color(
								Color.WHITE), new Color(0.098039216f,
								0.098039216f,
								0.439215686f)), 1.5f, 1.0f);
		scoresMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		optionsMenuItem = new ScaleMenuItemDecorator(
				new ColorMenuItemDecorator(
						new TextMenuItem(App.MENU_OPTIONS,
								app.getmFontMenu(), "Options",
								this.getVertexBufferObjectManager()),
						new Color(
								Color.WHITE), new Color(0.098039216f,
								0.098039216f,
								0.439215686f)), 1.5f, 1.0f);
		optionsMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		creditsMenuItem = new ScaleMenuItemDecorator(
				new ColorMenuItemDecorator(
						new TextMenuItem(App.MENU_CREDITS,
								app.getmFontMenu(), "Credits",
								this.getVertexBufferObjectManager()),
						new Color(
								Color.WHITE), new Color(0.098039216f,
								0.098039216f,
								0.439215686f)), 1.5f, 1.0f);
		creditsMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);

		exitMenuItem = new ScaleMenuItemDecorator(
				new ColorMenuItemDecorator(
						new TextMenuItem(App.MENU_EXIT_MENU,
								app.getmFontMenu(), "Exit",
								this.getVertexBufferObjectManager()),
						new Color(
								Color.WHITE), new Color(0.098039216f,
								0.098039216f,
								0.439215686f)), 1.5f, 1.0f);
		exitMenuItem.setBlendFunction(GLES20.GL_SRC_ALPHA,
				GLES20.GL_ONE_MINUS_SRC_ALPHA);


		// Attach all the menu items
		attachMainMenuItems();
		finilizeMenu();

	}














	/**
	 * 
	 * 
	 * Attaches all the main menu items to MenuScene
	 * 
	 * 
	 * */
	private void attachMainMenuItems() {

		// Add those items to menuScene
		app.getMenuSceneMainMenu().addMenuItem(playLiveMenuItem);
		app.getMenuSceneMainMenu().addMenuItem(scoresMenuItem);
		// app.getMenuSceneMainMenu().addMenuItem(spaceItem);
		app.getMenuSceneMainMenu().addMenuItem(optionsMenuItem);
		// app.getMenuSceneMainMenu().addMenuItem(spaceItem);
		app.getMenuSceneMainMenu().addMenuItem(creditsMenuItem);
		// app.getMenuSceneMainMenu().addMenuItem(spaceItem);
		app.getMenuSceneMainMenu().addMenuItem(exitMenuItem);

	}










	/**
	 * 
	 * Finilizes the menu
	 * 
	 * */
	private void finilizeMenu() {
		// Build the menu
		app.getMenuSceneMainMenu().buildAnimations();
		app.getMenuSceneMainMenu().setBackgroundEnabled(false);

		app.getMenuSceneMainMenu().setOnMenuItemClickListener(this);
	}





	/**
	 * 
	 * 
	 * Build the Initial main menu scene
	 * 
	 * 
	 * */
	private void buildInitialMainMenuScene() {
		app.getMenuSceneMainMenu().detachChildren();

		createMainMenuScene();

		// Recycle that scene
		app.getSceneSplashScreen().clearChildScene();
		app.getSceneSplashScreen().setChildScene(
				app.getMenuSceneMainMenu());
	}





	/**
	 * 
	 * 
	 * Builds the whole no wifi main menu scene
	 * 
	 * 
	 * */
	private void buildNoPreferencesSetScene() {
		app.getMenuSceneMainMenu().detachChildren();
		createNoPreferencesSetMenuScene();


		// Recycle that scene
		app.getSceneSplashScreen().clearChildScene();
		app.getSceneSplashScreen().setChildScene(
				app.getMenuSceneMainMenu());
	}












	/**
	 * 
	 * 
	 * Builds the whole no wifi main menu scene
	 * 
	 * 
	 * */
	private void buildNoWifiScene() {
		app.getMenuSceneMainMenu().detachChildren();
		createMainNoWifiMenuScene();


		// Recycle that scene
		app.getSceneSplashScreen().clearChildScene();
		app.getSceneSplashScreen().setChildScene(
				app.getMenuSceneMainMenu());
	}













	/** Show a Toast Messsage */
	private void showToast(final String Message) {
		MainMenu.this.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(
						MainMenu.this,
						Message,
						Toast.LENGTH_LONG).show();
			}
		});
	}





	/**
	 * 
	 * 
	 * 
	 * Runs when a menu Item is clicked
	 * 
	 * 
	 * 
	 * */
	@Override
	public boolean onMenuItemClicked(MenuScene pMenuScene,
			IMenuItem pMenuItem, float pMenuItemLocalX, float pMenuItemLocalY) {
		switch (pMenuItem.getID()) {

			case App.MENU_PLAY_LIVE:
				Log.d(TAG, "Chosen Play Multi");
				addBackgroundFancyAnimation();

				// If no preferences set
				if (!mPlayerprefs.getBoolean(App.PREFS_MAIN_PLAYER_ALL_SET,
						false)){

					// Build the no preferences set Scene
					buildNoPreferencesSetScene();

					// @formatter:off
					this.playLiveMenuItem
							.registerEntityModifier(
							new ParallelEntityModifier(new IEntityModifierListener() {
								
								@Override
								public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {
								}
			
								@Override
								public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
									app.getmHandler().post(mRunOpenPlayerPreferences);
								}
							}
								,
								new AlphaModifier(2.0f, 0.0f, 1.0f,EaseElasticInOut.getInstance()),
								new ScaleModifier(2.0f, 5.0f,1.0f, EaseElasticOut.getInstance())
									));
			
			
					showToast("\nPlease Set up your Preferences\n");;
					
					//Restore the Initial Main Menu, when user is moved to Preferences
					app.getmHandler().postDelayed(mRunRestoreInitialMainMenu, 2000);
					app.getmHandler().postDelayed(mRunRestorePlayLiveMenuItemMovement, 2001);
					
					// @formatter:on

					return true;

				}





				// User dont have an internet connection
				else if (!PHPServerConnection
						.haveNetworkConnection(getApplicationContext())){
					Log.d(TAG, "No internet connection.");

					// Build the now wifi Scene
					buildNoWifiScene();

					// @formatter:off
						this.playLiveMenuItem
								.registerEntityModifier(
								new ParallelEntityModifier(new IEntityModifierListener() {
									
									@Override
									public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {
										
									}
									
									@Override
									public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
										app.getmHandler().post(mRunOpenWifiSettings);
									}
								}
										,
										new AlphaModifier(2.0f, 0.0f, 1.0f,EaseElasticInOut.getInstance()),
									new ScaleModifier(2.0f, 5.0f,1.0f, EaseElasticOut.getInstance())));
						
						showToast("\nDont worry!\n"
								+ 	"Opening WiFi Settings\n");
						

		
						
						//Restore the Initial Main Menu, when user is moved to wifi settings
						app.getmHandler().postDelayed(mRunRestoreInitialMainMenu, 2000);
						app.getmHandler().postDelayed(mRunRestorePlayLiveMenuItemMovement, 2001);
						restoreMovementMenuItem(playLiveMenuItem);
						// @formatter:on


					return true;

				}
				// Preferences are fine
				// Network Connection is fine
				else{

					// Register movements for the items
					this.playLiveMenuItem
							.registerEntityModifier(new ParallelEntityModifier(
								new IEntityModifierListener() {

					// @formatter:off					
					@Override
					public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {
						
					}

					@Override
					public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
						app.getmHandler().post(mRunChooseOpponent);
						
						//make the play menu item reappear (in similar way it dissapeared)
						restoreMovementMenuItem(playLiveMenuItem);
										}
									}//End of inner-anonymous class
								
					,
					new ScaleModifier(0.5f, 1.0f, 4.0f),
					new AlphaModifier(0.5f, 1.0f, 0.0f)));
				
				// @formatter:on	

					return true;


				}
			case App.MENU_SCORES:
				Log.d(TAG, "Chosen Scores");
				addBackgroundFancyAnimation();
				
				// Register movements for the items
				this.scoresMenuItem
						.registerEntityModifier(new ParallelEntityModifier(
							new IEntityModifierListener() {

				// @formatter:off					
				@Override
				public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {
					
				}

				@Override
				public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
					
					//make the play menu item reappear (in similar way it dissapeared)
					restoreMovementMenuItem(scoresMenuItem);
									}
								}//End of inner-anonymous class
							
				,
				new ScaleModifier(0.5f, 1.0f, 4.0f),
				new AlphaModifier(0.5f, 1.0f, 0.0f)));
				
				
				

				return true;
			case App.MENU_OPTIONS:
				Log.d(TAG, "Chosen Options");

				addBackgroundFancyAnimation();

				// Register movements for the items
				this.optionsMenuItem
						.registerEntityModifier(new ParallelEntityModifier(
								new IEntityModifierListener() {




				// @formatter:off					
				@Override
				public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {}

				@Override
				public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
					// Open preferences activity
					Intent myIntent = new Intent(getApplicationContext(),
							PlayerPreferences.class);
					startActivity(myIntent);
					
					//make the option menu item reappear (in similar way it dissapeared)
					restoreMovementMenuItem(optionsMenuItem);
									}
				}//End of inner-anonymous class
							
				,
				new ScaleModifier(0.5f, 1.0f, 4.0f),
				new AlphaModifier(0.5f, 1.0f, 0.0f)));
			
				// @formatter:on	

				return true;
			case App.MENU_CREDITS:
				Log.d(TAG, "Chosen Credits");

				addBackgroundFancyAnimation();
				return true;




			case App.MENU_EXIT_MENU:
				Log.d(TAG, "Chosen Exit");


				addBackgroundFancyAnimation();

				// Register movements for the items
				this.exitMenuItem
						.registerEntityModifier(new ParallelEntityModifier(
								new IEntityModifierListener() {




				// @formatter:off					
				@Override
				public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {}

				@Override
				public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							createExitDialog();
							//isExitAlertShowing=true;
							exitAlert.show();
							
						}
					});
					
					
					
					
				// Open preferences activity
				//	buildExitMenuScene();
					}
				}//End of inner-anonymous class
							
				,
				new ScaleModifier(0.5f, 1.0f, 4.0f),
				new AlphaModifier(0.5f, 1.0f, 0.0f)));

				return true;

//			case App.MENUEXIT_EXIT:
//				System.exit(0);
//
//			case App.MENUEXIT_BACK:
//				Log.d(TAG, "Chosen Back");
//				buildInitialMainMenuScene();
//				
//				//restore exit items movement
//				restoreMovementMenuItem(exitMenuItem);

			case App.MENU_IGNORE:
				// do nothing!
				return true;
			default:
				return false;
		}
		// Something wrong happened
	}
	
	
	
	
	
	
	
	
	/**
	 * 
	 * 
	 * 
	 * @param pMenuItem to register movements
	 * 
	 * 
	 * 
	 */
	private void restoreMovementMenuItem(IMenuItem pMenuItem){
		//make the play menu item reappear (in similar way it dissapeared)
		pMenuItem.registerEntityModifier(new
				ParallelEntityModifier(
						new ScaleModifier(0.5f, 4.0f, 1.0f),
						new AlphaModifier(0.5f, 0.0f, 1.0f)));
	}
	
	
	
	/**
	 * Adds a fancy animation to background Sprite
	 * 
	 * 
	 * */
	
	private void addBackgroundFancyAnimation(){
		 mBackgroundSprite.registerEntityModifier(
     			 new RotationModifier(0.7f, 360.0f, 0.0f,
     					 EaseElasticOut.getInstance())
     			 );
	}
	
	


	/** ignore back button??? */
	@Override
	public boolean onKeyUp(final int pKeyCode, final KeyEvent pEvent) {
		switch (pKeyCode) {
			case KeyEvent.KEYCODE_BACK:
				
				addBackgroundFancyAnimation();
				
				
				//Register movements for the items
				this.exitMenuItem
						.registerEntityModifier(new ParallelEntityModifier(
							new IEntityModifierListener() {

				// @formatter:off					
				@Override
				public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {}

				@Override
				public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
					runOnUiThread(new Runnable() {
						
						@Override
						public void run() {
							if(exitAlert==null){
								createExitDialog();
							}

							exitAlert.show();
							
						}
					});
					
					
					
					
				// Open preferences activity
				//	buildExitMenuScene();
					}
				}//End of inner-anonymous class
							
				,
				new ScaleModifier(0.5f, 1.0f, 4.0f),
				new AlphaModifier(0.5f, 1.0f, 0.0f)));
				
				
				

					
					

				return true;
		}
		return super.onKeyUp(pKeyCode, pEvent);
	}


	
	
	private void createExitDialog(){
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Are you sure you want to exit?")
		
		       .setCancelable(true)
		       
		       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
		           public void onClick(DialogInterface dialog, int id) {
		          	 
		          	addBackgroundFancyAnimation();
		          	 
		          	 
		          	 
		          	 
		          	 exitMenuItem.registerEntityModifier(
		          			 new ParallelEntityModifier(
		          					 new IEntityModifierListener() {
										
						@Override
						public void onModifierStarted(IModifier<IEntity> pModifier, IEntity pItem) {
						}
						
						
						
						
						
						@Override
						public void onModifierFinished(IModifier<IEntity> pModifier, IEntity pItem) {
							 //End this activity
				                MainMenu.this.finish();	
						}
									},
		          			 new ParallelEntityModifier
		          			 (new ScaleModifier(0.7f, 3.0f, 7.0f,
		          					 EaseQuintOut.getInstance()),
				new AlphaModifier(0.7f, 0.5f, 0.1f))));
		          	 
		          	
		           }
		       })
		       .setNegativeButton("No", new DialogInterface.OnClickListener() {
		           public void onClick(DialogInterface dialog, int id) {
		                dialog.cancel();
		           }
		       });
		
		builder.setOnCancelListener(new OnCancelListener() {
			
			@Override
			public void onCancel(DialogInterface dialog) {
				//make the option menu item reappear (in similar way it dissapeared)
				restoreMovementMenuItem(exitMenuItem);
				
			}
		});
		
		
		exitAlert = builder.create();
	}
	
	
	
	
	
	
	
}