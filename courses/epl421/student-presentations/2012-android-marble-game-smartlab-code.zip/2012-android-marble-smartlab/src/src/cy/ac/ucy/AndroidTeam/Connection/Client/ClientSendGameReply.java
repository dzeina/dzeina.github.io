package cy.ac.ucy.AndroidTeam.Connection.Client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.extension.multiplayer.protocol.adt.message.client.ClientMessage;
import org.andengine.extension.multiplayer.protocol.adt.message.client.IClientMessage;


public class ClientSendGameReply  extends ClientMessage implements ClientMessageFlags,
IClientMessage{
		/** The reply of Client to servers question:
		 * will you play with me?  */
		private boolean reply;




		//Default constructor
		public ClientSendGameReply() {

		}



		
		public ClientSendGameReply(boolean pReply) {
			this.setReply(pReply);
		}






		public void set(final boolean pReply) {
			this.setReply(pReply);
		}




		/** Returns the flag of the message send */
		@Override
		public short getFlag() {
			
			return FLAG_MESSAGE_CLIENT_SEND_CONNECTION_REPLY;
		}




		
		/** 
		 * Read the boolean reply of client response
		 *  */
		@Override
		protected void onReadTransmissionData(
				final DataInputStream pDataInputStream) throws IOException {
			
			this.setReply(pDataInputStream.readBoolean());
		}



		
		/**
		 * Write the reply of Client to server
		 * */
		@Override
		protected void onWriteTransmissionData(
				final DataOutputStream pDataOutputStream)
				throws IOException {
			pDataOutputStream.writeBoolean(this.getReply());
		}




		public boolean getReply() {
			return reply;
		}




		public void setReply(boolean reply) {
			this.reply = reply;
		}

		
	}