
package cy.ac.ucy.AndroidTeam.Game;



import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import cy.ac.ucy.AndroidTeam.Connection.Server.PHPServerConnection;





/**
 * @author paschalis
 * 
 *         Fetchs data for online users from cloud
 * 
 */
public class UsersOnlineRefresherService extends Service {
	
	private static final String TAG = UsersOnlineRefresherService.class.getSimpleName();

	UsersUpdater		usersUpdater;

	private boolean	isRunning	= false;
	
	App app;





	@Override
	public void onCreate() {
		super.onCreate();

		usersUpdater = new UsersUpdater();
		
		app = (App) getApplication();


	}


	


	@Override
	public synchronized void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);

		if (!isRunning){
			usersUpdater.start();
			isRunning = true;
		}
	}





	@Override
	public synchronized void onDestroy() {
		super.onDestroy();

		if (isRunning)
			usersUpdater.interrupt();
	}





	public class UsersUpdater extends Thread {

		@Override
		public void run() {

			while (isRunning){
				

				// Refresh the Online Users

				// Download all Online Users Data
				PHPServerConnection
						.downloadOnlineUsersData(app.getUser());
				
				// We send a broadcast, within our application so the game flow
				// can move onPopulateScene method
				sendBroadcast(new Intent(App.REC_USERS_ONLINE_INITIALIZED));
				
				switch (PHPServerConnection.openUsersBattlesFile(app.getUser())) {
					case OPPONENT_FOUND:
						
						// Inform the world, that i was chosen to play game
						sendBroadcast(new Intent(App.REC_OPPONENT_HAS_PICKED_ME));
											
						break;

					default:
						
						break;
				}
				


				try{
					Thread.sleep(App.DELAY_FETCH_USERS_ONLINE_INTERVAL);
				}
				catch (InterruptedException e){
					// Thread interrupted
					isRunning = false;
				}

			}


		}

	}





	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}



}
