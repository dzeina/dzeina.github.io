/*
 * AirPlace:  The Airplace Project is an OpenSource Indoor and Outdoor
 * Localization solution using WiFi RSS (Receive Signal Strength).
 * The AirPlace Project consists of three parts:
 *
 *  1) The AirPlace Logger (Ideal for collecting RSS Logs)
 *  2) The AirPlace Server (Ideal for transforming the collected RSS logs
 *  to meaningful RadioMap files)
 *  3) The AirPlace Tracker (Ideal for using the RadioMap files for
 *  indoor localization)
 *
 * It is ideal for spaces where GPS signal is not sufficient.
 *
 * Authors:
 * C. Laoudias, G.Larkou, G. Constantinou, M. Constantinides, S. Nicolaou,
 *
 * Supervisors:
 * D. Zeinalipour-Yazti and C. G. Panayiotou
 *
 * Copyright (c) 2011, KIOS Research Center and Data Management Systems Lab (DMSL),
 * University of Cyprus. All rights reserved.
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * Υou should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package cy.com.airplacersslogger;

import java.util.ArrayList;

import cy.com.movement.MovementDetector;

/**
 * 
 * @author Kyriakos Georgiou
 * 
 *         Have put the ArrayList<LogRecord> into this class so more info can be
 *         utilized regarding this sample, at the moment the only extra info is
 *         the movement state of the user while this sample was taken
 * 
 */
public class Sample {

	private ArrayList<LogRecord> logrecs = new ArrayList<LogRecord>();

	/*
	 * Mark as Walking or Standing, depending how the user was moving while the
	 * sample was taken
	 */
	private MovementDetector.MovementState stateTaken;

	public Sample(ArrayList<LogRecord> lr, MovementDetector.MovementState state) {
		this.logrecs = lr;
		this.stateTaken = state;
	}

	public ArrayList<LogRecord> getLogRecords() {
		return this.logrecs;
	}

	public void addLogRecord(LogRecord lr) {
		this.logrecs.add(lr);
	}

	public MovementDetector.MovementState getStateTaken() {
		return this.stateTaken;
	}
}
