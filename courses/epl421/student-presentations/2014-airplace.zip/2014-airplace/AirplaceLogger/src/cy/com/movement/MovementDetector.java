/*
 * AirPlace:  The Airplace Project is an OpenSource Indoor and Outdoor
 * Localization solution using WiFi RSS (Receive Signal Strength).
 * The AirPlace Project consists of three parts:
 *
 *  1) The AirPlace Logger (Ideal for collecting RSS Logs)
 *  2) The AirPlace Server (Ideal for transforming the collected RSS logs
 *  to meaningful RadioMap files)
 *  3) The AirPlace Tracker (Ideal for using the RadioMap files for
 *  indoor localization)
 *
 * It is ideal for spaces where GPS signal is not sufficient.
 *
 * Authors:
 * C. Laoudias, G.Larkou, G. Constantinou, M. Constantinides, S. Nicolaou,
 *
 * Supervisors:
 * D. Zeinalipour-Yazti and C. G. Panayiotou
 *
 * Copyright (c) 2011, KIOS Research Center and Data Management Systems Lab (DMSL),
 * University of Cyprus. All rights reserved.
 *
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * Υou should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package cy.com.movement;

import java.util.ArrayList;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * 
 * @author Kyriakos Georgiou
 * @author 
 *         https://github.com/bagilevi/android-pedometer/blob/master/src/name/bagi
 *         /levente/pedometer/StepDetector.java
 * 
 * 
 *         Step detector, if no steps are being detected, the user is standing.
 *         If steps are being detected, the user is moving.
 * 
 */
public class MovementDetector implements SensorEventListener {

	/*
	 * Determines how fast the transition between walking to standing happens,
	 * give a chance for a long step to take place
	 */
	private static final int STANDING_DELAY = 50;

	private static float sensitivity = 4.5f;

	public enum MovementState {
		WALKING, STANDING
	};

	private MovementState currentState = MovementState.STANDING;

	private float mLastValues[] = new float[3 * 2];
	private float mScale[] = new float[2];
	private float mYOffset;

	private float mLastDirections[] = new float[3 * 2];
	private float mLastExtremes[][] = { new float[3 * 2], new float[3 * 2] };
	private float mLastDiff[] = new float[3 * 2];
	private int mLastMatch = -1;

	private int noStep = 0;

	private ArrayList<MovementListener> mStepListeners = new ArrayList<MovementListener>();

	public MovementDetector() {
		int h = 480;
		mYOffset = h * 0.5f;
		mScale[0] = -(h * 0.5f * (1.0f / (SensorManager.STANDARD_GRAVITY * 2)));
		mScale[1] = -(h * 0.5f * (1.0f / (SensorManager.MAGNETIC_FIELD_EARTH_MAX)));
	}

	public static void setSensitivity(float s) {
		// Suggested sensitivity values, more sensitive as values go down
		// 1.97 2.96 4.44 6.66 10.00 15.00 22.50 33.75 50.62
		sensitivity = s;
	}

	public void addStepListener(MovementListener ml) {
		mStepListeners.add(ml);
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		Sensor sensor = event.sensor;
		synchronized (this) {

			if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

				float vSum = 0;
				/* Sum x, y, z axis values */
				for (int i = 0; i < 3; i++) {
					final float v = mYOffset + event.values[i] * mScale[1];
					vSum += v;
				}
				int k = 0;
				float v = vSum / 3;

				float direction = (v > mLastValues[k] ? 1
						: (v < mLastValues[k] ? -1 : 0));
				if (direction == -mLastDirections[k]) {
					/* Direction changed minumum or maximum? */
					int extType = (direction > 0 ? 0 : 1);
					mLastExtremes[extType][k] = mLastValues[k];
					float diff = Math.abs(mLastExtremes[extType][k]
							- mLastExtremes[1 - extType][k]);

					/* Passed the threshold sensitivity? */
					if (diff > sensitivity) {

						boolean isAlmostAsLargeAsPrevious = diff > (mLastDiff[k] * 2 / 3);
						boolean isPreviousLargeEnough = mLastDiff[k] > (diff / 3);
						boolean isNotContra = (mLastMatch != 1 - extType);

						if (isAlmostAsLargeAsPrevious && isPreviousLargeEnough
								&& isNotContra) {
							// Log.i(TAG, "step");
							noStep = 0;
							if (currentState != MovementState.WALKING) {
								currentState = MovementState.WALKING;
								for (MovementListener stepListener : mStepListeners) {
									stepListener.onWalking();
								}
							}
							mLastMatch = extType;
						} else {
							mLastMatch = -1;
						}
					} else {
						noStep++;
						// Log.i(TAG, "standing");
						if (currentState != MovementState.STANDING
								&& noStep > STANDING_DELAY) {
							currentState = MovementState.STANDING;
							for (MovementListener stepListener : mStepListeners) {
								stepListener.onStanding();
							}
						}
					}
					mLastDiff[k] = diff;
				}
				mLastDirections[k] = direction;
				mLastValues[k] = v;
			}
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

}
