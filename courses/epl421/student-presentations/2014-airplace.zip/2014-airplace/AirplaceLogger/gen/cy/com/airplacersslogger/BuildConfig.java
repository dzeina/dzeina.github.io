/** Automatically generated file. DO NOT MODIFY */
package cy.com.airplacersslogger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}