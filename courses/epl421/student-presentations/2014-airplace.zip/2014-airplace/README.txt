Main Changes
------------
+ The package cy.com.movement contains classes for the walking/standing classification.
+ In the preferences I have added a seekbar to calibrate accelerometer's sensitivity, the smaller the value on
  the seekbar, the more the sensitivity on the sensor.
- In the preferences I have removed the Samples Number since we need to take samples continuously.
+ In RSSLogger.java, the method distributeLineSamples(PointF start, PointF end) does most of the job
  distributing the points on the recorded line.
+ Number of samples & movement state are visible at the bottom of the main screen.
+ "Start recording" button begins the recording session, then changes to "End recording" that can end the session.
  Once recording is ended, a button appears that can clean the points and lines on the floorplan.