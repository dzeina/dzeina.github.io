if($args.Length -ne 4){
Write-Host "Usage is: ftpupload filename server username password"
Exit
}



$file =$args[0]
$server=$args[1]
$Username=$args[2]
$Password= $args[3]

if(Test-Path $file -pathType container){
    Start-Process 'pscp.exe' -ArgumentList ("-v $file mitsos@pasithea.in.cs.ucy.ac.cy:/home/mitsos/ftp")
    Exit
}
<#
if(Test-Path $file -pathType container){


foreach ($item in Get-ChildItem $file)
    {
        $item
        $RemoteFile = "ftp://$server/ftp/$file/$item"
        if (Test-Path $item.FullName -PathType Container)
        {
        # Create FTP Rquest Object
        $FTPRequest = [System.Net.FtpWebRequest]::Create("$RemoteFile")
        $FTPRequest = [System.Net.FtpWebRequest]$FTPRequest
        $FTPRequest.Method = [System.Net.WebRequestMethods+Ftp]::MakeDirectory
        $FTPRequest.Credentials = new-object System.Net.NetworkCredential($Username, $Password)
        $FTPRequest.UseBinary = $true
        $FTPRequest.UsePassive = $true
        $FTPRequest.GetResponse();
            foreach ($subitem in Get-ChildItem $item.FullName){
                $subitem
                $FTPRequest.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
                # Read the File for Upload
                $FileContent = gc -en byte $subitem.FullName
                $FTPRequest.ContentLength = $FileContent.Length
                # Get Stream Request by bytes
                $Run = $FTPRequest.GetRequestStream()
                $Run.Write($FileContent, 0, $FileContent.Length)
                Write-Host "File uploaded..."
            }
            # Cleanup
            $Run.Close()
            $Run.Dispose()
        }
        # Create FTP Rquest Objecti
        $FTPRequest = [System.Net.FtpWebRequest]::Create("$RemoteFile")
        $FTPRequest = [System.Net.FtpWebRequest]$FTPRequest
        $FTPRequest.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
        $FTPRequest.Credentials = new-object System.Net.NetworkCredential($Username, $Password)
        $FTPRequest.UseBinary = $true
        $FTPRequest.UsePassive = $true
        # Read the File for Upload
        $FileContent = gc -en byte $item.FullName
        $FTPRequest.ContentLength = $FileContent.Length
        # Get Stream Request by bytes
        $Run = $FTPRequest.GetRequestStream()
        $Run.Write($FileContent, 0, $FileContent.Length)
        Write-Host "File uploaded..."
    }
}
Exit#>
$RemoteFile = "ftp://$server/ftp/$file"
# Create FTP Rquest Object
$FTPRequest = [System.Net.FtpWebRequest]::Create("$RemoteFile")
$FTPRequest = [System.Net.FtpWebRequest]$FTPRequest
$FTPRequest.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
$FTPRequest.Credentials = new-object System.Net.NetworkCredential($Username, $Password)
$FTPRequest.UseBinary = $true
$FTPRequest.UsePassive = $true
# Read the File for Upload
$FileContent = gc -en byte $file
$FTPRequest.ContentLength = $FileContent.Length
# Get Stream Request by bytes
$Run = $FTPRequest.GetRequestStream()
$Run.Write($FileContent, 0, $FileContent.Length)
Write-Host "File uploaded..."
# Cleanup
$Run.Close()
$Run.Dispose()
