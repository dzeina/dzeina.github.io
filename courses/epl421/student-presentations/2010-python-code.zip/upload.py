################################################
# Systems Programming: upload command
# Programmer: Team 2
################################################


#######################
# Importing Libraries
######################
import socket
import sys
import os

###################
# Constants
###################
end = '\r\n'
TRUE = 0
FALSE = -1
port = 26

###################
# Defining Functions
###################

# Sending a command 
def send(socket, cmd):
    sendcmd = cmd + end
    socket.send(sendcmd)
    
    # Sending data 
def sendData(socket, data):
    socket.send(data)

# Receiving a reply
def rcv(socket):
    print socket.recv(1024)
    
# Receiving a reply
def rcvSilent(socket):
    socket.recv(1024)
    
    
# Function that checks the command line arguments
def checkArguments():
    if len(sys.argv) != 4:
        print "\nError: Invalid Command!"
        sys.exit("Usage: ./upload <emaildir> <smtpserver> <username>\n")

    if not os.path.exists(sys.argv[1]):
        sys.exit("\nError: The directory does not exist!\n")
    return sys.argv[1], sys.argv[2], sys.argv[3];


##########################
# THE MAIN PROGRAM
##########################

# Checking if the right arguments where given
emailDir, smtpServer, username = checkArguments()


# Changing directory to the given folder

firstTime = TRUE

# Read the e-mails from the email directory
dirList = os.listdir(emailDir)
os.chdir(emailDir)
for fName in dirList:
    if firstTime == TRUE:
        print "\nThe program has started.The e-mails are being uploaded!\nPlease wait..."
        firstTime = FALSE
    # create a socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connecting to the server 
    try:
        s.connect((smtpServer, port))
    except socket.gaierror:
        sys.exit("\nError: The SMTP server "+smtpServer+" is invalid...\n")
    rcvSilent(s)

    # Sending the HELO command with the username
    sendcmd = "HELO " + username
    send(s, sendcmd)
    rcvSilent(s)

    # Sending the MAILFROM  command
    sendcmd = "MAIL FROM: " + username + "@runbox.com"
    send(s, sendcmd)
    rcvSilent(s)
    
    # Sending the RCPT TO  command
    sendcmd = "RCPT TO: " + username + "@runbox.com"
    send(s, sendcmd)
    reply = s.recv(1024)
    
    # Checking if the recipient is valid
    if reply.find('550', 0, 3) == TRUE :
            print "Error: " + reply
            exit()   
   
    # Sending the DATA command
    send(s, "DATA")
    rcvSilent(s)
    # Declaring a file object
    f = open(fName, "r") # opening the file
    flag = FALSE # flag used to separate header from body
    header = ""
    body = ""
    contents = f.readlines() # gets all the contents of the file
    for line in contents:    # for each line
        if line.isspace():   # check if is the first empty line
            if flag == FALSE :
                flag = TRUE
        if flag == FALSE :   # if we haven't found the first line then it's still the header
            header += line
        else : body += line  # else it's the body
        
    send(s,header) # sending the header
    send(s,body)   # sending the body
    send(s,".")    # sending the dot to indicate the end of the message
    send(s,"QUIT") # Closing the TCP connection
    s.close()      # Closing the socket
   
print "All e-mails from "+emailDir+" has been uploaded to "+ smtpServer+" under the account of "+username+".\nThe program will now exit..."

