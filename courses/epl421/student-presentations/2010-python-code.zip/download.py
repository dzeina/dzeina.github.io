# Lilbaries
from signal import SIG_IGN
import sys
import os
import shutil
import re
import os.path
import getpass
import socket
from operator import itemgetter
from time import strftime
import signal

# Constants declaration
PORT=110;
User = getpass.getuser() # The user that is currently logged in
SAVE_DIR= "/tmp/" + User;
TEMP_FILE= SAVE_DIR + "/temp.txt~";
PASS_FILE = SAVE_DIR + "/.pass.txt";
LEX_FILE= SAVE_DIR +  "/lexicon";
SPELL_FILE= SAVE_DIR + "/spell.txt";
FROM_DIR= SAVE_DIR + "/from";
TO_DIR= SAVE_DIR + "/to";
TRUE = 0
FALSE = -1
END = '\r\n'

# Global variables
to = 0;  From = 0;  lex = 0;  spell = 0; globSocket = -1;

# Functions declaration
#########################################################################################################
# Function that checks the command line arguments
def checkArguments():

 # Variables declaration
 j=1;  gby = 0; wrong = 0;  pos_gby=-1; 
 pos_to=-1; pos_from=-1; pos_lex=-1; pos_spell=-1; size = len(sys.argv)-1; k = size - 1;
 global to,From,lex,spell;

 for i in sys.argv:
   
   if i == "groupby":
     gby=1; pos_gby=j;
   elif i== "to":
     to=1; pos_to=j;
   elif i == "from":
     From=1; pos_from=j;
   elif i == "lexicon":
     lex=1; pos_lex=j; 
   elif i == "spellcheck":
     spell=1; pos_spell=j; 
   elif i == "download.py":
     continue;
   else:
    wrong +=1;

   if j == k:
    popServer=i

   if j == size:
    userName=i

   j +=1;

 com_sum = gby + to + From + lex + spell;

 # Check the arguments
 if (size < 2  or  size > 6) or (size==2 and com_sum > 0 ) or (pos_gby==size or pos_to == size or  pos_from==size or pos_lex == size or pos_spell ==  k or pos_gby == k or  pos_to == k or pos_from == k or pos_lex == k or pos_spell == k) or (size > 2  and com_sum == 0 ) or (wrong > 2 ):
  print "\nError:Invalid Command!";
  sys.exit("Usage: ./download [options] <popserver> <username>\n");

 # Check the groupby command
 to_from=pos_gby+1;
 if ( gby == 1 or From ==  1 or  to == 1 ):
   if (to==1 and From == 1) or (gby==1 and From==0 and to == 0) or (gby==0 and From==1) or (gby==0 and to==1):
      sys.exit("\nUsage: ./download.sh groupby headerfield(from or to)!\n");

   if (pos_to != to_from ) and  (From == 0 ):
     sys.exit("\nUsage: ./download.sh groupby headerfield(from or to)!\n");
    
   if (pos_from != to_from ) and  (to == 0 ):
     sys.exit("\nUsage: ./download.sh groupby headerfield(from or to)!\n");

 return popServer,userName;
#########################################################################################################
# Implementation of the groupby from command
def fromOption():

 print "\n\nProgram makes the [from] folder!\nPlease wait...";

 # Delete the from directory if exist
 if os.path.exists(FROM_DIR):
  shutil.rmtree(FROM_DIR);

 # Check if emails exist
 if os.listdir(SAVE_DIR) == []:
   sys.exit( FROM_DIR + " will not be create!\n");

 # Create the from directory
 os.mkdir(FROM_DIR,0777);

 # Get the emails from the directory
 dirList = os.listdir(SAVE_DIR)
 for fileName in dirList:

  # Accept only regular files and emails
  path = SAVE_DIR + "/" + fileName;
  if not os.path.isfile(path) or not fileName.endswith(">"):
    continue;
  
  # Read each email line by line
  f = open(path, "r") # opening the file
  contents = f.readlines() # gets all the contents of the file

  # Get the from name 
  for line in contents:

   p = re.compile('^From: ');
   m = p.match(line);
   if m:
     p2 = re.compile(" ")
     fromName=p2.split(line.replace("@", " "))[1]
     break;

  # Check if the directory exist in the from directory
  newPath =  FROM_DIR + "/" + fromName;
  if not os.path.isdir(newPath):
    os.mkdir(newPath,0777);

  # Make and copy a hardlink in the proper directory
  os.link(path, newPath + "/" + fileName);
#########################################################################################################
# Implementation of the groupby to command
def toOption():

 print "\n\nProgram makes the [to] folder!\nPlease wait...\n";

 # Delete the TO directory if exist
 if os.path.exists(TO_DIR):
  shutil.rmtree(TO_DIR);

 # Check if emails exist
 if os.listdir(SAVE_DIR) == []:
  sys.exit( TO_DIR + " will not be create!\n");

 # Create the TO directory
 os.mkdir(TO_DIR,0777);

 # Get the emails from the directory
 dirList = os.listdir(SAVE_DIR)
 for fileName in dirList:

  # Accept only regular files and emails
  path = SAVE_DIR + "/" + fileName;
  if not os.path.isfile(path) or not fileName.endswith(">"):
    continue;

  # Read each email line by line
  f = open(path, "r") # opening the file
  contents = f.readlines() # gets all the contents of the file

  i=0
  # Get the TO names
  for line in contents:

   # If the header dont include the TO keyword
   if line.isspace():   # check if is the first empty line
     index1=0; index2=0;
     break;

   p1 = re.compile('^To:');
   p2 = re.compile('^Subject:');
   m1 = p1.match(line);
   m2 = p2.match(line);
   if m1:
     index1=i;
   if m2:
     index2=i;
     break;

   i +=1;

  while index1 < index2:
   line2 = contents[index1].replace("To: ","").replace(',', '\n').replace(" ",'\n').replace("\t",'').replace(">",'').replace("<",'').replace('@', "@\n");
   for line3 in line2.split():
     if "@" in line3:
      toName = line3.replace("@","\0").partition("\0")[0];

      #Check if the directory exist in the TO directory
      newPath =  TO_DIR + "/" + toName;
      try:
       if not os.path.isdir(newPath):
        os.mkdir(newPath,0777);

       # Make and copy a hardlink in the proper directory if doesnt exist
       if not os.path.isfile(newPath + "/" + fileName):
        os.link(path, newPath + "/" + fileName);
      except:
        continue;
   index1 +=1;
#########################################################################################################
# Tokenize one line.Used to lexiconOption command
def tokenize(line):
 line = re.sub(r"[^a-zA-Z']", " ",line.lower())
 return line.split(" ")
#########################################################################################################
# Implementation of the lexicon command
def lexiconOption(UserName,password,PopServer):

  try:
   print "\n\nProgram makes the lexicon file!\nPlease wait...\n";
  except:
   open("/tmp/temp.txt","w")
   

  # Check if lexicon file exist
  if os.path.isfile(LEX_FILE):
    os.remove(LEX_FILE);

  # Check if emails exist
  if os.listdir(SAVE_DIR) == []:
   sys.exit( LEX_FILE + " will not be create!\n");
   
  # Get the emails from the directory
  dirList = os.listdir(SAVE_DIR); words={};
  for fileName in dirList:
  
   # Accept only regular files and emails
   path = SAVE_DIR + "/" + fileName;
   if not os.path.isfile(path) or not fileName.endswith(">"):
      continue;

   # Get the body from each email
   f = open(path, "r") # opening the file
   contents = f.readlines() # gets all the contents of the file

   flag = FALSE; body = ""
   for line in contents: # for each line
     if line.isspace() and flag == FALSE: # check if is the first empty line
       flag = TRUE
     if flag == TRUE :
      body = body + line   # get the body


   words_gen = (word for line in body.split("\r\n") for word in tokenize(line))
   for word in words_gen:
     if word == "": # if word is empy ignore it
      continue;

     # Remove the "'" character from the end of the string
     if word.endswith("'"):
      word = word[0:-1];
     words[word] = words.get(word, 0) + 1
    
   top_words = sorted(words.iteritems(),key=itemgetter(1),reverse=True)
   
  # Save the lexicon in the file
  filename = LEX_FILE + "_" + strftime("%d-%m-%Y@%H:%M:%S") + ".txt"
  file = open(filename, "w")
 
  for word, frequency in top_words:
    file.write(str(frequency) + " " + word + "\n");
  file.close;

  # Activate crontab command
  executeCrontab(UserName, password,PopServer);
#########################################################################################################
def spellcheckOption():

  print "\n\nProgram starts the spellchecker!\n\n";

  # Check if emails exist
  if os.listdir(SAVE_DIR) == []:
   sys.exit( LEX_FILE + " will not be create!\n");

  # Get the emails from the directory and print an email list for user
  dirList = os.listdir(SAVE_DIR); fileNames={};  i=0;
  for fileName in dirList:

    # Accept only regular files and emails
    path = SAVE_DIR + "/" + fileName;
    if not os.path.isfile(path) or not fileName.endswith(">"):
      continue;
    
    fileNames[i] = fileName;
   
    if (i % 3 == 0 and i != 0):
     print
    print " %3d) %s\t" % ( i , fileName ),;
    i +=1;

  print
 
  # Get the user input
  while 1:
    try:
     question = raw_input("Choose a file from the list to spell ( -1 to exit ): ")
    except:
      cleanup(globSocket);

    if str.isdigit(question) and int(question) >= 0 and int(question) < i:
      spellcheckFile(SAVE_DIR + "/" + fileNames[int(question)]);
    else:
      if int(question) != -1:
        print "The email does not exist!"
      else:
        break;
#########################################################################################################
# Function that spell and correct a file
def spellcheckFile(fName):

 # Check if spell file exist
 if os.path.isfile(SPELL_FILE):
  os.remove(SPELL_FILE);

 header = ""; i=0;
 file = open( fName, 'rw+')
 contents = file.readlines() # gets all the contents of the file
 for line in contents:
  if line.isspace():   # check if is the first empty line
    break;
  header += line
  i+=1;
 file.close();

 f = open( fName,'w' )
 f.writelines(contents[i+1:])
 f.close()

 try:
  os.rename(fName, SPELL_FILE)
  os.system("ispell -x " + SPELL_FILE)
 except:
   print "\nPlease install ispell on your pc!"
   cleanup(globSocket);

 # Recreate the correct email
 file = open(fName, "a+");
 file.write(header);
 f = open(SPELL_FILE,"r")
 contents = f.readlines() # gets all the contents of the file
 for line in contents:    # for each line append to the email file
  file.write(line);       # write to the file
 f.close;
 file.close;

# Check if spell file exist
 if os.path.isfile(SPELL_FILE):
  os.remove(SPELL_FILE);
#########################################################################################################
# Sending a command
def send(socket, cmd):
    sendcmd = cmd + END
    socket.send(sendcmd)

# Receiving a reply
def rcv(socket):
    print socket.recv(1024)

# Receiving a silent reply
def rcvSilent(socket):
    socket.recv(1024)

# Checking if the log file that saves the Message IDs exists. If not the file will be created.
def logexists(user):
    path = "/tmp/" + user +"/log.txt"
    if not os.path.exists(path):
        file = open("/tmp/" + user + "/log.txt", "a")

# Checking if the directory exists and create it in case it doesn't.
def checkUserDir(user):
    path = "/tmp/" + user
    if not os.path.exists(path):
        os.mkdir(path)

# Checking if the given password is correct
def checkPass(socket):
    reply = socket.recv(1024)
        # Checking if the password is valid
    if reply.find('-ERR', 0, 4) == TRUE :
            print "Error: " + reply
            cleanup(socket)

# Delete the temporary files
def deleteTemp():
   dirList = os.listdir(SAVE_DIR);
   for fileName in dirList:
    if fileName.endswith("~"):
      os.remove(SAVE_DIR + "/" +fileName );


# A cleanup function
def cleanup(socket):
    if os.path.exists("/tmp/" + User + "/file"):
        os.remove("/tmp/" + User + "/file")

    # Remove temporary files
    deleteTemp();
    try:
     send(socket, "QUIT")
     socket.close()
    except:
      sys.exit("\nThe program will now exit...");
    sys.exit("\nThe program will now exit...");


# A function that gets the number of the mails
def getMailNum(socket):
    reply = socket.recv(1024)
    subtype = reply.split()
    return subtype[1]

# A function that reads one line from the server's reply
def read_line(s):
    ret = ''

    while True:

        try:
         c = s.recv(1)
        except:
         c = s.recv(1)

        if c == '\n' or c == '':
            break
        else:
            ret += c

    return ret

# A function that synchronizes the log file at the beginning of each run.
def syncLog(user):
    fileList = []
    for file in os.listdir("/tmp/" + user):
        dirfile = os.path.join("/tmp/" + user, file)
        ext = os.path.splitext(dirfile)[1] # Gets the extension of a file
        if os.path.isfile(dirfile) and ext != ".txt" and ext != ".txt~" : # Gets only the mails
            fileList.append(file)
    # Open the log file to check if it already exists
    logfile = open("/tmp/" + user + "/log.txt", "r")
    logfileTemp = open("/tmp/" + user + "/log_temp.txt", "a+")
    # Read in the entire text of the file
    filetext = logfile.read()
    for file in fileList:
            exists = filetext.find(file)
            if exists!=FALSE:
                logfileTemp.write(file + "\n")
    # Deleting the old log file
    os.remove("/tmp/" + user + "/log.txt")
    # Renaming the new synchronized file
    os.rename("/tmp/" + user + "/log_temp.txt","/tmp/" + user + "/log.txt")
    logfile.close()
    logfileTemp.close()

# A function that uses regular expressions in order to replace a block of text
def replace(start, replace, end, replacement, search):
        return re.sub("(" + str(re.escape(start)) + ")" + str(re.escape(replace)) + "(?=" + str(re.escape) + ")", "\\1" + str(re.escape(replacement)), search)


# A function that clears the e-mails from the unwanted blocks
def clearBlocks(fileName):
    tempFile = open(fileName, "r")
    flag = FALSE
    header = ""
    body = ""
    contents = tempFile.readlines() # gets all the contents of the file
    for line in contents:    # for each line
        if line.isspace():   # check if is the first empty line
            if flag == FALSE :
                flag = TRUE
        if flag == FALSE :   # if we haven't found the first line then it's still the header
            header += line
        else : body += line  # else it's the body

    tempFile.close()

    # Removes the lines that are starting with >
    NewBody=re.sub(re.compile('^>(.*)',re.MULTILINE), '', body )
    # Removes the "Request ID: ... Resource Type" Block from mails.
    NewBody=re.sub(re.compile('Request ID :(?s)(.*)(?=Resource Type :(.*))(Resource Type : \w*)',re.MULTILINE), '', NewBody )
    # Removes the Blocks that are included in stars
    NewBody=re.sub(re.compile('(^\*\**\*)(?s)(.*)(?=(^\*\**\*)(.*))(^\*\**\*)',re.MULTILINE), '', NewBody )

    # Delete the previous mail
    if os.path.exists(fileName):
        os.remove(fileName)

    # Creating the new file with the fixed blocks
    File = open(fileName, "a+")
    File.write(header+NewBody)
    File.close()
#########################################################################################################
def download(user,server,username,password):
  # Directory check
  checkUserDir(user)

  # Checking if the log file that saves the Message IDs exists.if not the file will be created.
  logexists(user)

  # Synchronize the log file
  syncLog(user)

  # create a socket
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

  # Connecting to the server
  try:
      s.connect((server, PORT))
  except socket.gaierror:
      sys.exit("\nError: The POP3 server " + server + " is invalid...\n")
  rcvSilent(s)

  # Sending the USER command with the username
  sendcmd = "USER " + username
  send(s, sendcmd)
  rcvSilent(s)

  # Sending the PASS command
  sendcmd = "PASS " + password
  send(s, sendcmd)
  checkPass(s)

  # Sending the STAT command in order to get the number of the mails on the server
  sendcmd = "STAT"
  send(s, sendcmd)
  mailNum = getMailNum(s) # Getting the number of the mails

  mail = 1
  for mail in range (1, int(mailNum) + 1):

    file = open("/tmp/" + user + "/file", "a")

    exists = FALSE # flag that indicates if a mail already exists
    plainTextFlag = "None" # flag that indicates if a mail is plain text
    # Sending the RETR command
    sendcmd = "RETR " + str(mail)
    send(s, sendcmd)
    reply = read_line(s)
    reply = read_line(s)

    tempreply = re.sub('.$', '', reply)
    while tempreply != '.':

        file.write(tempreply + "\n");

       # Checking if the mail is contains only plain/text
       # if not ignore the file (by removing it)
        plainTextFlag = re.match(r'Content-Type: text/plain', tempreply)
        msgid = re.match(r'Message-ID: (.*)', tempreply)
        if msgid:

            # Get the msg id of the mail
            fileToWrite = msgid.group(1)
         
            # Open the log file to check if it already exists
            logfile = open("/tmp/" + user + "/log.txt", "a+")
            # Read in the entire text of the file
            filetext = logfile.read()
            exists = filetext.find(fileToWrite)
           
            if exists == FALSE:
                logfile.write(fileToWrite + "\n")
              
            else:
                print "The e-mail with ID: " + fileToWrite + " and num:" + str(mail) + " already exists and will not be downloaded again"
                os.remove("/tmp/" + user + "/file")


        reply = read_line(s)
        tempreply = re.sub('.$', '', reply)
   # print "Exists for mail "+str(mail)+" is "+str(exists)
    if exists == FALSE and plainTextFlag!="None":
        os.rename("/tmp/" + user + "/file", "/tmp/" + user + "/" + str(fileToWrite))
        print "done with mail: " + str(mail)
    logfile.close()

  # Open the log file to check if it already exists
  logfile = open("/tmp/" + user + "/log.txt", "r")
  # Read in the entire text of the file
  filetext = logfile.readlines()

  # Clearing the unwanted blocks from the mails
  for filename in filetext:
    clearBlocks("/tmp/" + user + "/"+filename.rstrip())
  return s #return the socket
#########################################################################################################
# Function tha execute the crontab command
def executeCrontab(user,password,server):

  file = open(PASS_FILE, "w");
  file.write(password);
  file.close();

  # Change the rigth modes of our program

  programPath = os.getcwd().replace(" ","\ ") + "/" + "download.py";
  os.system("chmod 0777 " + programPath);

  crontbatQuery = "* 0,12 * * * " + " python " + programPath + " lexicon " + server + " " +user +  " < " + PASS_FILE;

  file = open(SAVE_DIR + "/crontab.txt", "w");
  file.write(crontbatQuery);
  file.close();

  # Insert query in the crontab
  os.system("crontab -i " + SAVE_DIR + "/crontab.txt" );

  if os.path.isfile(SAVE_DIR + "/crontab.txt"):
   os.remove(SAVE_DIR + "/crontab.txt");
#########################################################################################################
# Function that handles signals
def signalHandler(signum,stack):

   if lex == 1:
    print "\nUnable to corrupt! Lexicon Command run!\n"
    return;

   # Clean up unused files
   cleanup(globSocket);
#########################################################################################################
#The main program

if __name__ == "__main__":

   # Local variables
   PopServer = ""; password="0"; UserName = "";

   # Check if arguments are valid
   PopServer,UserName=checkArguments();

   print "\nThe program has started!\n"

   # Getting the password from the user
   print "Enter the password for the given account (" + UserName + ")"
   try:
    password = getpass.getpass()
   except:
     cleanup(globSocket)

   # Receive signals
   signal.signal(1, signalHandler)
   signal.signal(2, signalHandler)
   signal.signal(3, signalHandler)

   # Download the emails from server
   globSocket = download(User,PopServer,UserName,password);

   # Remove temporary files
   deleteTemp();

   # Call the options
   if From == 1:
    fromOption();

   if to == 1:
    toOption();

   if lex == 1:
    lexiconOption(UserName,password,PopServer);
    lex = 0;
  
   if spell == 1:
    spellcheckOption();

   cleanup(globSocket);