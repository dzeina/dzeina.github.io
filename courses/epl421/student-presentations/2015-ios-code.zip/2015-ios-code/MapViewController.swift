//
//  MapViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 28/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {

   @IBOutlet weak var webView: UIWebView!
   

    override func viewDidLoad() {
      super.viewDidLoad()
      
      if (wifi==false){

         let alertController = UIAlertController(title: "iOScreator", message:
            "Hello, world!", preferredStyle: UIAlertControllerStyle.Alert)
         alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
         self.presentViewController(alertController, animated: true, completion: nil)

         
      }
      else{
         let url = NSURL(string: "http://anyplace.cs.ucy.ac.cy/viewer/")
         let request = NSURLRequest(URL: url!)
         webView.loadRequest(request)
      }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
