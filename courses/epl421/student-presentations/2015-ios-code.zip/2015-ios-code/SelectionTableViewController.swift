//
//  SelectionTableViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 27/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class SelectionTableViewController: UITableViewController {
   
   var infos: [String] = ["General Info", "Blueprints", "POIs"]
//   var selInfo : Int?
   var selBuild : Int?

    override func viewDidLoad() {
        super.viewDidLoad()
      
      if (wifi==false){
         
         let alertController = UIAlertController(title: "Error.", message:
            "Please connect to the internet.", preferredStyle: UIAlertControllerStyle.Alert)
         alertController.addAction(UIAlertAction(title: "I Will.", style: UIAlertActionStyle.Default,handler: nil))
         
         self.presentViewController(alertController, animated: true, completion: nil)
         
         
      }
//      println("\nin selectionTableView")
//      println(self.selBuild)

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return infos.count
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCellWithIdentifier("infoCell", forIndexPath: indexPath) as UITableViewCell
      
      let selection = infos[indexPath.row]
//      self.selInfo = indexPath.row
//      println(self.selInfo)
      cell.textLabel?.text = selection

        return cell
    }
   
   
   
   override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
   {

      let row = indexPath.row
      println("The row is \(row)")
//      println(self.selInfo)
 
      if indexPath.row == 0
      {
         self.performSegueWithIdentifier("generalSegue", sender: self)
      }
      else if indexPath.row == 1
      {
         self.performSegueWithIdentifier("blueprintSegue", sender: self)
      }
      else if indexPath.row == 2
      {
         self.performSegueWithIdentifier("poisSegue", sender: self)
      }
      
   }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation
   override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
      if let parameter = self.tableView.indexPathForSelectedRow(){
         if parameter.row == 0{
            var passingBuilding = segue.destinationViewController as InfoViewController
            passingBuilding.selBuild=self.selBuild;
         }
         else if parameter.row == 1{
            var passingBuilding = segue.destinationViewController as FloorTableViewController
            passingBuilding.selBuild=self.selBuild;
         }
         else{
            var passingBuilding = segue.destinationViewController as POISViewController
            passingBuilding.selBuild=self.selBuild;
         }
      }
      
   }


}
