//
//  TestViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 28/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit
import Foundation

class TestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      
      // Do any additional setup after loading the view, typically from a nib.
      //        post("buildings.txt" ,["access_token":"api_tester"], "http://anyplace.rayzit.com/anyplace/mapping/building/all") { (succeeded: Bool, msg: String) -> () in }
      //
      //        println("//////////////////////////// Save pois")
      //        savePOIS()
      //        println("//////////////////////////// Buildings Name")
      //        var b = getBuildingsName()
      //        println(b)
      //        println("//////////////////////////// END")
      //
      //        println("//////////////////////////// pois")
      //
      //        var bb = getStatisticsForBuilding("username_1373876832005")
      //
      //        println(bb)
      //        var floors = getNumOfFloorsForBuilding("username_1373876832005");
      //        println(floors)
      //        println("//////////////////////////// END11")
      
      saveBluePrintForBuilding("username_1373876832005")
      
      //BLUEPRINT
      let base64String = getBase64StringForBuildingAndFloor("username_1373876832005" ,-1)
      let decodedData = NSData(base64EncodedString: base64String, options: NSDataBase64DecodingOptions())
      var decodedimage = UIImage(data: decodedData!)
      println(decodedimage)
      //bluePrint.image = decodedimage as UIImage?
      
      var b = getGeneralInfoForBuilding("buildings.txt", "username_1373876832005")
      println(b)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
