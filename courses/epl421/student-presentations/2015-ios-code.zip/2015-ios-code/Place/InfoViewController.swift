//
//  InfoViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 27/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController {
   
   var selBuild : Int?
   var buildingsID = getBuildingsID("buildings.txt")
   
   @IBOutlet weak var Name: UILabel!
   @IBOutlet weak var Address: UILabel!
   @IBOutlet weak var Description: UILabel!
   @IBOutlet weak var Floors: UILabel!
   @IBOutlet weak var URL: UILabel!
   
   
    override func viewDidLoad() {
        super.viewDidLoad()
         var b = getGeneralInfoForBuilding("buildings.txt", buildingsID[self.selBuild!] as NSString)
      println(b)
      self.Name.text = b["name"]
      self.Address.text = b["address"]
      self.Description.text = b["description"]
      self.Floors.text = b["Floors"]
      self.URL.text = b["url"]

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
