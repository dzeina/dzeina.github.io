//
//  FirstViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 28/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

let useClosures = false
var wifi = false

class FirstViewController: UITabBarController {

   @IBOutlet weak var networkStatus: UILabel!
   

   
//   override init() {
//      wifi = false
//   }
//
//   required init(coder aDecoder: NSCoder) {
//       fatalError("init(coder:) has not been implemented")
//   }
   
   let reachability = Reachability.reachabilityForInternetConnection()
   
   override func viewDidLoad() {
      super.viewDidLoad()
      var b = getGeneralInfoForBuilding("buildings.txt", "username_1373876832005")
      println(b)
      
      if (useClosures) {
         reachability.whenReachable = { reachability in
          //  self.updateLabelColourWhenReachable(reachability)
         }
         reachability.whenUnreachable = { reachability in
          //  self.updateLabelColourWhenNotReachable(reachability)
         }
      } else {
         NSNotificationCenter.defaultCenter().addObserver(self, selector: "reachabilityChanged:", name: ReachabilityChangedNotification, object: reachability)
      }
      
      reachability.startNotifier()
      
      // Initial reachability check
      if reachability.isReachable() {
         //make post requests
         wifi = true

         post("buildings.txt" ,["access_token":"api_tester"], "http://anyplace.rayzit.com/anyplace/mapping/building/all") { (succeeded: Bool, msg: String) -> () in }
         savePOIS("buildings.txt")
         //updateLabelColourWhenReachable(reachability)
      } else {
         wifi = false

//         var alert = UIAlertController(title: "Alert", message: "Message", preferredStyle: UIAlertControllerStyle.Alert)
//         alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.Default, handler: nil))
//         self.presentViewController(alert, animated: true, completion: nil)
         
         //updateLabelColourWhenNotReachable(reachability)
      }
   }
   
   deinit {
      
      reachability.stopNotifier()
      
      if (!useClosures) {
         NSNotificationCenter.defaultCenter().removeObserver(self, name: ReachabilityChangedNotification, object: nil)
      }
   }
   
//   func updateLabelColourWhenReachable(reachability: Reachability) {
//      if reachability.isReachableViaWiFi() {
//         self.networkStatus.textColor = UIColor.greenColor()
//      } else {
//         self.networkStatus.textColor = UIColor.blueColor()
//      }
//      
//      self.networkStatus.text = reachability.currentReachabilityString
//   }
//   
//   func updateLabelColourWhenNotReachable(reachability: Reachability) {
//      self.networkStatus.textColor = UIColor.redColor()
//      
//      self.networkStatus.text = reachability.currentReachabilityString
//   }
   
   
   func reachabilityChanged(note: NSNotification) {
      let reachability = note.object as Reachability
      
      if reachability.isReachable() {
         //make post requests
         wifi = true
         
         post("buildings.txt" ,["access_token":"api_tester"], "http://anyplace.rayzit.com/anyplace/mapping/building/all") { (succeeded: Bool, msg: String) -> () in }
         savePOIS("buildings.txt")
//         updateLabelColourWhenReachable(reachability)
      } else {
         wifi = false
         
//         updateLabelColourWhenNotReachable(reachability)
      }
   }

}
