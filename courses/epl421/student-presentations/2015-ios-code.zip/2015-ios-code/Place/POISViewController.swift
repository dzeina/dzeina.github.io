//
//  POISViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 28/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class POISViewController: UIViewController {
   
   var selBuild : Int?
   var buildings = getBuildingsName("buildings.txt")
   var buildingsID = getBuildingsID("buildings.txt")


//   
//   var buildID = getBuildingsID("buildings.txt")
//   println(buildID)
//   var statistics = getStatisticsForBuilding(buildingsID[selBuild])
//   println(statistics)
   
   
   @IBOutlet weak var Office: UILabel!
   @IBOutlet weak var Room: UILabel!
   @IBOutlet weak var Entrance: UILabel!
   @IBOutlet weak var Toilets: UILabel!
   @IBOutlet weak var DisabledToilets: UILabel!
   @IBOutlet weak var Security: UILabel!
   @IBOutlet weak var FirstAidAED: UILabel!
   @IBOutlet weak var FireExtinguisher: UILabel!
   
   @IBOutlet weak var Elevator: UILabel!
   @IBOutlet weak var Outdoor: UILabel!
   @IBOutlet weak var Ramp: UILabel!
   @IBOutlet weak var Stair: UILabel!
   @IBOutlet weak var Kitchen: UILabel!
   @IBOutlet weak var Indoor: UILabel!
   @IBOutlet weak var FirstAid: UILabel!
   @IBOutlet weak var None: UILabel!
   
//   "pois_type" : "Disabled Toilets"
//   "pois_type" : "Elevator"
//   "pois_type" : "Entrance"
//   "pois_type" : "Fire Extinguisher"
//   "pois_type" : "First Aid"
//   "pois_type" : "First Aid\/AED"
//   "pois_type" : "Indoor"
//   "pois_type" : "Kitchen"
//   "pois_type" : "None"
//   "pois_type" : "Office"
//   "pois_type" : "Outdoor"
//   "pois_type" : "Ramp"
//   "pois_type" : "Room"
//   "pois_type" : "Security\/Guard"
//   "pois_type" : "Stair"
//   "pois_type" : "Toilets"
   
    override func viewDidLoad() {
         super.viewDidLoad()
         println(buildingsID)
      println("///////////////statistics")
         var statistics = getStatisticsForBuilding(buildingsID[selBuild!] as String)
         println(statistics)
      for (key,value) in statistics{
         println("\(key) \(value)")
         var num = "\(value)"
         if key == "\"Disabled Toilets\"" {
            self.DisabledToilets.text = num
         }
         if key == "Elevator" {
            self.Elevator.text = num
         }
         if key == "Entrance" {
            self.Entrance.text = num
         }
         if key == "Fire Extinguisher" {
            self.FireExtinguisher.text = num
         }
         if key == "First Aid" {
            self.FirstAid.text = num
         }
         if key == "First Aid/AED" {
            self.FirstAidAED.text = num
         }
         if key == "Indoor" {
            self.Indoor.text = num
         }
         if key == "Kitchen" {
            self.Kitchen.text = num
         }
         if key == "Office" {
            self.Office.text = num
         }
         if key == "Outdoor" {
            self.Outdoor.text = num
         }
         if key == "Ramp" {
            self.Ramp.text = num
         }
         if key == "Romm" {
            self.Room.text = num
         }
         if key == "Security/Guard" {
            self.Security.text = num
         }
         if key == "Stair" {
            self.Stair.text = num
         }
         if key == "Toilets" {
            self.Toilets.text = num
         }
      }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
