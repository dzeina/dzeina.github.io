//
//  BlueprintViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 29/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class BlueprintViewController: UIViewController {
   
   var selBuild : Int?
   var selFloor : Int?
   var buildingsID = getBuildingsID("buildings.txt")
   
   
   @IBOutlet weak var blueprint: UIImageView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
      var buid = buildingsID[selBuild!] as String
      
      var floorBuild = getNumOfFloorsForBuildingInt(buid)
      
      
      
      var floor = floorBuild[selFloor!]
      if (wifi==false){
         
         let alertController = UIAlertController(title: "Error", message:
            "I told you, there is no internet connection.", preferredStyle: UIAlertControllerStyle.Alert)
         alertController.addAction(UIAlertAction(title: "I am sorry.", style: UIAlertActionStyle.Default,handler: nil))
         
         self.presentViewController(alertController, animated: true, completion: nil)
      }
      else{
         println(floor)
         println("ddddddddd \(buid)")
         //BLUEPRINT
         let base64String = getBase64StringForBuildingAndFloor(buid, floor)
         let decodedData = NSData(base64EncodedString: base64String, options: NSDataBase64DecodingOptions())
         var decodedimage = UIImage(data: decodedData!)
         println(decodedimage)
         blueprint.image = decodedimage as UIImage?
      }
      
         
        // Do any additional setup after loading the view.
   }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
