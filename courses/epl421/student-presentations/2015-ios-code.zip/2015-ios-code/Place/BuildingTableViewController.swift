//
//  BuildingTableViewController.swift
//  Place
//
//  Created by Panayiotis Pavlides on 27/4/15.
//  Copyright (c) 2015 Panayiotis Pavlides. All rights reserved.
//

import UIKit

class BuildingTableViewController: UITableViewController, UITableViewDataSource, UITableViewDelegate {
   
   var buildings = getBuildingsName("buildings.txt")
   var buildingsID = getBuildingsID("buildings.txt")

   
   var selectedBuilding : Int!
   

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return buildings.count
    }

   
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("buildingCell", forIndexPath: indexPath) as UITableViewCell

      let selection: AnyObject = buildings[indexPath.row]
      cell.textLabel?.text = selection as? String

        return cell
    }
   
   
//   override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
//      selectedBuilding = indexPath.row
//      println("SO THE SELECTED BUILDING IS \(selectedBuilding)")
//   }
   


    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */


    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */


    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
      
      var option = segue.destinationViewController as SelectionTableViewController
      if let parameter = self.tableView.indexPathForSelectedRow(){
//         println("TEST \(parameter.row)")
         option.selBuild=parameter.row
      }
    }


}
