import sys
import re
import urllib2
import urlparse
import optparse
import htmllib, formatter
import time
from cStringIO import StringIO

def parse_options():

    parser = optparse.OptionParser()
    
    parser.add_option("-d", "--depth",
            action="store", type="int", default=30, dest="depth",
            help="Maximum depth to traverse")

    opts, args = parser.parse_args()

    if len(args) < 1:
        parser.print_help()
        raise SystemExit, 1

    return opts, args


def log_stdout(msg):
    print msg

def get_page(url, log):
    try:
        page = urllib2.urlopen(url)
    except urllib2.URLError:
        log("Error retrieving: " + url)
        return ''
    body = page.read()
    page.close()
    return body

def find_links(html):
    writer = formatter.DumbWriter(StringIO())
    f = formatter.AbstractFormatter(writer)
    parser = htmllib.HTMLParser(f)
    parser.feed(html)
    parser.close()
    return parser.anchorlist

class Spider:
    
    def __init__(self,startURL, log=None):
        self.URLs = set()
        self.URLs.add(startURL)
        self.include = startURL
        
        self._links_to_p = set()
        if log is None:
            
            self.log = log_stdout
        else:
            self.log = log
    
    def run(self,urls):
        for url in urls:
            
            print url
            self.process_page(url)
                
    def process_page(self, url):
        html = get_page(url, self.log)
        self.URLs.add(url)
        
        for link in find_links(html):
            link = urlparse.urljoin(url, link)
            if link[-1] == '/':
                if link not in self.URLs:
                    self.URLs.add(link)
                    self._links_to_p.add(link)
            else:

                temp = link.replace('/', '.')
                
                if temp[-5:] == ".html" or temp[-4:] == ".htm":
                  
                    if link not in self.URLs:
                        self.URLs.add(link)
                        self._links_to_p.add(link)
                else:
                    continue
                    
def clear(url):
    while not len(url) == 0:
        url.pop()

                
def main():
    opts, args = parse_options()
    depth = opts.depth
    startURL = args[0]
    spider = Spider(startURL)
 
    count = 0
    urls = set()
    urls.add(startURL)
    sTime = time.time()
    while count <= depth:
        spider.run(urls)
        clear(urls)
        while not len(spider._links_to_p) == 0:
            urls.add(spider._links_to_p.pop())
        count=count+1
    eTime = time.time()
    tTime = eTime - sTime   

    print "time taken %f" % tTime
if __name__ == "__main__":
    main()
