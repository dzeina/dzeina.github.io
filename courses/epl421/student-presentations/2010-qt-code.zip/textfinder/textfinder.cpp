#include <QtUiTools> //For the various controls inside the form
#include <QtGui> //for the Graphical User Interface
#include "textfinder.h"


TextFinder::TextFinder(QWidget *parent)
    : QWidget(parent)
{
    QWidget *formWidget = loadUiFile();

    //create the controls/buttons that exist on the form
    ui_findButton = qFindChild<QPushButton*>(this, "findButton"); //the find button
    ui_textEdit = qFindChild<QTextEdit*>(this, "textEdit"); //the textbox containing the lexicon
    ui_lineEdit = qFindChild<QLineEdit*>(this, "lineEdit"); //the textbox containing the search word


    QMetaObject::connectSlotsByName(this);

    loadTextFile();

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(formWidget);
    setLayout(layout);

    setWindowTitle(tr("Lexicon")); //set the form's title bar
    isFirstTime = true; //boolean used to find multiple words in lexicon
}

QWidget* TextFinder::loadUiFile()
{
    QUiLoader loader;

    QFile file(":/forms/textfinder.ui"); //where to get the UI from
    file.open(QFile::ReadOnly);

    QWidget *formWidget = loader.load(&file, this);
    file.close();

    return formWidget;
}

void TextFinder::loadTextFile()
{
    QFile inputFile(":/forms/input.txt"); //where to get the lexicon from
    inputFile.open(QIODevice::ReadOnly);
    QTextStream in(&inputFile);
    QString line = in.readAll(); //copy the lexicon in the line string
    inputFile.close();

    //fill the textbox with the contents of line string (i.e. the lexicon)
    ui_textEdit->append(line);
    ui_textEdit->setUndoRedoEnabled(false);
    ui_textEdit->setUndoRedoEnabled(true);
}

//this method is called when the find button is clicked
void TextFinder::on_findButton_clicked()
{
    QString searchString = ui_lineEdit->text();
    QTextDocument *document = ui_textEdit->document();

    bool found = false;

    if (isFirstTime == false)
        document->undo();

    //in case the search string is null
    if (searchString == "") {
        QMessageBox::information(this, tr("Empty Search Field"),
                "The search field is empty. Please enter a word and then click Find.");

    } else {//search string is not null

        QTextCursor highlightCursor(document);  
        QTextCursor cursor(document);
        
        cursor.beginEditBlock();

        //set the highlight preferences
        QTextCharFormat plainFormat(highlightCursor.charFormat());
        QTextCharFormat colorFormat = plainFormat;
        colorFormat.setForeground(Qt::red);

        //find the search word somewhere in the lexicon
        while (!highlightCursor.isNull() && !highlightCursor.atEnd()) {
            highlightCursor = document->find(searchString, highlightCursor, QTextDocument::FindWholeWords);

            // highlight the word as defined above
            if (!highlightCursor.isNull()) {
                found = true;
                highlightCursor.movePosition(QTextCursor::WordRight,
                                       QTextCursor::KeepAnchor);
                highlightCursor.mergeCharFormat(colorFormat);
            }
        }

        cursor.endEditBlock();

        isFirstTime = false; //now we will search for more than 1 occurences of the  search word

        //if the word is not found
        if (found == false) {
            QMessageBox::information(this, tr("Word Not Found"),
                "Sorry, the word is not included in the dictionary.");
        }    
    }
}

