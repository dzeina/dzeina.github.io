#ifndef TEXTFINDER_H
#define TEXTFINDER_H

#include <QWidget>

QT_BEGIN_NAMESPACE
class QPushButton;
class QTextEdit;
class QLineEdit;
QT_END_NAMESPACE

class TextFinder : public QWidget
{
    Q_OBJECT

public:
    TextFinder(QWidget *parent = 0);

private slots:
    void on_findButton_clicked();
    
private:
    QWidget* loadUiFile();
    void loadTextFile();

    QPushButton *ui_findButton; //the find button
    QTextEdit *ui_textEdit; //the textbox containing the lexicon
    QLineEdit *ui_lineEdit; //the textbox containing the search word
    bool isFirstTime; //boolean to check if the word was found more than once
};

#endif
