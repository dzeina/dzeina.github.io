        function httpGetLatest(userId)
        {
                var xmlHttp = null;
                xmlHttp = new XMLHttpRequest();				
				var url="http://dev.rayzit.com/user/"+userId+"/livefeed";
                xmlHttp.open("GET", url, false );
                xmlHttp.send( null );
                //alert(xmlHttp.responseText);
				return(xmlHttp.responseText);
        }
		
		 function httpGetUser(userId)
        {
                var xmlHttp = null;
                xmlHttp = new XMLHttpRequest();		
				var url="http://dev.rayzit.com/user/"+userId+"/myrayz/1";
                xmlHttp.open("GET", url, false );
                xmlHttp.send( null );
                //alert(xmlHttp.responseText);
				return(xmlHttp.responseText);
        }		
		
		function httpGetStar(userId)
        {
                var xmlHttp = null;
                xmlHttp = new XMLHttpRequest();		
				var url="http://dev.rayzit.com/user/"+userId+"/starred/1";
                xmlHttp.open("GET", url, false );
                xmlHttp.send( null );
                //alert(xmlHttp.responseText);
				return(xmlHttp.responseText);
        }		