<div class=" progress">
  <div  class="power-bar active progress-bar progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuenow="100" aria-valuemax="100">
  </div>
</div>