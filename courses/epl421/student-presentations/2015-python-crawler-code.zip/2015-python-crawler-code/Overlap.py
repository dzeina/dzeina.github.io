try:
    from tkinter import *
except ImportError:
    try:
        from Tkinter import *
    except ImportError:
        print('Please install python-tk before running')
        exit()
import requests
from bs4 import BeautifulSoup
import sys
import os
import re
import time
import urllib2
import zipfile


# Funtion to graph points, graph roads, or open the OverLap website to show roads
def ComputeRoadsAndSee(outselection):
    try:
        import numpy as np
        import matplotlib.pyplot as plt
        import webbrowser
    except ImportError:
        print('Please install numpy, mmatplotlib and webbrowser to run this method')
        exit()

    directory = "All/"
    lineFrom = []
    lineTo = []
    points = set()

    # Get all GPX files from the All directory
    for filename in os.listdir("All"):
        if filename.endswith(".gpx"):
            file = open(directory + filename,'r')
            prevlamda = 1
            prevpoint = (1,1)
            confidence = 0
            pointckeck = (1,1)
            lamdacheck = 1

            # For each point compute bearings and decide if new road
            for line in file:
                if 'lon=' in line:
                    lon = float(line.split('"')[1])
                    lat = float(line.split('"')[3])
                    points.add((lon,lat))
                    point = (lon,lat)

                    if point[1]-prevpoint[1] == 0:
                        confidence = confidence + 1
                        continue
                    lamda = (point[0]-prevpoint[0])/(point[1]-prevpoint[1])

                    # If road has changed
                    if np.absolute(np.arctan(lamda) - np.arctan(lamdacheck)) > 0.3:

                        # if the road is confirmed then append it's points to the list
                        if pointckeck != (1,1) and confidence > 0:
                            lineFrom.append(pointckeck)
                            lineTo.append(prevpoint)

                        confidence /= 8
                        if confidence == 0:
                            pointckeck = point
                            lamdacheck = lamda

                    # Else increase confidence
                    elif confidence<16:
                        confidence = confidence + 1
                    prevpoint = point
                    prevlamda = lamda

            # Also prepare the points graph in case we want to plot all points
            pointsl = list(points)
            plt.plot(np.array(pointsl)[:, 0], np.array(pointsl)[:, 1], '.', marker='.', label=filename)
            points.clear()

    # Plot points option
    if outselection == 0:
        plt.show()

    # Plot roads option
    elif outselection == 1:
        plt.clf()
        for i in range(len(lineFrom)):
            plt.plot ( (lineFrom[i][0],lineTo[i][0]) ,(lineFrom[i][1],lineTo[i][1]) ,'.-',label='line'+str(i))
        plt.show()

    # Plot roads in maps option
    elif outselection == 2:
        # Write a new GPX file with all roads
        f = open("Site/overlap.gpx","w")
        f.write('<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1"><trk>')
        for i in range(len(lineFrom)):
            f.write('<trkseg>')
            f.write('<trkpt lon="'+str(lineFrom[i][0])+'" lat="'+str(lineFrom[i][1])+'"></trkpt>\n')
            f.write('<trkpt lon="'+str(lineTo[i][0])+'" lat="'+str(lineTo[i][1])+'"></trkpt>\n')
            f.write('</trkseg>')
        f.write('</trk></gpx>')
        f.close()
        # And then oppen the OverLap site in browser
        webbrowser.open('Site/index.html')


# Functions that calls the proper crawler with
# the given username and password.
def login():
    u = entUsername.get()
    p = entPassword.get()
    s = sites.get()
    o = overlap.get()
    if len(u) == 0:
        errorMsg("Attention!", "Your username is too short")
        return
    if len(p) == 0:
        errorMsg("Attention!", "Your password is too short")
        return
    if s == "Runtastic":
        crawlRuntastic(u, p)
    elif s == "RunKeeper":
        crawlRunkeeper(u, p)
    elif s == "Endomondo":
        crawlEndomondo(u, p)


# Function that creates custom error message
# with a given title and message text.
def errorMsg(title, msg):
    msgwin = Tk()
    msgwin.wm_title(title)
    w = Label(msgwin, text=msg, font=("Helvetica", 16))
    w.grid(row=0)
    btnOK = Button(msgwin, text="OK", font=("Helvetica", 12), command=msgwin.destroy)
    btnOK.grid(row=1)


def saveGPX(gpx_name, gpx_text):
    sys.stdout.write("  > Saving " + gpx_name + "...")
    lines = gpx_text.split("\\n")
    if not os.path.exists(os.path.dirname(gpx_name)):
        os.makedirs(os.path.dirname(gpx_name))
    fx = open(gpx_name, "w")
    for line in lines:
        fx.write(line + "\n")
    fx.close()
    print("Done!")


# Crawler for the Runtastic website
def crawlRuntastic(u, p):
    basic_url = "https://www.runtastic.com"
    print("> Crawling Runtastic...")

    # Login to Runtastic
    sys.stdout.write(' > Logging in...')
    session = requests.session()
    payload = {'user[email]': u, 'user[password]': p}
    r = session.post('https://www.runtastic.com/en/d/users/sign_in.json', data=payload)
    if r.status_code != 200:
        print("Error!")
        errorMsg("Attention!", "Wrong username or password!")
        return
    plain_text = str(r.json())
    soup = BeautifulSoup(str(plain_text))
    link = soup.find('a', {'class': 'header-navigation__link'})
    user_url = link.get('href')
    user_url = user_url[:-9]
    print("Done!")

    # Access route list
    sys.stdout.write(' > Accessing routes...')
    url = basic_url + user_url + "/sport-sessions#single_type_3/"
    r = session.get(url)
    if r.status_code != 200:
        print("Error!")
        return
    print("Done!")

    # Find routes
    try:
        plain_text = str(r.text)
    except Exception:
        plain_text = unicode(r.text)
    find_start = "var index_data = [["
    find_end = "]];"
    tstart = plain_text.find(find_start)
    if tstart == -1:
        print(" *** No routes found! ***")
        print("> Crawling Runtastic...Done!")
        return
    start = tstart + len(find_start)
    end = plain_text.rfind(find_end, start)
    if end == -1 or start == end:
        print(" *** No routes found! ***")
        print("> Crawling Runtastic...Done!")
        return
    all_routes = plain_text[start:end]
    routes = all_routes.split('],[')

    # Download and save all routes
    for rs in routes:
        route = rs.split(',')
        route_name = str(route[0]) + ".gpx"
        route_url = basic_url + user_url + "sport-sessions/" + route_name
        sys.stdout.write("  > Downloading " + route_name + "...")
        r = session.get(route_url)
        if r.status_code != 200:
            print("Error!")
            return
        print("Done!")
        str_gpx = r.text
        user_name = user_url[10:]

        # save to user's path
        route_path = "Runtastic/" + user_name + route_name
        saveGPX(route_path, str_gpx)

        # save to default path
        route_path = "All/" + route_name
        saveGPX(route_path, str_gpx)
    print("> Crawling Runtastic...Done!")


# Unzip file
def unzip(source_filename, dest_dir):
    with zipfile.ZipFile(source_filename) as zf:
        zf.extractall(dest_dir)


# Download zip from runkeeper
def download_file(url):
    file_name = url.split('/')[-1]
    u = urllib2.urlopen(url)
    f = open(file_name, 'wb')
    meta = u.info()
    file_size = int(meta.getheaders("Content-Length")[0])
    print(" > Downloading: %s Bytes: %s" % (file_name, file_size))

    file_size_dl = 0
    block_sz = 8192
    while True:
        buffer = u.read(block_sz)
        if not buffer:
            break

        file_size_dl += len(buffer)
        f.write(buffer)
        status = r"%10d  [%3.2f%%]" % (file_size_dl, file_size_dl * 100. / file_size)
        status = status + chr(8)*(len(status)+1)
        print(status)

    f.close()

    unzip(file_name, "All")
    os.remove(file_name)
    print


# Crawler for the Runkeeper website
def crawlRunkeeper(u, p):
    basic_url = "https://www.runkeeper.com"
    print("Crawling RunKeeper...")

    # Login to Runkeeper
    sys.stdout.write(' > Logging in...')
    session = requests.session()

    r = session.get("https://runkeeper.com/login")

    count = 0

    fpStr = ""
    sourcePageStr = ""
    strLogin = ""

    for line in r.text.splitlines():
        if 'name="__fp"' in line:
            strLogin = line
            count = count + 1
        if count==2:
            break


    start = strLogin.find('"_sourcePage" value=')+20
    end = strLogin.find('/><input type', start)
    sourcePageStr = strLogin[start:end]

    start = strLogin.find('"__fp" value=')+13
    end = strLogin.find('/></div></form>', start)
    fpStr = strLogin[start:end]

    payload = {"_eventName": 'submit', 'redirectUrl': "/index", 'failUrl': "", 'email': u, 'password': p, "_sourcePage": sourcePageStr, "__fp": fpStr }

    r = session.post('https://runkeeper.com/login', data=payload)

    if "stripesErrorDesc" in r.text or r.status_code != 200:
        print("Error!")
        errorMsg("Attention!", "Wrong username or password!")
        return

    print("Done!")

    # Access route list
    sys.stdout.write(' > Accessing routes...')
    url = "http://runkeeper.com/exportDataForm"
    r = session.get(url)

    count = 0

    fpStr = ""
    sourcePageStr = ""
    strExport = ""

    for line in r.text.splitlines():
        if 'name="__fp"' in line:
            strExport=line
            count=count+1
        if count==2:
            break

    start = strExport.find('"_sourcePage" value=')+20
    end = strExport.find('/><input type', start)
    sourcePageStr= strExport[start:end]

    start = strExport.find('"__fp" value=')+13
    end = strExport.find('/></div></form>', start)
    fpStr = strExport[start:end]

    url = "http://runkeeper.com/exportData"
    payload = {"startDate": "01/01/2000", "endDate": "01/01/2050" , "_sourcePage": sourcePageStr, "__fp": fpStr}
    r = session.post(url, data=payload)

    if "stripesErrorDesc" in r.text or r.status_code != 200:
        print("Error!")
        return
    print("Done!")

    sys.stdout.write(" > Generating export. Should not take more than a few minutes...")
    time.sleep(20)
    print("Done!")

    url = "http://runkeeper.com/exportDataForm"
    r = session.get(url)
    count = 0
    for line in r.text.splitlines():
        if 'href="http://s3.amazonaws' in line:
            strExport = line
            count = count + 1

    if count == 0:
        print(" *** No routes found! ***")
        print("> Crawling Runkeeper...Done!")
        return

    start = strExport.find('href="http://s3.amazonaws')+6
    end = strExport.find('">Download Now!', start)
    download_link = strExport[start:end]

    download_file(download_link)
    print("> Crawling Runkeeper...Done!")


# Crawler for the Endomondo website
def crawlEndomondo(u, p):
    print("Crawling Endomondo...")


# Create Blank Window
win = Tk()
win.wm_title("OverLap")

# Create Title-Logo
try:
    logo = PhotoImage(file='Logo.png')
    title = Label(win, image=logo)
    title.grid(row=0, columnspan=3)
except Exception:
    logo = Label(win, text="OVERLAP", font=("Helvetica", 22))
    logo.grid(row=0, columnspan=3)

# Create Login Form
lblUsername = Label(win, text="Username:", font=("Helvetica", 12))
lblPassword = Label(win, text="Password:", font=("Helvetica", 12))
lblOptions = Label(win, text="Options:", font=("Helvetica", 12))
lblOverlap = Label(win, text="Overlap Routes\n(Coming soon):", font=("Helvetica", 12))
entUsername = Entry(win, font=("Helvetica", 12))
entPassword = Entry(win, font=("Helvetica", 12), show="*")
sites = StringVar(win)
sites.set('Runtastic')
choices = ['Runtastic', 'RunKeeper', 'Endomondo (Coming soon)']
options = OptionMenu(win, sites, *choices)
overlap = StringVar(win)
overlap.set('Only my routes')
overlap_choices = ['Only My Routes', 'Every Available Route']
overlap_options = OptionMenu(win, overlap, *overlap_choices)

# Place Login Form
lblUsername.grid(row=1, sticky=E)
entUsername.grid(row=1, column=1, sticky=W)
lblPassword.grid(row=2, sticky=E)
entPassword.grid(row=2, column=1, sticky=W)
lblOptions.grid(row=3, sticky=E)
options.grid(row=3, column=1, sticky=W)
lblOverlap.grid(row=4, sticky=E)
overlap_options.grid(row=4, column=1, sticky=W)

# Create Login Button
btnLogin = Button(win, text="Login", fg="blue", font=("Helvetica", 12), command=login)
btnLogin.grid(row=5, column=0, sticky=E)

# Create Exit Button
btnExit = Button(win, text="Exit", fg="red", font=("Helvetica", 12), command=exit)
btnExit.grid(row=5, column=1, sticky=W)

# Create Show Buttons
lblShow = Label(win, text="Saved GPX files Manipulation:", font=("Helvetica", 12))
lblShow.grid(row=6, sticky=E)
btnShow = Button(win, text="Show Points in Graph", fg="green", font=("Helvetica", 12), command= lambda:ComputeRoadsAndSee(0))
btnShow.grid(row=7, column=0, sticky=EW)
btnShow2 = Button(win, text="Show Roads in Graph", fg="green", font=("Helvetica", 12), command= lambda:ComputeRoadsAndSee(1))
btnShow2.grid(row=7, column=1, sticky=EW)
btnShow3 = Button(win, text="Show Roads in Map", fg="green", font=("Helvetica", 12), command= lambda:ComputeRoadsAndSee(2))
btnShow3.grid(row=7, column=2, sticky=EW)

# Show Window
win.mainloop()
