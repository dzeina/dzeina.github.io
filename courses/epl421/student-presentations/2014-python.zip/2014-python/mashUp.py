#!/usr/bin/python

import glob
import os
import time
import datetime
import sys
import re

def timestamp(date):
        t=time.mktime(datetime.datetime.strptime(date, '%c').timetuple())
	return int(t);


def toDate(mytime):
	d=datetime.datetime.fromtimestamp(mytime).strftime("%a %b %d %X EEST %Y")
	return d;


def geo_sort(slc):
	path_geo =os.getcwd()+'/geo_msgs/'

	list=[];

	path_geo_twi=path_geo+'twitter_msgs'
        for filename in glob.glob(os.path.join(path_geo_twi, '*.txt')):
		f=open(filename,'r')
    	        data=[]
      	        stringfile=f.read();
                hi=stringfile.split('\nTime:')
   	  	hi2=hi[1].split('\n')
   	  	date_s=hi2[0].replace('+0000 ','')
   	  	data.append(hi[0])
   	  	data.append(timestamp(date_s))
   	  	data.append(hi2[1])
   	  	list.append(data)
   	  	f.close()
  	 
  	path_geo_ray=path_geo+'rayzit_msgs'
        for filename in glob.glob(os.path.join(path_geo_ray, '*.txt')):
  		f=open(filename,'r')
		data=[]
	        stringfile=f.read();
      	        hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                data.append(hi[0])
                data.append(int(hi2[0])/1000)
                data.append(hi2[1])
                list.append(data)
                f.close()

        list.sort(key = lambda x :x[1]) #sort with timesptamp

        if slc==2:
                print list[0][0]+'\nTime:'+toDate(list[0][1])+'\n'+list[0][2]
                return;

        list.reverse()

        for x in list:
                print x[0]+'\nTime:'+toDate(x[1])+'\n'+x[2]

        return;

def latest_sort(slc):
        path_latest =os.getcwd()+'/latest_msgs/'
   
        list=[];
   
        path_latest_twi=path_latest+'twitter_msgs'
        for filename in glob.glob(os.path.join(path_latest_twi, '*.txt')):
                f=open(filename,'r')
                data=[]
                stringfile=f.read();
                hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                date_s=hi2[0].replace('+0000 ','')
                data.append(hi[0])
                data.append(timestamp(date_s))
                data.append(hi2[1])
                list.append(data)
                f.close()
   
        path_latest_ray=path_latest+'rayzit_msgs'
        for filename in glob.glob(os.path.join(path_latest_ray, '*.txt')):
                f=open(filename,'r')
                data=[]
                stringfile=f.read();
                hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                data.append(hi[0])
                data.append(int(hi2[0])/1000)
                data.append(hi2[1])
                list.append(data)
                f.close()
   
        list.sort(key = lambda x :x[1]) #sort with timesptamp

        if slc==2:
                print list[0][0]+'\nTime:'+toDate(list[0][1])+'\n'+list[0][2]
                return;

        list.reverse()
   
        for x in list:
                print x[0]+'\nTime:'+toDate(x[1])+'\n'+x[2]
   
        return;

def max_retransmitted():
        path_geo =os.getcwd()+'/geo_msgs/'

	list=[];

	path_geo_twi=path_geo+'twitter_msgs'
        for filename in glob.glob(os.path.join(path_geo_twi, '*.txt')):
		f=open(filename,'r')
    	        data=[]
      	        stringfile=f.read();
                hi=stringfile.split('\nTime:')
   	  	hi2=hi[1].split('\nRetweet:')
   	  	date_s=hi2[0].replace('+0000 ','')
   	  	data.append(hi[0])
   	  	data.append(timestamp(date_s))
                data.append('Retweet:')
   	  	data.append(int(hi2[1]))
   	  	list.append(data)
   	  	f.close()
  	 
  	path_geo_ray=path_geo+'rayzit_msgs'
        for filename in glob.glob(os.path.join(path_geo_ray, '*.txt')):
  		f=open(filename,'r')
		data=[]
	        stringfile=f.read();
      	        hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\nRerayzs:')
                data.append(hi[0])
                data.append(int(hi2[0])/1000)
                data.append('Rerayzs:')
                data.append(int(hi2[1]))
                list.append(data)
                f.close()

        list.sort(key = lambda x :x[3]) #sort with rerayz/retweet
        length=len(list)
        print list[length-1][0]+'\nTime:'+toDate(list[length-1][1])+'\n'+list[length-1][2]+str(list[length-1][3])
   
        return;        

def lexicon():
	#punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
	#no_punct = ""
	path_geo =os.getcwd()+'/geo_msgs/'

	list=[];
	word_table = {}
	path_geo_twi=path_geo+'twitter_msgs'
        for filename in glob.glob(os.path.join(path_geo_twi, '*.txt')):
		f=open(filename,'r')
    	        data=[]
      	        stringfile=f.read();
                hi=stringfile.split('\nTime:')
   	  	hi2=hi[1].split('\n')
   	  	k=hi[0].replace('Text:','')
		q=k.replace('"','')
                bs=q.replace('\n','')
		space=bs.split(' ')
		for x in space:
			if re.match('^[a-zA-Z0-9_]+$',x):
				if x in word_table:
					word_table[x] += 1
        			else:
            				word_table[x] = 1
        				count = space.count(x)
        				word_table[x] = count
   	  	f.close()
  	 
  	path_geo_ray=path_geo+'rayzit_msgs'
        for filename in glob.glob(os.path.join(path_geo_ray, '*.txt')):
  		f=open(filename,'r')
		data=[]
	        stringfile=f.read();
      	        hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                k=hi[0].replace('Text:','')
                q=k.replace('"','')
                bs=q.replace('\n','')
		space=bs.split(' ')
                for x in space:
			if re.match('^[a-zA-Z0-9_]+$',x):
				if x in word_table:
					word_table[x] += 1
        			else:
            				word_table[x] = 1
        				count = space.count(x)
        				word_table[x] = count
                f.close()

	path_latest =os.getcwd()+'/latest_msgs/'

   
        path_latest_twi=path_latest+'twitter_msgs'
        for filename in glob.glob(os.path.join(path_latest_twi, '*.txt')):
                f=open(filename,'r')
                data=[]
                stringfile=f.read();
                hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                #date_s=hi2[0].replace('+0000 ','')
		k=hi[0].replace('Text:','')
                q=k.replace('"','')
                bs=q.replace('\n','')
		space=bs.split(' ')
                for x in space:
			if re.match('^[a-zA-Z0-9_]+$',x):
				if x in word_table:
					word_table[x] += 1
        			else:
            				word_table[x] = 1
        				count = space.count(x)
        				word_table[x] = count
                f.close()
   
        path_latest_ray=path_latest+'rayzit_msgs'
        for filename in glob.glob(os.path.join(path_latest_ray, '*.txt')):
                f=open(filename,'r')
                data=[]
                stringfile=f.read();
                hi=stringfile.split('\nTime:')
                hi2=hi[1].split('\n')
                k=hi[0].replace('Text:','')
                q=k.replace('"','')
		bs=q.replace('\n','')
		space=bs.split(' ')
                for x in space:
			if re.match('^[a-zA-Z0-9_]+$',x):
				if x in word_table:
					word_table[x] += 1
        			else:
					re.match('^[a-zA-Z0-9_]+$',x)
            				word_table[x] = 1
        				count = space.count(x)
        				word_table[x] = count
                f.close()
	
	lexico=sorted(word_table.items(), key=lambda item: item[1], reverse=True)
	f=open("lexicon.txt",'w')
	for word in lexico:
		f.write(str(word[0])+' '+str(word[1])+'\n')
	return;

def before_date(year):

	yearT=int(time.mktime(datetime.datetime.strptime(str(year), '%Y').timetuple()))

	path_geo =os.getcwd()+'/geo_msgs/'
 	path_geo_twi=path_geo+'twitter_msgs'
 	list=[];
 	for filename in glob.glob(os.path.join(path_geo_twi, '*.txt')):
  		f=open(filename,'r')
  		data=[]
  		stringfile=f.read();
  		hi=stringfile.split('\nTime:')
  		hi2=hi[1].split('\n')
  		date_s=hi2[0].replace('+0000 ','')
		dateT=int(timestamp(date_s))
  		data.append(hi[0])
  		data.append(dateT) 
		data.append(hi2[1])
  		if dateT < yearT:
  			list.append(data)
  	f.close()
  	
 	path_geo_ray=path_geo+'rayzit_msgs'
 	for filename in glob.glob(os.path.join(path_geo_ray, '*.txt')):
  		f=open(filename,'r')
  		data=[]
  		stringfile=f.read();
  		hi=stringfile.split('\nTime:')
  		hi2=hi[1].split('\n')
  		date_s=int(hi2[0])/1000
  		data.append(hi[0])
  		data.append(date_s) 
		data.append(hi2[1])
  		if date_s < yearT:
  			list.append(data)
  		f.close()

	for x in list:
                print x[0]+'\nTime:'+toDate(x[1])+'\n'+x[2]  
 	return;


#a
if sys.argv[1]=='geo-sort':
	geo_sort(1);

#b
elif sys.argv[1]=='latest-sort':
        latest_sort(1);

#c
elif sys.argv[1]=='geo-max-retransmitted':
        max_retransmitted();

#e
elif sys.argv[1]=='geo-oldest':
	geo_sort(2);

#st
elif sys.argv[1]=='latest-oldest':
	latest_sort(2);

#z
elif sys.argv[1]=='all-build-lexicon':
	lexicon();

#d
elif sys.argv[1]=='geo-before-date':
	if len(sys.argv)<3:
		print "Give year!";
	elif len(sys.argv)>3:
		print "Wrong Number of arguments!"
	else:
		year=sys.argv[2];
		before_date(year);
else:
	print "Wrong option! Give 'geo-sort' or 'latest-sort' or 'geo-max-retransmitted' or 'geo-oldest' or 'latest-oldest' or 'all-build-lexicon' or 'geo-before-date <year>'";

