#!/usr/bin/python

import urllib2
import urllib
import json
import time;
import datetime
import string
import random
import sys, getopt
from hashlib import sha1
import hmac
import binascii
import os

if len(sys.argv) !=3:
   print 'Wrong argument!! ./latest_msgs.py [ <screen_name> | <rayzit_time> ]'
   sys.exit(1)

request_url="https://api.twitter.com/1.1/statuses/user_timeline.json" 
oauth_signature_method="HMAC-SHA1"                       	
count="20"
oauth_version="1.0"
oauth_consumer_key="6CNDlXGBIFlB6ZLxCmEiQ"
oauth_token="582308178-bPqPMz4PPINdivpv8JFCgKg3RoKJZRnXFBGdbyxu"
username=sys.argv[1]

localtime=str(time.time())
oauth_nonce=''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(30))

ConsumerSecret="6OMPpsWTYA85noVHiVNnkUa68L8eDaklV38k1IAvM"
tokenSecret="JFvHC2J68clT8hJ53L156pj9gwhXTMX4g6KPlYmbE9Tcb"

value1 ={'count':count}
data1=urllib.urlencode(value1)
value2 ={'oauth_consumer_key':oauth_consumer_key}
data2=urllib.urlencode(value2)
value3 ={'oauth_nonce':oauth_nonce}
data3=urllib.urlencode(value3)
value4 ={'oauth_signature_method':oauth_signature_method}
data4=urllib.urlencode(value4)
value5 ={'oauth_timestamp':localtime}
data5=urllib.urlencode(value5)
value6 ={'oauth_token':oauth_token}
data6=urllib.urlencode(value6)
value7 ={'oauth_version':oauth_version}
data7=urllib.urlencode(value7)
value8 ={'screen_name':username}
data8=urllib.urlencode(value8)

parameter_string=data1+'&'+data2+'&'+data3+'&'+data4+'&'+data5+'&'+data6+'&'+data7+'&'+data8


url=urllib.quote_plus(request_url)

parstring=urllib.quote_plus(parameter_string)

base_string='GET&'+url+'&'+parstring


consec=urllib.quote_plus(ConsumerSecret)
toksec=urllib.quote_plus(tokenSecret)

signing_key=consec+'&'+toksec

hashed=hmac.new(signing_key,base_string,sha1)

sign=binascii.b2a_base64(hashed.digest())[:-1]

signature=urllib.quote_plus(sign)


#Authorization
params='OAuth oauth_consumer_key='+oauth_consumer_key+', oauth_nonce='+oauth_nonce+', oauth_signature='+signature+', oauth_signature_method='+oauth_signature_method+', oauth_timestamp='+localtime+', oauth_token='+oauth_token+', oauth_version='+oauth_version

request_url+='?'+'count='+count+'&screen_name='+username
req=urllib2.Request(request_url)

req.add_header('Authorization', params)

latest_f='latest_msgs'
if not os.path.exists(latest_f):
   os.makedirs(latest_f);


try:
   res = urllib2.urlopen(req)
   tweetdata=json.load(res)

   os.chdir(latest_f)

   twitter_f='twitter_msgs'
   if not os.path.exists(twitter_f):
      os.makedirs(twitter_f);

   os.chdir(twitter_f);

   count=1;
   for status in tweetdata:
      filename=str(count)+'.txt'
      f=open(filename,'w')
      f.write('Text:"'+str(status[u'text'].encode('utf-8'))+'"\n')
      f.write('Time:'+status["created_at"]+'\n')
      f.write('Retweet:'+str(status["retweet_count"]))
      f.close()
      count=eval('count+1');

   os.chdir('../..')
except urllib2.HTTPError,e:
   if e.code == 404:
      print 'Twitter: screen_name '+sys.argv[1]+' not found!'

except urllib2.URLError,e:
   print 'Twitter: Request Problem!'


rayzit_url='http://api.rayzit.com/latest/rayz/'+sys.argv[2]
try:
   rayzitdata=json.load(urllib2.urlopen(rayzit_url))
   statusr=rayzitdata['status']
   if statusr=='error':
      print 'Rayzit: '+rayzitdata['message']
      sys.exit(1)
   os.chdir(latest_f)
   rayz_f='rayzit_msgs'
   if not os.path.exists(rayz_f):
      os.makedirs(rayz_f);

   os.chdir(rayz_f);
   count=1;
   for rayzstatus in rayzitdata['latest']:
      filename=str(count)+'.txt'
      f=open(filename,'w')
      f.write('Text:"'+str(rayzstatus[u'rayz_message'].encode('utf-8'))+'"\n')
      f.write('Time:'+str(rayzstatus['timestamp'])+'\n')
      f.write('Rerayzs:'+str(rayzstatus['rerayz']))
      f.close()
      count=eval('count+1');
   os.chdir('../..')
except urllib2.URLError,e:
   print 'Rayzit: Request Problem!'
