#!/usr/bin/perl
use IO::Socket;
if ($#ARGV != 0) {
    print "VALE VATHOS\n";
    exit;
}
$depth = $ARGV[0];
open(LINKSS, ">>broken$depth.dat");

$start = "www.ucy.ac.cy";
@selides=();
push(@selides,$start);
%visited = ( $start , 0 );
foreach $page (@selides){
    
    if ($visited{ $page } <= $depth){ 
	
	$value=$visited{ $page };
	
	($lala,$ext)=split(/\//,$page,2);
	$socket = IO::Socket::INET->new(PeerAddr => $lala,PeerPort => 80,Proto => 'tcp',Type => SOCK_STREAM)
	    or {print LINKSS "$page\n"};
	unless ($socket) { next };
	print $socket "GET /$ext HTTP/1.0\n\n";
	
	$test=$page;
	$test =~ s/\/\w+\.html//;
	
	open(LINKS, ">>links$depth.dat");
	
	while (defined($line = <$socket>)) {
	    
	    $la=""; 
	    $dummy=0;
	    $line =~ s/</\n</g;
	    $line =~ s/></>\n</g;
	    
	    if (($line =~ m{a href="(.*?\.html)">}gi) || ($line =~ m{a href="(.*?\.txt)">}gi)){
		$la = $1;
		$la =~ s/^\.\//$test\//;
		$la =~ s/^\.\.\/\.\.\//$start\//;
		$la =~ s/^\.\.\//$start\//;
		$la =~ s/http:\/\///;
		if (($page eq "www.ucy.ac.cy/fem/index.html") ||($page eq "www.ucy.ac.cy/~classics/EN/index.html")) {
		    $la = "/" . $la;
		    $la = $test . $la;
		}
		if (($page eq "www.ucy.ac.cy/byz/_en/index.html")  && ($la !~ /www\./)){
		    $la = "/" . $la;
		    $la = $test . $la;
		}
		if (($page =~ "www.ucy.ac.cy/alumni/EL/")  && ($la !~ /www\./)){
		    if ($la =~ /^\//){
			$la = $start . $la;
		    }
		    else{
			$la = "/" . $la;
			$la = $test . $la;
		    }
		}
		
		foreach $selid (@selides){
		    if ( $selid eq $la) {$dummy=1; }
		}
		
		if ($dummy ne 1){
		    chomp $la;
		    print LINKS "$la\n";
		    $cv01=$value+1;
		    $visited { $la } = $cv01; 
		    push(@selides, $la); }
	    }
	}
	
	close($socket);
	close(LINKSs);
    }
}close(LINKS);
