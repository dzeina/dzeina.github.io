<?php require_once('Connections/connection.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_students = "-1";
if (isset($_GET['grade'])) {
  $colname_students = (get_magic_quotes_gpc()) ? $_GET['grade'] : addslashes($_GET['grade']);
}

mysql_select_db($database_connection, $connection);
$query_students = sprintf("SELECT * FROM students WHERE grade = %s ORDER BY surname ASC", GetSQLValueString($colname_students, "text"));
if(!isset($_GET["grade"]))
	$query_students = sprintf("SELECT * FROM students");
$students = mysql_query($query_students, $connection) or die(mysql_error());
$row_students = mysql_fetch_assoc($students);
$totalRows_students = mysql_num_rows($students);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EPL428 Students</title>
</head>

<body>
<table border="1">
  <tr bgcolor="#FFFF99">
    <td>Name</td>
    <td>Surname</td>
    <td>Grade</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_students['name']; ?></td>
      <td><?php echo $row_students['surname']; ?></td>
      <td><?php echo $row_students['grade']; ?></td>
    </tr>
    <?php } while ($row_students = mysql_fetch_assoc($students)); ?>
</table>
<p><a href="addstudent.php"><strong>add new student</strong></a></p>
</body>
</html>
<?php
mysql_free_result($students);
?>
