<TABLE border="1" bgcolor="<?php echo $_GET['color'];?>">
<?php

for($i=0;$i<$_GET['rows'];$i++){	
	echo '<TR>';
	for($j=0;$j<$_GET['columns'];$j++){
		echo '<TD>'.$i.','.$j;
		echo '</TD>';
	}
	echo '</TR>';
}
?>
</TABLE>