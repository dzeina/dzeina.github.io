#!/usr/bin/python 

import thread, time
import random, sys

def counter(myId, count):
    
    for i in range(count): 
        time.sleep(random.uniform(1,3))
        print 'thread number %d reporting' % (myId)

for i in range(5):
    thread.start_new(counter, (i, 3))

time.sleep(10) 
print 'Main thread exiting.'
