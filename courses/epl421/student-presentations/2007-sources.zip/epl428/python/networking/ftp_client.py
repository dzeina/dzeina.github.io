#!/usr/bin/python

from ftplib import FTP

def handleDownload(block):
    file.write(block)
  
# Create an instance of the FTP object
# FTP('hostname', 'username', 'password')
ftp = FTP('ftp.cs.ucy.ac.cy')

print 'Welcome to CS UCY ftp'
# Log in to the server
print 'Logging in.'
# ftp.login('username', 'password')
# Otherwise, it defaults to Anonymous
print ftp.login()

# This is the directory that we want to go to
directory = 'pub/linux/fedora/core/6/x86_64/iso/'

print 'Changing to ' + directory
ftp.cwd(directory)

# Print the contents of the directory
ftp.retrlines('LIST')

filename = 'FC-6-x86_64-rescuecd.iso'

# Open the file for writing in binary mode
print 'Opening local file ' + filename
file = open(filename, 'wb')


print 'Getting ' + filename
ftp.retrbinary('RETR ' + filename, handleDownload)

print 'Closing file ' + filename
file.close()

print 'Closing FTP connection'
ftp.close()

