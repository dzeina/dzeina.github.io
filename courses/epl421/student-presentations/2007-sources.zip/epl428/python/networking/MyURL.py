#!/usr/bin/python 

import urllib

MyURL="http://www.cs.ucy.ac.cy"
urllib.urlretrieve(MyURL, "index.html")
urllib.urlcleanup()
