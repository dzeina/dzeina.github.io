##
# Copyright 2004 Gregory Trubetskoy <grisha@modpython.org>
#

#
#    A Mod_python Example: Using Publisher with PSP 
#

"""

This example demonstrates a practical use of the Publisher
handler in conjunction with PSP as a templating mechanism.

Here we have a farily typical corporate site with a few
pages: "home", "product" and "about". The site contains
a menu which lets you go to any one of those pages. The
menu highlights the page you're on.

The layout of the site uses the main template, which
consists of an HTML table which provides space for the
menu component and the body component.

Apache config:

  SetHandler mod_python
  PythonHandler mod_python.publisher

"""

import os
from mod_python import psp

# subdirectory where we place templates
TMPL_DIR = "templates"

# the name for the "shell" template
MAIN_TMPL = "main_frame.html"
# the menu template
MENU_TMPL = "main_menu.html"


##
# External functions. These can be accessed via URL's from
# outside.

def index(req):
    # The publisher will call this function as default,
    # make it same as home
    return home(req)

def home(req):
    return _any_page(req, 'home')

def product(req):
    return _any_page(req, 'product')

def about(req):
    return _any_page(req, 'about')


##
# Internal functions. Because they begin with an underscore,
# the publisher will not allow them to be accessible from the
# web. Perhaps a cleaner technique is to place these into a
# seprate module. If that module contains __access__ = 0 global
# variable, then none of its contents would be accessible via
# the publisher, in which case you don't need to prepend
# underscores to function names.

def _base_url(req, ssl=0):
    """
    This function makes its best effort to guess the base url.
    Sometimes it is simpler to just hard code the base url as
    a constant, but doing something like this makes the application
    independent of what the name of the site is.
    """
    
    # first choice is the 'Host' header, second is the
    # hostname in the Apache server configuration.
    host = req.headers_in.get('host', req.server.server_hostname)
    
    # are we running on an unusual port?
    if not ':' in host:
        port = req.connection.local_addr[1]
        if port != 80 and not ssl:
            host = "%s:%d" % (host, req.connection.local_addr[1])

    # SSL?        
    if ssl:
        base = 'https://' + host + req.uri
    else:
        base = 'http://' + host + req.uri

    # chop off the last part of the URL    
    return os.path.split(base)[0]

def _tmpl_path(name):
    """ A shorthand for building a full path to a template """
    return os.path.join(TMPL_DIR, name)

def _menu(req, hlight, tmpl=MENU_TMPL):
    """
    This function builds a menu. The actual menu contents is inside the
    PSP template whose file name is passed in as tmpl. The hlight string
    gives the menu an opportunity to highlight a particular menu item.
    """

    tmpl = _tmpl_path(tmpl)
    m = psp.PSP(req, tmpl, vars={'hlight':hlight})
    return m

def _any_page(req, name):
    """
    Construct a web page given a page name, which is a string identifier
    that is also passed to the _menu() function to highlight the current
    menu item, and is used to construct the filename for the page template.
    """

    body_tmpl = _tmpl_path('%s_body.html' % name)

    vars = {"menu": _menu(req, hlight=name),
            "body": psp.PSP(req, body_tmpl)}

    main_tmpl = _tmpl_path(MAIN_TMPL)

    return psp.PSP(req, main_tmpl, vars=vars)

