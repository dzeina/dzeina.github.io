from xml.dom import minidom
xmldoc = minidom.parse('grammar.xml')
print xmldoc.toxml()
