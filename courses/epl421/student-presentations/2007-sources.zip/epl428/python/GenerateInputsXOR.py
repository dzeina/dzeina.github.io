#! /usr/bin/python
import random, sys
try:
        file = open('inputs.dat', 'w')
        i = 0
        iterations = int(sys.argv[1])
        while i < iterations:
            a= random.uniform(-0.05,1.05)
            b= random.uniform(-0.05,1.05)
            if (b >= 0.95 or b<=0.05) and (a<=0.05 or a>=0.95):
            	c = round(a) + round(b)
                if c==2:
                    c=0
                line = "%.3f\t%.3f\t%i\n" % (a,b,c)
                file.write(line)
                i= i + 1
        file.flush()
        file.close()
except IOError:
        print 'Can\'t open file for writing.'
        sys.exit(0)
