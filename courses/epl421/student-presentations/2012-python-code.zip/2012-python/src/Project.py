#! /usr/bin/env python

import sys
import httplib
import os
import getpass
import re
import datetime
up=re.compile('<A\s*HREF=(.*?)>')
low=re.compile('<a\s*href=(.*?)>')


# Function that checks if the arguments are correct
def checkArguments():
    if (len(sys.argv) != 3):
	print "You must give only two arguments!!!"
	print "Example: Project.py [starting link] [depth]"
	print "Exiting..."
	sys.exit()
    elif (int(sys.argv[2]) < 0): 
	print "The depth must be equal or greater than zero(0)!!!"
	print "Exiting..."
	sys.exit()

# Call function checkArguments with args(number of bash shell arguments,arg2=depth)
checkArguments()

# Set variables
URL=sys.argv[1]		                # URL given by the user as an argument(1)
givendepth=int(sys.argv[2])            	# The depth given by the user as an argument(2)
ALLindex=0	                        # On which position of ALL table I am working on
ALL = [URL+"/index.html"];	        # ALL is a table that contains all the links found for the given depth. ALL[0] contains the homepage of the given URL
brokenList = []                         # A list with all the broken urls
lexiconList = []                        # A list with all the words


while (True):
    #Get the size of table ALL
    ALLsize=len(ALL)		
    
    #Break out of loop if all positions of table ALL have been read
    if (ALLindex == ALLsize):
        break

    #Get the page from position=ALLindex of table ALL
    PAGE=ALL[ALLindex].split(URL)

    ####################################################
    ## Get page status (200,404,...) and Content-Type ##
    ####################################################
    conn = httplib.HTTPConnection(URL,80)
    conn.request("GET",PAGE[1])
    r1 = conn.getresponse()
    status = r1.status
    contentType = r1.getheader("content-type")
    body = r1.read()
    data = body.replace("\r","\n")
    A=data.split('\n')
    s=""
    for i in xrange(len(A)):
        s=s+A[i]
    conn.close()


    ############################################################
    ## We care only for text/html and text/plain content type ##
    ############################################################
    if (contentType.startswith("text/html") or contentType.startswith("text/plain")):
        #URL is OK!
        if ( status==200 ):
            #Add words in lexiconList
            Words = body.replace("\n", " ")
            Words = Words.replace("\r", " ") 
            Words = Words.replace("[", " ")
            Words = Words.replace("]", " ")
            Words = Words.replace(")", " ")
            Words = Words.replace("(", " ")
            Words = Words.replace("-", " ")
            Words = Words.replace("_", " ")
            Words = Words.replace(",", " ")
            Words = Words.replace("=", " ")
            #replace consecutive spaces into a single one
            Words = " ".join(Words.split())  
            #Upper case letters converted to lower case letters
            Words = Words.lower()
            #remove all that is included between <>
            p=re.compile(r'<.*?>')
            q=re.compile(r'&.*?;')
            r=re.compile(r'<!--.*?-->')
            Words = p.sub(' ', Words)
            #replace consecutive spaces into a single one
            Words = " ".join(Words.split())  
            #remove all words between & and ;
            Words = q.sub('', Words)
            #remove all words between <!--and -->
            Words = r.sub('', Words)
            Words=Words.split(" ")
            #Remove all empty strings from a list of strings
            Words = filter(None, Words)
            for item in Words:
                lexiconList.append(item)

            #Now...Let's find the links of this page...
            linksList=[]    
            upper=up.findall(s)
            for i in xrange(len(upper)):
                if (upper[i].startswith("\"")):
                    link=upper[i].split("\"")
                    link2=link[1]
                elif (upper[i].startswith("\'")):
                    link=upper[i].split("\'")
                    link2=link[1]
                else:
                    link=upper[i].split()
                    link2=link[0]

                if (link2.startswith("http://"+URL)):
                    link3=link2.split("http://")
                    linksList.append(link3[1])
                elif (link2.startswith("./")):
                    link3=link2.split("./")
                    lastoc=PAGE[1].rfind("/")+1
                    p=PAGE[1]
                    linksList.append(URL+p[:lastoc]+link3[1])
                elif (link2.startswith("../")):
                    timesGoBack = link2.count("../")+1
                    lastoc = link2.rfind("../")+3
                    newlink = link2[lastoc:]
                    p=PAGE[1]
                    repeats=0
                    while (repeats<timesGoBack):
                        lastSlash=p.rfind("/")
                        p=p[:lastSlash]
                        repeats=repeats+1
                    linksList.append(URL+p+"/"+newlink)

            lower=low.findall(s)
            for i in xrange(len(lower)):
                if (lower[i].startswith("\"")):
                    link=lower[i].split("\"")
                    link2=link[1]
                elif (lower[i].startswith("\'")):
                    link=lower[i].split("\'")
                    link2=link[1]
                else:
                    link=lower[i].split()
                    link2=link[0]
        
                if (link2.startswith("http://"+URL)):
                    link3=link2.split("http://")
                    linksList.append(link3[1])
                elif (link2.startswith("./")):
                    link3=link2.split("./")
                    lastoc=PAGE[1].rfind("/")+1
                    p=PAGE[1]
                    linksList.append(URL+p[:lastoc]+link3[1])
                elif (link2.startswith("../")):
                    timesGoBack = link2.count("../")+1
                    lastoc = link2.rfind("../")+3
                    newlink = link2[lastoc:]
                    p=PAGE[1]
                    repeats=0
                    while (repeats<timesGoBack):
                        lastSlash=p.rfind("/")
                        p=p[:lastSlash]
                        repeats=repeats+1
                    linksList.append(URL+p+"/"+newlink)

            #Uniq links found in current page
            uniqLinksOfPage=list(set(linksList))

            #############################################
            ## Put links from uniqLinksOfPage into ALL ##
            #############################################
            for i in xrange(len(uniqLinksOfPage)):
                PAGEk=uniqLinksOfPage[i].split(URL)
                conn = httplib.HTTPConnection(URL,80)
                conn.request("GET",PAGEk[1])
                r2 = conn.getresponse()
                statusk = r2.status
                contentTypek = r2.getheader("content-type")
                conn.close()
                if (statusk!=200):
                    brokenList.append("http://"+URL+PAGEk[1])
                    continue
                if (contentTypek.startswith("text/html") or contentTypek.startswith("text/plain")):
                    linkdepth=uniqLinksOfPage[i].count("/")-1
                    #Check if the link depth is <= of the given depth
                    if (linkdepth<=givendepth):
                        exists=0
                        for j in xrange(ALLsize):
                            if (ALL[j]==uniqLinksOfPage[i]):
                                exists=1
                                break
                        #Add link in table ALL only if it does not already exist in it
                        if (exists==0):
                            ALL.append(uniqLinksOfPage[i])
        #URL is broken! Add it to brokenurls.txt	  
        else:
            brokenList.append("http://"+URL+PAGE[1])     
    ############################################################
    ## We care only for text/html and text/plain content type ##
    ############################################################
            
    

    #Go to next position of table ALL
    ALLindex=ALLindex+1




#Print the broken urls in file
uniqBroken=list(set(brokenList))
if (len(uniqBroken)>0):
    FILE = open("brokenurls.txt","w")
    for i in xrange(len(uniqBroken)):
        FILE.write("%s\n" % (uniqBroken[i]))
    FILE.close()


#get date and time
now=datetime.datetime.now()
#make it string "lexicon_Date21-04-2012_Time14:05:09.txt"
lexiconFile="lexicon_"+now.strftime("Date%d-%m-%Y_Time%H:%M:%S")+".txt"
#Dimiourgei i an iparxei anoigei to lexiconFile
FILE = open(lexiconFile,"w")
#Metra tis emfaniseis ton lekseon stin lexiconList kai tis bazei sto lexicon.txt
count = {}
for i in xrange(len(lexiconList)):
    if lexiconList[i] in count:
        count[lexiconList[i]] += 1
    else:
        count[lexiconList[i]] = 1
for word, times in count.items():
    FILE.write("%d %s \n" % (times, word))
FILE.close()




# Create folders
if not os.path.isdir('tmp'):
    os.makedirs('tmp')
os.chdir('tmp')
#Get name of the user
user=getpass.getuser()
if not os.path.isdir(user):
    os.makedirs(user)
os.chdir(user)
if not os.path.isdir('data'):
    os.makedirs('data')
os.chdir('data')

j=0
while True: 
    # Create table Folders
    FOLDERS=[]
    FOLDERS= ALL[j].split("/")
    k=0
    FOLDERSsize=len(FOLDERS)
    iamfile=FOLDERSsize-1
    PAGE=ALL[j].split(URL) 
    filename= FOLDERS[len(FOLDERS)-1]

    while True:
        if ( k == iamfile ): 
            conn = httplib.HTTPConnection(URL,80)
            conn.request("GET",PAGE[1])
            r1 = conn.getresponse()
            body = r1.read()
            conn.close()
            FILE = open(filename,"w")
            FILE.writelines(body)
            FILE.close()
         
        else:
            if not os.path.isdir(FOLDERS[k]):
                os.makedirs(FOLDERS[k])
            os.chdir(FOLDERS[k])
	
        k=k+1
        if ( k == len(FOLDERS) ):
            break

    l=0
    while True:
        os.chdir("..")
        l=l+1
        if ( l == iamfile ):
            break
  
    j=j+1
    if ( j == len(ALL) ):
        break




