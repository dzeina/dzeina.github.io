#!/bin/bash
echo -e "WiFi Down\c"
echo -e "\t-\c"
ifdown eth0
echo -e "\t[DONE]"
sleep 1

echo -e "GPS Down\c"
/etc/init.d/gpsd stop
echo -e "\t-\c"
echo 0 > /sys/class/i2c-adapter/i2c-0/0-0073/neo1973-pm-gps.0/pwron
sleep 1
echo -e "\t[DONE]"
sleep 1

