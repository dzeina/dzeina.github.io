#!/bin/bash
echo -e "GPS Start\c"
echo "GPS_DEV=\"/dev/ttySAC1\"" > /etc/default/gpsd
/etc/init.d/gpsd restart
echo -e "\t-\c"
echo 0 > /sys/class/i2c-adapter/i2c-0/0-0073/neo1973-pm-gps.0/pwron
sleep 1
echo 1 > /sys/class/i2c-adapter/i2c-0/0-0073/neo1973-pm-gps.0/pwron
stty -F /dev/ttySAC1 -echo
echo -e "\t[DONE]"
sleep 1

echo -e "WiFi Start\c"
iwconfig eth0 essid li3is
echo -e "\t-\c"
ifup eth0
echo -e "\t[DONE]"
sleep 1

