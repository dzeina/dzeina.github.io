#!/usr/bin/python

import etk
import commands

icon = etk.Image()
icon.set_from_file('/home/root/george/prog/tux.png')

def exit(target):
  #commands.getstatusoutput('/home/root/george/prog/stop.bash')
  #Due to the very long time needed to Activate. We have disabled this options for this Presentation
  etk.main_quit()

def update(target):
  #commands.getstatusoutput('/home/root/george/prog/start.bash')
  #dynamicLabel.text
  #p = "GPGLL,3509.12370,N,03324.08143,E,173256.00,A,A*6D"
  p = `commands.getoutput('head -n 18 /dev/ttySAC1 | grep -v ^$ | grep GPGLL | tee coord.txt')`
  p  = p.replace('GPGLL,','')
  pos1 = p.find(',N')
  f = p[:pos1]
  pos2 =  p.find(',E')
  f2 = p[pos1+3:pos2]
  dynamicLabel.text=f+"N "+f2+"E"
  commands.getstatusoutput("wget  \"http://xeirwn.bytefreaks.net/openmoko/?longitude="+f+"&latitude="+f2+"\"")
  #commands.getstatusoutput('wget --load-cookies coord.txt http://xeirwn.bytefreaks.net/openmoko/')

exitButton =  etk.Button(label="Bye Bye")
exitButton.on_clicked(exit)
updateButton = etk.Button(label="Update Position")
updateButton.on_clicked(update)
staticLabel = etk.Label(text="Your Current GPS position is:", alignment=(0.5, 0.5))
dynamicLabel = etk.Label(text="Press the Button Below!!", alignment=(0.5, 0.5))

box = etk.VBox()
box.append(exitButton, etk.VBox.START, etk.VBox.FILL, 0)
box.append(icon, etk.VBox.START, etk.VBox.FILL, 0)
box.append(staticLabel, etk.VBox.START, etk.VBox.FILL, 0) 
box.append(dynamicLabel, etk.VBox.START, etk.VBox.FILL, 0)
box.append(updateButton, etk.VBox.START, etk.VBox.FILL, 0)

w = etk.Window(title="Murloc GPS", size_request=(300, 300), child=box)
w.on_destroyed(lambda x: etk.main_quit())
w.show_all()

etk.main()
