//
//  Contansts.h
//  Contansts
//
//  Created by MajorTom on 9/7/10.
//  Copyright iphonegametutorials.com 2010. All rights reserved.
//

#define kStartX 180
#define kStartY 50
#define kMaxLevelNo 10
#define kMaxRecordCount 5
#define kKindCount 25
#define kSolvedText 125
#define kMoveTileTime 0.3f

//Easy
#define kTileSizeEasy 134.0f
#define kBoxWidthEasy 3
#define kBoxHeightEasy 3

//Medium
#define kTileSizeMedium 80.0f
#define kBoxWidthMedium 5
#define kBoxHeightMedium 5

//Hard
#define kTileSizeHard 57.143f
#define kBoxWidthHard 7
#define kBoxHeightHard 7
