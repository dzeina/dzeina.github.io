//
//  HelloWorldLayer.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


#import "cocos2d.h"
#import "MenuLayer.h"
#import "PlayLayerEasy.h"
#import "PlayLayerMedium.h"
#import "PlayLayerHard.h"
#import "Difficulty.h"
#import "CreditsLayer.h"

@interface SceneManager : NSObject {
}

+(void) goMenu;
+(void) goPlay;
+(void) goCredits;
+(void) goQuit;
+(void) goEasy;
+(void) goMedium;
+(void) goHard;

@end