//
//  Difficulty.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Difficulty.h"

@implementation Difficulty
-(id) init{
	self = [super init];
   
	CCMenuItemFont *easy = [CCMenuItemFont itemFromString:@"Easy" target:self selector:@selector(onEasy:)];
    CCMenuItemFont *medium = [CCMenuItemFont itemFromString:@"     Medium" target:self selector:@selector(onMedium:)];
    CCMenuItemFont *hard = [CCMenuItemFont itemFromString:@"         Hard" target:self selector:@selector(onHard:)];
	CCMenu *display = [CCMenu menuWithItems:easy, medium, hard, nil];
    
	display.position = ccp(600, 750);
	[display alignItemsVerticallyWithPadding: 40.0f];
	[self addChild:display];
    
	return self;
}

- (void)onEasy:(id)sender{
	[SceneManager goEasy];
}

- (void)onMedium:(id)sender{
	[SceneManager goMedium];
}

- (void)onHard:(id)sender{
	[SceneManager goHard];
}

@end
