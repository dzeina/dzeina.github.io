//
//  CreditsLayer.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CreditsLayer.h"

@implementation CreditsLayer
-(id) init{
	self = [super init];
	if (!self) {
		return nil;
	}
    CCLabelTTF *name2 = [CCLabelTTF labelWithString:@"Andreas Demetriou" fontName:@"Marker Felt" fontSize:48];
    CCLabelTTF *name4 = [CCLabelTTF labelWithString:@"Christos Vasiliou" fontName:@"Marker Felt" fontSize:48];
    CCLabelTTF *name1 = [CCLabelTTF labelWithString:@"Margarita Papaefthimiou " fontName:@"Marker Felt" fontSize:48];
    CCLabelTTF *name3 = [CCLabelTTF labelWithString:@"Myria Hadjitheori" fontName:@"Marker Felt" fontSize:48];
    CCMenuItemFont *back = [CCMenuItemFont itemFromString:@"back" target:self selector: @selector(back:)];
	CCMenu *menu = [CCMenu menuWithItems: back, nil];
    
    name1.position = ccp(512, 974);
	[self addChild: name1];
    name2.position = ccp(564, 894);
	[self addChild: name2];
    name3.position = ccp(570, 814);
	[self addChild: name3];
    name4.position = ccp(584, 734);
	[self addChild: name4];
    
	menu.position = ccp(718, 50);
	[self addChild: menu];
    
	return self;
}

-(void) back: (id) sender{
	[SceneManager goMenu];
}

@end