//
//  Timer.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Timer.h"

@implementation Timer

-(id) init {
    self = [super init];
    timeLabel = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%02d:%02d", mins, secs]fontName:@"Marker Felt" fontSize:18];
    timeLabel.position = ccp(60, 160);
    [self schedule: @selector(tickCounter:) interval:1.0];
    [self addChild:timeLabel];
    return self;
}
-(void) tickCounter: (ccTime) dt {
    // using deltatime
    timeInt++;
    secs = timeInt % 60;
    mins = timeInt / 60;
    [timeLabel setString:[NSString stringWithFormat:@"%02d:%02d", mins, secs]];
}

@end
