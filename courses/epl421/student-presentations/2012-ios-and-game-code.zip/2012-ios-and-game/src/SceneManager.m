//
//  HelloWorldLayer.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


#import "SceneManager.h"

@interface SceneManager ()
+(void) go: (CCLayer *) layer;
+(CCScene *) wrap: (CCLayer *) layer;
@end

@implementation SceneManager

+(void) goMenu{
	CCLayer *layer = [MenuLayer node];
	[SceneManager go: layer];
}

+(void) goPlay{
	CCLayer *layer = [Difficulty node];
	[SceneManager go: layer];
}

+(void) goCredits{
	CCLayer *layer = [CreditsLayer node];
	[SceneManager go: layer];
}

+(void) goEasy{
	CCLayer *layer = [PlayLayerEasy node];
	[SceneManager go: layer];
}

+(void) goMedium{
	CCLayer *layer = [PlayLayerMedium node];
	[SceneManager go: layer];
}

+(void) goHard{
	CCLayer *layer = [PlayLayerHard node];
	[SceneManager go: layer];
}

+(void) goQuit{
    exit(0);
}

+(void) go: (CCLayer *) layer{
	CCDirector *director = [CCDirector sharedDirector];
	CCScene *newScene = [SceneManager wrap:layer];
	if ([director runningScene]) {
		[director replaceScene: newScene];
	}else {
		[director runWithScene:newScene];
	}
}

+(CCScene *) wrap: (CCLayer *) layer{
	CCScene *newScene = [CCScene node];
	[newScene addChild: layer];
	return newScene;
}



@end