//
//  Box.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

#import "Constants.h"
#import "Tile.h"

@interface Box : NSObject {
	id first, second;
	CGSize size;
	NSMutableArray *content;
	NSMutableSet *readyToRemoveTiles;
	BOOL lock;
	CCLayer *layer;
	Tile *OutBorderTile;
	int type;
	NSInteger imgValue;
}
@property(nonatomic, retain) CCLayer *layer;
@property(nonatomic, readonly) CGSize size;
@property(nonatomic) BOOL lock;
@property(nonatomic) int type;

-(id) initWithSize: (CGSize) size imgValue: (int) aImgValue newtype:(int)newtype;
-(Tile *) objectAtX: (int) posX Y: (int) posY;
-(BOOL) check;
-(BOOL) checkSolution;
@end

