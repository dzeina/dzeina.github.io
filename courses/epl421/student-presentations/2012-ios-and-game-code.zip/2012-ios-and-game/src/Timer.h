//
//  Timer.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "Box.h"

@interface Timer : CCLayer{
    int mins, secs, timeInt;
    CCLabelTTF *timeLabel;
}
@end
