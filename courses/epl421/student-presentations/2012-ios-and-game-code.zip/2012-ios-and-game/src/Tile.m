//
//  Tile.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Tile.h"

@implementation Tile
@synthesize x, y, value,originalValue, sprite, type;

-(id) initWithX: (int) posX Y: (int) posY newtype:(int)newtype{
	self = [super init];
	x = posX;
	y = posY;
    type = newtype;
	return self;
}

-(BOOL) nearTile: (Tile *)othertile{
	return
	(x == othertile.x && abs(y - othertile.y)==1)
	||
	(y == othertile.y && abs(x - othertile.x)==1);
}

-(void) trade: (Tile *)otherTile{
	CCSprite *tempSprite = [sprite retain];
	int tempValue = value;
	self.sprite = otherTile.sprite;
	self.value = otherTile.value;
	otherTile.sprite = tempSprite;
	otherTile.value = tempValue;
	[tempSprite release];
}

-(CGPoint) pixPosition{
if (type == 1){
    return ccp(kStartX + x * kTileSizeEasy +kTileSizeEasy/2.0f,kStartY + y * kTileSizeEasy +kTileSizeEasy/2.0f);
}
else if (type == 2){
    return ccp(kStartX + x * kTileSizeMedium +kTileSizeMedium/2.0f,kStartY + y * kTileSizeMedium +kTileSizeMedium/2.0f);
}else{
    return ccp(kStartX + x * kTileSizeHard +kTileSizeHard/2.0f,kStartY + y * kTileSizeHard +kTileSizeHard/2.0f);
}
	
}

@end
