//
//  Box.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Box.h"

@implementation Box
@synthesize layer;
@synthesize size;
@synthesize lock;
@synthesize type;

-(id) initWithSize: (CGSize) aSize imgValue: (int) aImgValue newtype:(int)newtype{
	self = [super init];
    type = newtype;
	imgValue = aImgValue;
	size = aSize;
	OutBorderTile = [[Tile alloc] initWithX:-1 Y:-1 newtype:type];
	content = [NSMutableArray arrayWithCapacity: size.height];
	
	readyToRemoveTiles = [NSMutableSet setWithCapacity:50];
	
	for (int y=0; y<size.height; y++) {
		
		NSMutableArray *rowContent = [NSMutableArray arrayWithCapacity:size.width];
		for (int x=0; x < size.width; x++) {
			Tile *tile = [[Tile alloc] initWithX:x Y:y newtype:type];
			[rowContent addObject:tile];
			[readyToRemoveTiles addObject:tile];
			[tile release];
		}
		[content addObject:rowContent];
		[content retain];
	}
	
	[readyToRemoveTiles retain];
	
	return self;
}

-(Tile *) objectAtX: (int) x Y: (int) y{
    if (type == 1){
        if (x < 0 || x >= kBoxWidthEasy || y < 0 || y >= kBoxHeightEasy) {
            return OutBorderTile;
        }
        return [[content objectAtIndex: y] objectAtIndex: x];
    }
    else if (type == 2){
        if (x < 0 || x >= kBoxWidthMedium || y < 0 || y >= kBoxHeightMedium) {
            return OutBorderTile;
        }
        return [[content objectAtIndex: y] objectAtIndex: x];
    }else{
        if (x < 0 || x >= kBoxWidthHard || y < 0 || y >= kBoxHeightHard) {
            return OutBorderTile;
        }
        return [[content objectAtIndex: y] objectAtIndex: x];
    }
	
}

-(BOOL) check{
	
	NSArray *objects = [[readyToRemoveTiles objectEnumerator] allObjects];
	if ([objects count] == 0) {
		return NO;
	}
	
	int countTile = [objects count];
	for (int i=0; i<countTile; i++) {
		Tile *tile = [objects objectAtIndex:i];
		if (tile.value == 0) {
			[readyToRemoveTiles addObject:tile];
			continue;
		}
		
		tile.value = 0;
		if (tile.sprite) {
			[layer removeChild: tile.sprite cleanup:YES];
		}
	}
    
	[readyToRemoveTiles removeAllObjects];
    
	NSString *name = [NSString stringWithFormat:@"%d.png",imgValue];	
    
	CCTexture2D * texture = [[CCTextureCache sharedTextureCache] addImage:name];
	NSMutableArray *imgFrames = [NSMutableArray array];
	[imgFrames removeAllObjects];
    int BoxHeight;   
    int BoxWidth;  
    int TileSize;   
       if (type == 1){
           BoxHeight = kBoxHeightEasy;   
           BoxWidth = kBoxWidthEasy;   
           TileSize = kTileSizeEasy;
       }else if (type == 2){
           BoxHeight = kBoxHeightMedium;   
           BoxWidth = kBoxWidthMedium;   
           TileSize = kTileSizeMedium;
       }else{
           BoxHeight = kBoxHeightHard;   
           BoxWidth = kBoxWidthHard;   
           TileSize = kTileSizeHard;
       }
        
	for (int i = 0; i < BoxHeight; i++) {
		for (int j = BoxWidth-1; j >= 0; j--) {
			CCSpriteFrame *imgFrame = [CCSpriteFrame frameWithTexture:texture rect:CGRectMake(i*TileSize, j*TileSize, TileSize, TileSize)];
                                        
			[imgFrames addObject:imgFrame];
		}
	}
    
	
    /*NSUInteger count = [imgFrames count];
    for (NSUInteger i = 0; i < count; ++i) {
        // Select a random element between i and end of array to swap with.
        int nElements = count - i;
        int n = (arc4random() % nElements) + i;
        [imgFrames exchangeObjectAtIndex:i withObjectAtIndex:n];
    }*/
	
	for (int x=0; x<size.width; x++) {
		for (int i=0; i<size.height; i++) {
			Tile *destTile = [self objectAtX:x Y:i];
			CCSpriteFrame * img = [imgFrames objectAtIndex:0];
			CCSprite *sprite = [CCSprite spriteWithSpriteFrame:img];
			[imgFrames removeObjectIdenticalTo:img];
          sprite.position = ccp(kStartX + x * TileSize + TileSize/2, kStartY + (BoxHeight + i) * TileSize + TileSize/2 - TileSize * size.height);
			[layer addChild: sprite];
            
			destTile.value = (BoxHeight * destTile.x) + destTile.y;
			destTile.originalValue = destTile.value;
			destTile.sprite = sprite;
			
			NSLog(@"Tile - X = %i, Y = %i, Value - %i",destTile.x, destTile.y, destTile.value);
			
		}
	}
    
	
    
    /*for(int i =0; i<kBoxWidth; i++){
        for(int j = 0 ; j<kBoxHeight;j++){
            Tile *a = [self objectAtX:i Y:j];
            [layer addChild:a.sprite];
        }
    }*/

	return YES;
}

-(BOOL) checkSolution {
	
	BOOL isSolved = true;
	
	for (int x=0; x<size.width; x++) {
		for (int y=0; y<size.height; y++) {
			Tile *tile = [self objectAtX:x Y:y];
			
			if (tile.originalValue != tile.value) {
				isSolved = false;
			}
		}
	}
	
	if (isSolved) {
		NSLog(@"The Sliding Image is Solved");
		return true;
	} else {
		NSLog(@"The Sliding Image is NOT Solved");
		return false;
	}	
	
	return true;
}

@end