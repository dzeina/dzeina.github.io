//
//  Tile.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

#import "Constants.h"

@interface Tile : NSObject {
	int x, y, value, originalValue;
	CCSprite *sprite;
    int type;
}

-(id) initWithX: (int) posX Y: (int) posY newtype:(int) newtype;
@property (nonatomic, readonly) int x, y;
@property (nonatomic) int value;
@property (nonatomic) int type;
@property (nonatomic) int originalValue;
@property (nonatomic, retain) CCSprite *sprite;
-(BOOL) nearTile: (Tile *)othertile;
-(void) trade:(Tile *)otherTile;
-(CGPoint) pixPosition;
@end
