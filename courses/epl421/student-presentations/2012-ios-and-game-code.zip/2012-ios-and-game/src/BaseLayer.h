//
//  BaseLayer.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface BaseLayer : CCLayer{
    
}

@end