//
//  MenyLayer.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MenuLayer.h"

@implementation MenuLayer

-(id) init{
	self = [super init];
    
	CCLabelTTF *title = [CCLabelTTF labelWithString:@"SlideIt" fontName:@"Marker Felt" fontSize:100];
	CCMenuItemFont *startNew = [CCMenuItemFont itemFromString:@"New Game" target:self selector:@selector(onNewGame:)];
    CCMenuItemFont *credits = [CCMenuItemFont itemFromString:@"     Credits" target:self selector:@selector(onCredits:)];
    CCMenuItemFont *quit = [CCMenuItemFont itemFromString:@"         Quit" target:self selector:@selector(onQuit:)];
	CCMenu *menu = [CCMenu menuWithItems:startNew, credits, quit, nil];
    
	title.position = ccp(550, 930);
	[self addChild: title];

	menu.position = ccp(600, 750);
	[menu alignItemsVerticallyWithPadding: 40.0f];
	[self addChild:menu z: 2];
    
	return self;
}

- (void)onNewGame:(id)sender{
	[SceneManager goPlay];
}

- (void)onCredits:(id)sender{
	[SceneManager goCredits];
}

- (void)onQuit:(id)sender{
	[SceneManager goQuit];
}
@end