//
//  Difficulty.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "BaseLayer.h"
#import "SceneManager.h"

@interface Difficulty : BaseLayer{
}
- (void)onEasy:(id)sender;
- (void)onMedium:(id)sender;
- (void)onHard:(id)sender;
@end
