//
//  PlayLayer.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "BaseLayer.h"
#import "SceneManager.h"
#import "Box.h"

@interface PlayLayerHard: BaseLayer {
	Box *box;
	Tile *selectedTile;
    Tile *firstOne;
	
	BOOL isMoving;
	NSInteger value;
    
    int mins, secs, timeInt;
    CCLabelTTF *timeLabel;
    CCLabelTTF *congrats;
    
    int counter;
    CCLabelTTF *label;
    
    
    
}

-(void) changeWithTileA: (Tile *) a TileB: (Tile *) b sel : (SEL) sel;
-(void) check: (id) sender data: (id) data;
-(void) back: (id) sender;
-(void) addToCounter;
-(void) updateLabel;
@end
