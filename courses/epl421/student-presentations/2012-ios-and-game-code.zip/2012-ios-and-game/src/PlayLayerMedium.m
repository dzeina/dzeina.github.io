
//
//  PlayLayer.m
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "PlayLayerMedium.h"

@implementation PlayLayerMedium
-(id) init{
	self = [super init];
	if (!self) {
		return nil;
	}
    NSLog(@"kkindcount %d",kKindCount);
    value = (arc4random() % kKindCount+1);
	box = [[Box alloc] initWithSize:CGSizeMake(kBoxWidthMedium,kBoxHeightMedium) imgValue:value newtype:2];
    
	box.layer = self;
	//box.lock = YES;	
    
	[box check];
    
    NSInteger count = kBoxWidthMedium*kBoxHeightMedium;
    for ( int i = 0; i<count ; i++){
        int x1 ;
        int y1 ;
        int x2 ;
        int y2 ;
        do{
            x1 = (arc4random() % kBoxWidthMedium);
            y1 = (arc4random() % kBoxHeightMedium);
            x2 = (arc4random() % kBoxWidthMedium);
            y2 = (arc4random() % kBoxHeightMedium);
        }while(x1 == x2 && y1 == y2);
        Tile *a = [box objectAtX:x1 Y:y1];
        Tile *b = [box objectAtX:x2 Y:y2];
        NSLog(@"Tile a: x = %d,y = %d\nTile b: x = %d,y = %d\n",x1,y1,x2,y2);
        [self changeWithTileA:a TileB:b sel:@selector(check:data:)];
    }
    
	self.isTouchEnabled = YES;
    
    NSString *name = [NSString stringWithFormat:@"%d.png",value];
    
    CCSprite *solve = [CCSprite spriteWithFile: name];
    
	solve.position = ccp(384,674);
	[self addChild: solve z:0];
    
	CCMenuItemFont *back = [CCMenuItemFont itemFromString:@"back" target:self selector: @selector(back:)];
	CCMenu *menu = [CCMenu menuWithItems: back, nil];
    
    counter = 0;
    label = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"Moves %i",counter] fontName:@"Marker Felt" fontSize:40];    
    label.position = ccp(668, 974);
    [self addChild:label];
    
	menu.position = ccp(718, 50);
	[self addChild: menu];
    
    //Timer
    timeLabel = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%02d:%02d", mins, secs]fontName:@"Marker Felt" fontSize:40];
    timeLabel.position = ccp(100, 1024-50);
    [self schedule: @selector(tickCounter:) interval:1.0];
    [self addChild:timeLabel];
    //
    
    
    
	return self;
}
- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(box.lock == NO){
        UITouch* touch = [touches anyObject];
        CGPoint location = [touch locationInView: touch.view];
        location = [[CCDirector sharedDirector] convertToGL: location];
        
        if (location.y < (kStartY) || location.y > (kStartY + (kTileSizeMedium * kBoxHeightMedium))) {
            return;
        }
        
        int x = (location.x - kStartX) / (kTileSizeMedium);
        int y = (location.y - kStartY) / (kTileSizeMedium);
        
        if (selectedTile && selectedTile.x == x && selectedTile.y == y) {
            selectedTile = nil;
            return;
        }
        
        Tile *tile = [box objectAtX:x Y:y];
        if (tile.x >= 0 && tile.y >= 0) {
            if (selectedTile && [selectedTile nearTile:tile]) {
                //box.lock = YES;
                [self changeWithTileA: selectedTile TileB: tile sel: @selector(check:data:)];
                selectedTile = nil;
            }
            else {
                if (selectedTile) {
                    if (selectedTile.x == x && selectedTile.y == y) {
                        selectedTile = nil;
                    }
                }
                selectedTile = tile;
            }
        }
    }
}

-(void) changeWithTileA: (Tile *) a TileB: (Tile *) b sel : (SEL) sel{
	CCAction *actionA = [CCSequence actions:
						 [CCMoveTo actionWithDuration:kMoveTileTime position:[b pixPosition]],
						 [CCCallFuncND actionWithTarget:self selector:sel data: a],
						 nil
						 ];
    
	CCAction *actionB = [CCSequence actions:
						 [CCMoveTo actionWithDuration:kMoveTileTime position:[a pixPosition]],
						 [CCCallFuncND actionWithTarget:self selector:sel data: b],
						 nil
						 ];
	[a.sprite runAction:actionA];
	[b.sprite runAction:actionB];
    
	[a trade:b];
    
    [self addToCounter];
    [self updateLabel];
    
    NSLog(@"Check Solution");
	
	BOOL isSolved = [box checkSolution];
	
	CCLabelTTF *solvedLabel = (CCLabelTTF*)[self getChildByTag:kSolvedText];
	
	if (isSolved) {
		[solvedLabel setString:@"The Puzzle is Solved"];
        box.lock = YES;
        congrats = [CCLabelTTF labelWithString:@"Congratulations!" fontName:@"Marker Felt" fontSize:40];
        congrats.position = ccp(384, 1024-50);
        [self addChild:congrats];
	} else {
		[solvedLabel setString:@"The Puzzle is NOT Solved"];
	}
}

-(void) check: (id) sender data: (id) data{
    
}
-(void) back: (id) sender{
	[SceneManager goMenu];
}
-(void) tickCounter: (ccTime) dt {
    // using deltatime
    timeInt++;
    secs = timeInt % 60;
    mins = timeInt / 60;
    BOOL isSolved = [box checkSolution];
    if(isSolved){
        [self schedule: @selector(tickCounter:) interval:100000.0];
    }else{
        [timeLabel setString:[NSString stringWithFormat:@"%02d:%02d", mins, secs]];
        
    }
}
-(void) addToCounter{
    counter++;
}

-(void) updateLabel{
    [label setString:[NSString stringWithFormat:@"Moves %i",counter]];
}
@end