//
//  CreditsLayer.h
//  SlideIt
//
//  Created by Andreas Demetriou on 4/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "BaseLayer.h"
#import "SceneManager.h"

@interface CreditsLayer : BaseLayer {
    
}
-(void) back: (id) sender;
@end