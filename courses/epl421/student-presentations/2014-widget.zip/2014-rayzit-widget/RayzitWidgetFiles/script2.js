   prev = kappas(widthA,heightA,0,1);
    temph = heightA;