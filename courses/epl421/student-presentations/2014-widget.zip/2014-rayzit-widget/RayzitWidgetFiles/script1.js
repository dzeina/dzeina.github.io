 var qs = (function(a) {
    if (a == "") return {};
    var b = {};
    for (var i = 0; i < a.length; ++i)
    {
        var p=a[i].split('=');
        if (p.length != 2) continue;
        b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
    }
    return b;
    })(window.location.search.substr(1).split('&'));    
    var heightA=qs["height"]; 
    var widthA=qs["width"];
    var userID=qs["userID"];
    var requestA=qs["request"];
     
    var prevjson;
    var prev = 0;   
    var temph;
    var total=0;

    function kappas(ww,hh,prev,fresh){
    
      var json;
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
      if (requestA.localeCompare("livefeed")==0){
			  xmlHttp.open("GET", "http://dev.rayzit.com/user/"+userID+"/livefeed",false);
      }
      else if (requestA.localeCompare("latest")==0){
        xmlHttp.open("GET", "http://dev.rayzit.com/user/"+userID+"/latest",false);
      }
      else if (requestA.localeCompare("popular")==0){
        xmlHttp.open("GET", "http://dev.rayzit.com/user/"+userID+"/popular",false);
      }
      else
        return;
			xmlHttp.send(null);

      if (fresh==1){
        document.getElementById("maindiv").innerHTML="";
			  json = new String(xmlHttp.responseText);
			  json = json.replace(/\\r/g, "");
        prevjson = json;
      }
      else
        json = prevjson;

			var tsplit = json.split(",");
			var text;
			var time;
			var rerayz;
			var c = 0;
      var count = 0;

			for (var i = 0; i < tsplit.length; i++) {
				var str = new String(tsplit[i]);

				if (str.match(/rayz_message/g)) {
					var splitmsg = str.split(":");
					for (var j = 0; j < splitmsg.length; j++) {
						text = new String(splitmsg[j]);
						if (text.match(/rayz_message/g)) {
							text = splitmsg[j + 1];
							break;
						}
					}
					text = text.replace(/\"/g, "");
					c++;
				} else if (str.match(/timestamp/g)) {

					var thenum = str.replace(/^\D+/g, '');
					thenum = thenum.substring(0, 10);
					var a = new Date(thenum * 1000);
					var months = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
							'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
					var year = a.getFullYear();
					var month = months[a.getMonth()];
					var date = a.getDate();
					var hour = new String(a.getHours());
					var min = new String(a.getMinutes());
					var sec = new String(a.getSeconds());
					
					if (hour.length==1)
						hour = "0"+hour;

					if (min.length==1)
						min = "0"+min;

					if (sec.length==1)
						sec = "0"+sec;
					
					var time = date + ', ' + month + ' ' + year + ' ' + hour
							+ ':' + min + ':' + sec;
       
					c++;
				} else if (str.match(/rerayz/g)) {
					var splitrerayz = str.split(":");
					rerayz = new String(splitrerayz[1]);
					c++;
				}
				if (c == 3 && count<=hh/30) {
          if (count<prev){
            count++;
            c=0;
          }
          else {
            if (count<total){
              count++;
              continue;
            }
            var str = "";
            var a = document.createElement("PP");
            var b = document.createElement("B");
            var t1 = document.createTextNode("\"" + text + "\"\n");
            b.appendChild(t1);
            a.appendChild(b);
            document.getElementById("maindiv").appendChild(a);
            
            var c = document.createElement("H1");
            var t2 = document.createTextNode("Rayzed on: " + time +" Rerayzs:"+String.fromCharCode(160)+ rerayz);
            c.appendChild(t2);
            document.getElementById("maindiv").appendChild(c);
            
            var d = document.createElement("H2");
          
            for (var k=0; k<ww; k++)
              str+="________________________";
            
            var t3 = document.createTextNode(str);
            d.appendChild(t3);
            document.getElementById("maindiv").appendChild(d);

					  c = 0;
            count++;
            total++;
          }
				}
        if (count>hh/30){
          return count;
        }
			}
		}
    
    function load(){
      temph = Math.floor(parseFloat(temph)+heightA);
      prev = kappas(widthA,temph,prev,0);
    }  
    
    function test(){
      total=0;
      prev = kappas(widthA,heightA,0,1);
      temph = heightA;
      $("div").scrollTop(0);      
    }    