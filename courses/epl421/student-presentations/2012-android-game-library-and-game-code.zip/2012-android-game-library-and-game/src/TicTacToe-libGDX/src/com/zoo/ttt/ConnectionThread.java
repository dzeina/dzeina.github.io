package com.zoo.ttt;

import java.net.ServerSocket;
import java.net.Socket;

public class ConnectionThread extends Thread {
    private Socket socket;
    private boolean successStatus = false;
    private Object lock = new Object();
    private boolean readyStatus = false;

    public boolean success() {
	synchronized (lock) {
	    return successStatus;
	}
    }

    public boolean statusReady() {
	synchronized (lock) {
	    return readyStatus;
	}
    }

    public ConnectionThread() {
    }

    public Socket getSocket() {
	return socket;
    }

    @Override
    public void run() {
	boolean ss;
	try {
	    ServerSocket sss = new ServerSocket(30000);
	    socket = sss.accept();
	    ss = true;
	} catch (Exception e) {
	    ss = false;
	}

	synchronized (lock) {
	    successStatus = ss;
	    readyStatus = true;
	}
    }
}
