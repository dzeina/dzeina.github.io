package com.zoo.ttt;

import java.io.Serializable;

public class GameData implements Serializable {

    private static final long serialVersionUID = 1L;

    char[] game;

    public static final char X = 'X';
    public static final char O = 'O';
    public static final char None = ' ';
    public static final char Draw = 'D';

    public GameData() {
	game = new char[] { None, None, None, None, None, None, None, None,
		None };
    }

    char get(int x, int y) {
	return game[y * 3 + x];
    }

    void putX(int x, int y) {
	game[y * 3 + x] = X;
    }

    void putO(int x, int y) {
	game[y * 3 + x] = O;
    }

    void clear(int x, int y) {
	game[y * 3 + x] = None;
    }

    void clearAll() {
	for (int i = 0; i < 9; ++i) {
	    game[i] = None;
	}
    }

    String getAsStr(int x, int y) {
	char c = game[y * 3 + x];
	return c == X ? "X" : c == O ? "O" : c == None ? "" : "Draw";
    }

    char checkWinner() {
	int countH = 0;
	int countV = 0;
	int countD1 = 0;
	int countD2 = 0;
	int count = 0;
	for (int x = 0; x < 3; ++x) {
	    for (int y = 0; y < 3; ++y) {
		countH += game[y * 3 + x];
		countV += game[x * 3 + y];
		if (game[y * 3 + x] != ' ') {
		    ++count;
		}
	    }
	    if (countH == 3 * X || countV == 3 * X) {
		return X;
	    } else if (countH == 3 * O || countV == 3 * O) {
		return O;
	    }
	    countD1 += game[x * 3 + x];
	    countD2 += game[x * 3 + 2 - x];
	    countH = 0;
	    countV = 0;
	}

	if (countD1 == 3 * X || countD2 == 3 * X) {
	    return X;
	} else if (countD1 == 3 * O || countD2 == 3 * O) {
	    return O;
	} else if (count == 9) {
	    return Draw;
	}
	return None;
    }

    boolean isFull() {
	for (int i = 0; i < 9; ++i) {
	    if (game[i] == None) {
		return false;
	    }
	}
	return true;
    }
}
