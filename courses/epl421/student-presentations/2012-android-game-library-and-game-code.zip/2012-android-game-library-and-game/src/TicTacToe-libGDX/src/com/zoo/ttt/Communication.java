package com.zoo.ttt;

import java.io.ObjectInputStream;
import java.net.Socket;

public class Communication extends Thread {

    Object mutex;
    Socket s;
    public GameData game = new GameData();
    boolean ready;
    boolean error;

    public Communication(Socket s, Object mutex) {
	this.mutex = mutex;
	this.s = s;
    }

    boolean getError() {
	synchronized (mutex) {
	    return error;
	}
    }
    
    public void finish() {
	mustFinish = true;
    }
    
    boolean mustFinish = false;

    @Override
    public void run() {
	while (true) {
	    if (mustFinish != false) {
		break;
	    }
	    try {
		GameData game = (GameData) new ObjectInputStream(
			s.getInputStream()).readObject();
		synchronized (mutex) {
		    this.game = game;
		    ready = true;
		}
	    } catch (Exception e) {
		synchronized (mutex) {
		    this.game = null;
		    ready = false;
		    error = true;
		}
	    }
	    if (mustFinish != false) {
		break;
	    }
	}
    }
}
