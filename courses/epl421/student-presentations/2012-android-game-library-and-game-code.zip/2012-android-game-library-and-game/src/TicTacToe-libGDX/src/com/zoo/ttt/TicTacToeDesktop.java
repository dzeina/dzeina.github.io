package com.zoo.ttt;

import com.badlogic.gdx.backends.jogl.JoglApplication;

public class TicTacToeDesktop {
	public static void main (String[] argv) {
		new JoglApplication(new TicTacToe(), "TicTacToe", 480, 320, false);
	}
}
