package com.zoo.ttt;

import com.badlogic.gdx.Input;

public class Keyboard implements Input.TextInputListener {

    private String message = null;
    private boolean cancelled = false;
    private boolean status = true;
    private boolean ready = false;
    
    public boolean messageReady() {
	return ready;
    }

    public Keyboard() {
    }

    @Override
    public void canceled() {
	cancelled = true;
    }

    public boolean enabled() {
	return status;
    }

    public void disable() {
	status = false;
    }

    boolean wasCancelled() {
	return cancelled;
    }

    @Override
    public void input(String msg) {
	if (msg != "") {
	    message = msg;
	}
	else {
	    message = null;
	}
	ready = true;
    }

    public String getMessage() {
	return message;
    }

    public void reset() {
	message = null;
	cancelled = false;
	ready = false;
	status = true;
    }

}
