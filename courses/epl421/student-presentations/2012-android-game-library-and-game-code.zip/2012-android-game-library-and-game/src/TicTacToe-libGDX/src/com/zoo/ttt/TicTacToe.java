package com.zoo.ttt;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.BitmapFont.TextBounds;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class TicTacToe implements ApplicationListener {

    SpriteBatch batch;
    Texture square;
    char player;
    int width;
    int height;
    float border;
    BitmapFont font;
    GameData game;
    int centerX;
    int centerY;
    boolean ready;
    Socket socket;
    private float xPos;
    private float sqSize;
    private float yPos;
    Object lock;
    boolean isServer;
    Communication com;
    String endMessage;
    String serverName;
    ServerSocket serverSocket;
    Keyboard textMessage;

    enum State {
	Lobby, InitServer, InitClient, Game, End, InitServer2, RequestServerIP, InitServer3
    };

    State gameState = State.Lobby;

    @Override
    public void create() {
	game = new GameData();
	batch = new SpriteBatch();
	square = new Texture(Gdx.files.internal("data/square.png"));
	font = new BitmapFont();
	font.setColor(Color.RED);
	lock = new Object();
	textMessage = new Keyboard();
    }

    @Override
    public void render() {
	Gdx.graphics.getGL10().glClear(GL10.GL_COLOR_BUFFER_BIT);
	Gdx.graphics.getGL10().glClearColor(0, 0, 0, 0);
	switch (gameState) {
	case End:
	    endGame();
	    break;
	case Lobby:
	    lobby();
	    break;
	case InitServer:
	    initServer();
	    break;
	case InitServer2:
	    initServer2();
	    break;
	case InitServer3:
	    initServer3();
	    break;
	case InitClient:
	    initClient();
	    break;
	case Game:
	    inGame();
	    break;
	case RequestServerIP:
	    requestServerIP();
	    break;
	}
    }

    void lobby() {
	font.setScale(1);
	batch.begin();
	{
	    batch.draw(square, centerX - sqSize - 2, centerY - sqSize / 2,
		    sqSize, sqSize);
	    String s;
	    TextBounds bounds;
	    s = "Server";
	    bounds = font.getBounds(s);
	    font.draw(batch, s, centerX - sqSize - 2 + sqSize / 2
		    - bounds.width / 2, centerY - sqSize / 2 + sqSize / 2
		    + bounds.height / 2);
	    batch.draw(square, centerX + 2, centerY - sqSize / 2, sqSize,
		    sqSize);
	    s = "Client";
	    bounds = font.getBounds(s);
	    font.draw(batch, s, centerX + 2 + sqSize / 2 - bounds.width / 2,
		    centerY - sqSize / 2 + sqSize / 2 + bounds.height / 2);
	}
	batch.end();

	if (Gdx.input.isTouched()) {
	    if (Gdx.input.getX() < centerX) {
		isServer = true;
		gameState = State.InitServer;
	    } else {
		isServer = false;
		gameState = State.RequestServerIP;
	    }

	    ready = isServer;
	    player = isServer ? 'X' : 'O';
	}
    }

    void requestServerIP() {
	if (textMessage.enabled()) {
	    Gdx.input.getTextInput(textMessage, "Enter server IP", "");
	    textMessage.disable();
	} else if (textMessage.wasCancelled() || textMessage.messageReady()
		&& textMessage.getMessage() == null) {
	    textMessage.reset();
	    gameState = State.Lobby;
	} else if (textMessage.messageReady()) {
	    serverName = textMessage.getMessage();
	    textMessage.reset();
	    gameState = State.InitClient;
	    batch.begin();
	    {
		font.setScale(2);
		String stringy = "Connecting to server...";
		TextBounds bounds = font.getBounds(stringy);
		font.draw(batch, stringy, centerX - bounds.width / 2, centerY
			+ bounds.height / 2);
	    }
	    batch.end();
	}
    }

    void initClient() {
	try {
	    socket = new Socket(serverName, 30000);
	    com = new Communication(socket, lock);
	    com.start();
	    gameState = State.Game;

	} catch (Exception e) {
	    finish("Could not connect to the server!");
	}

    }

    void initServer() {
	batch.begin();
	{
	    gameState = State.InitServer2;
	    font.setScale(1);
	    String s = "Waiting for players...";
	    TextBounds bounds = font.getBounds(s);
	    font.draw(batch, s, centerX - bounds.width / 2, centerY);
	    try {
		// s =
		// InetAddress.getAllByName(host)//InetAddress.getLocalHost().getHostAddress();
		// s = InetAddress.getgetHostAddress();
		s = getIP();
	    } catch (Exception e) {
		s = "(Could not resolve address)";
	    }
	    bounds = font.getBounds(s);
	    font.draw(batch, s, centerX - bounds.width / 2,
		    centerY + font.getLineHeight());

	}
	batch.end();
    }

    ConnectionThread c;

    void initServer2() {
	c = new ConnectionThread();
	c.run();

	gameState = TicTacToe.State.InitServer3;
    }
    void initServer3() {
	if (c.statusReady()) {
	    if (c.success()) {
		com = new Communication(socket = c.getSocket(), lock);
		com.start();
		gameState = State.Game;
	    } else {
		finish("Could not start connection.");
	    }
	}
    }

    void inGame() {
	font.setScale(3);
	centerX = Gdx.graphics.getWidth() / 2;
	centerY = Gdx.graphics.getHeight() / 2;
	if (ready) {
	    if (Gdx.input.isTouched()) {
		int indexX = indexH(Gdx.input.getX());
		int indexY = indexV(Gdx.graphics.getHeight() - Gdx.input.getY());
		if (indexX != -1 && indexY != -1
			&& game.get(indexX, indexY) == GameData.None) {
		    if (player == 'X') {
			game.putX(indexX, indexY);
		    } else {
			game.putO(indexX, indexY);
		    }
		    try {
			new UpdateThread(socket, game, lock, new pleaseFinish(
				this)).start();
		    } catch (Exception e) {
			finish("Connection error.");
		    }
		    ready = false;
		}
	    }
	} else {
	    try {
		synchronized (lock) {
		    if (com.ready) {
			game = com.game;
			ready = true;
			com.ready = false;
		    }
		}
	    } catch (Exception e) {
	    }
	}

	batch.begin();
	{
	    for (int x = 0; x < 3; ++x) {
		for (int y = 0; y < 3; ++y) {
		    batch.draw(square, xPos + x * (sqSize + 2), yPos + y
			    * (sqSize + 2), sqSize, sqSize);
		    String s = game.getAsStr(x, y);
		    TextBounds bounds = font.getBounds(s);
		    font.draw(batch, s, xPos + x * (sqSize + 2) + (sqSize + 2)
			    / 2 - bounds.width / 2, yPos + y * (sqSize + 2)
			    + bounds.height / 2 + (sqSize + 2) / 2);
		}
	    }
	}
	batch.end();

	char result = game.checkWinner();
	if (result == player) {
	    finish("You win!");
	} else if (result == GameData.Draw) {
	    finish("Nobody wins!");
	} else if (result != GameData.None) {
	    finish("You lose!");
	}
    }

    void endGame() {
	batch.begin();
	{
	    font.setScale(2);
	    TextBounds bounds = font.getBounds(endMessage);
	    font.draw(batch, endMessage, centerX - bounds.width / 2, centerY
		    + bounds.height / 2);
	}
	batch.end();
    }

    int indexH(float posX) {
	int index = (int) Math
		.floor(((posX - (centerX - border / 2)) / border) * 3);
	return index < 0 || index > 2 ? -1 : index;
    }

    int indexV(float posY) {
	int index = (int) Math
		.floor(((posY - (centerY - border / 2)) / border) * 3);
	return index < 0 || index > 2 ? -1 : index;
    }

    @Override
    public void resize(int width, int height) {
	batch.getProjectionMatrix().setToOrtho2D(0, 0, this.width = width,
		this.height = height);
	border = Math.min(width, height);
	sqSize = border / 3 - 2;
	centerX = width / 2;
	centerY = height / 2;
	xPos = centerX - border / 2;
	yPos = centerY - border / 2;
    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {
	if (com != null) {
	    com.finish();
	    com.interrupt();
	}
	if (c != null) {
	    c.interrupt();
	}
	if (socket != null) {
	    try {
		socket.close();
	    } catch (IOException e) {
	    }
	}
    }

    @Override
    public void pause() {
    }

    static private String getIP() {

	if (AndroidBridge.android) {
	    return AndroidBridge.hostname;
	}
	InetAddress addrs[];

	try {
	    addrs = InetAddress.getAllByName(InetAddress.getLocalHost()
		    .getHostName());
	} catch (UnknownHostException e) {
	    addrs = new InetAddress[] {};
	    Gdx.app.debug("info", "error");
	}
	String myIp = "UNKNOWN";
	Gdx.app.debug("info", "what");
	for (InetAddress addr : addrs) {
	    Gdx.app.debug("info",
		    "addr.getHostAddress() = " + addr.getHostAddress());
	    Gdx.app.debug("info", "addr.getHostName() = " + addr.getHostName());
	    Gdx.app.debug("info",
		    "addr.isAnyLocalAddress() = " + addr.isAnyLocalAddress());
	    if (!addr.isLoopbackAddress() && addr.isSiteLocalAddress()) {
		myIp = addr.getHostAddress();
	    }
	}
	return myIp;
    }

    void finish(String message) {
	endMessage = message;
	gameState = State.End;
    }

    class pleaseFinish implements Runnable {
	private TicTacToe owner;

	public pleaseFinish(TicTacToe owner) {
	    this.owner = owner;
	}

	@Override
	public void run() {
	    owner.finish("Connection error.");
	}
    }
}
