package com.zoo.ttt;

public class AndroidBridge {
    public static String hostname;
    public static boolean android;
}
