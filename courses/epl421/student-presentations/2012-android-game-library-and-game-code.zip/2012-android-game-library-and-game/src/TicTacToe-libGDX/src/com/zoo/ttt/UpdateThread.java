package com.zoo.ttt;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

class UpdateThread extends Thread {

    Object lock;
    Socket socket;
    GameData game;
    Runnable error;

    public UpdateThread(Socket socket, GameData game, Object lock, Runnable errorCallback) {
	this.socket = socket;
	this.game = game;
	this.lock = lock;
	error = errorCallback;
    }

    @Override
    public void run() {
	try {
	    synchronized (lock) {
		new ObjectOutputStream(socket.getOutputStream())
			.writeObject(game);
	    }
	} catch (IOException e) {
	    error.run();
	}
    }
};