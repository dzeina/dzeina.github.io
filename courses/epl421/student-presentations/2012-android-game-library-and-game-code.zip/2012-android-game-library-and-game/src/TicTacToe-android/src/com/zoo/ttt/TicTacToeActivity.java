package com.zoo.ttt;

import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;

import com.badlogic.gdx.backends.android.AndroidApplication;

public class TicTacToeActivity extends AndroidApplication {
    @Override
    public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);

	WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
	WifiInfo wifiInfo = wifiManager.getConnectionInfo();
	int ip = wifiInfo.getIpAddress();
	String ipString = String.format("%d.%d.%d.%d", (ip & 0xff),
		(ip >> 8 & 0xff), (ip >> 16 & 0xff), (ip >> 24 & 0xff));
	AndroidBridge.hostname = ipString;
	AndroidBridge.android = true;
	initialize(new TicTacToe(), false);
    }
}