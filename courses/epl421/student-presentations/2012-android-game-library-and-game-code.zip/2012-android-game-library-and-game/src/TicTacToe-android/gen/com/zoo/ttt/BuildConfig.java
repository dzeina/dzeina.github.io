/** Automatically generated file. DO NOT MODIFY */
package com.zoo.ttt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}