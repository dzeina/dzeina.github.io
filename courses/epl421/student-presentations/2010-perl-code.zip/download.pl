#!/usr/bin/perl
use IO::Socket;
use File::Copy;

## BEGIN
$lexValue = 0;
$SIG{INT} = "force"; 

checkArgs();
$gbValue = checkGroupBy(); 
$lexValue = checkLexicon();
$spValue = checkSpellcheck();

executeConnection();
readEmails($messages);
removeSpecial();

#GROUP BY
if ( $gbValue != 0 ){
	groupby($gbValue);
	print "Done Grouping!\n";
}

#Lexicon
if ($lexValue ne 0 ){
	lexicon();
	print "Done Lexicon!\n";
}

#spellcheck
if ($spValue ne 0){
	spellcheck();
	print "Done Spell Check!\n";
}

## END

sub checkArgs{
	
	if (($#ARGV > 5) || ($#ARGV < 1 )) {
		print "download: usage: download [options] popserver username\n";
		exit;
	}
}

sub executeConnection{
		
	$preLastArg = $ARGV[$#ARGV - 1];
	$popserver = $preLastArg; 

	$lastArg = $ARGV[$#ARGV];
	$username = $lastArg;  
	
	$sock = new IO::Socket::INET (
                                  PeerAddr => $popserver,
                                  PeerPort => '110',
                                  Proto => 'tcp',
                                  Type => SOCK_STREAM
                                 );
	die "Error!" unless $sock;	
	
	$line = <$sock>;
		
	print $sock "USER $username\n";
	$line = <$sock>;
	
	# hide stdin for entering password
	print "Please enter your password: ";
	system("stty","-echo");
	$password = <STDIN>;
	system("stty","echo");
	
	print $sock "PASS $password\n";
	
	$line = <$sock>;

	# check for wrong password
	my @response = split(/ /,$line);
	
	if ( $response[0] eq "-ERR" ){
		print "Wrong Password!\n";
		exit;
	}
	
	print "\nConnection Established!\n";

	print $sock "STAT\n";
	$line = <$sock>;
	
	@noMsgs = split(' ', $line);
	
	$messages = $noMsgs[1];
	print "No of messages $messages\n";
}

sub readEmails{

$userName =  $ENV{'LOGNAME'}; 
mkdir "/tmp/$userName", 0777 unless -d "/tmp/$userName";
open (EMAILS, ">>/tmp/$userName/emails") or die $!;

	$i = 1;
	$readE = 0;

	while  ($i <= $_[0]){
		open (FILE, ">>/tmp/$userName/$i");
		$midFound = 0;
		$removed = 0;
		print "Downloading email $i ";
	
		print $sock "RETR $i\n";
		$line = <$sock>;
		$line = <$sock>;
		
		$res = $line;
		$res =~ s/\r//g;	
		chomp $res;	
		
		while ($res ne "."){
			if ($midFound == 0){
				if ($line =~ m/^Message-ID:/) {
					 @msgID = split / /, $res;
					 $msgID[1] =~ s/\<//;
					 $msgID[1] =~ s/\>//;
					 $MessageID = $msgID[1];
					
					 print EMAILS "$MessageID\n";					
					
					$midFound=1;
					if ( -e "/tmp/$userName/$MessageID") {$removed=1;}
				}
			}
			
			#CHECK FOR PLAIN-TEXT
			$temp = $res;
			if ($temp =~ m/^Content-Type:/){
				@type = split(/ /,$res);
				if ($type[1] ne "text/plain;") {$removed = 1;}
			}
			
			if ($removed == 1){
				unlink("/tmp/$userName/$i");
				$i++;
				last;			
			}
			else{	
				print FILE "$res\n";
				$line = <$sock>;		
				$line =~ s/\r//g;	
				$res = $line;
				chomp $res;	
			}
			
		} # end while
		
		if ($removed == 1){
			print "Already Exists\n";
			
			#flush what's left in the socket
			$line = <$sock>;		
			$line =~ s/\r//g;	
			$res = $line;
			chomp $res;
				
			while ($res ne "."){
				$line = <$sock>;		
				$line =~ s/\r//g;	
				$res = $line;
				chomp $res;
			}		
			next;
		}
		
		print "OK\n";
		
		move( "/tmp/$userName/$i", "/tmp/$userName/$MessageID");
		
		$readE++;		
		$i++;
		close(FILE);
	} # end main while
		
	close(EMAILS);
	print "Downloaded $readE of $_[0] email(s) - DONE\n"
}

sub removeSpecial{
	
	$directory = "/tmp/$userName/";
	opendir(DIR, $directory);
	@files = readdir(DIR);
	closedir(DIR);

	foreach $file (@files) {
		
		if  (( -d $directory.$file ) || (! -f $directory.$file) || ( $file eq "emails" ) || ( $file eq "lexicon" ) || ( $file eq "lexicon.txt"))
			{next;}
			
		#synchronize email in folder with inbox
		if  ( -e $directory."emails" ){
			open (EMAILS, $directory."emails") or die $!;
			@lines = <EMAILS>;
			
			#check if file exists in folder
			$exists = 0;
			foreach $l (@lines){
				chomp $l;
				if($l eq $file){
					$exists = 1;
					last;
				}
			}
			
			if($exists == 0){
				 unlink($directory.$file);
 			    next;
			}	 
		}
		
		open(FILE, $directory.$file);
		@temp = <FILE>;
		close FILE;
		
		open(OUT, ">$directory"."$file");
		foreach $tline (@temp){
			if (($tline =~ m/^>/) || ($tline =~ m/^(\*\*)+(\*\*)$/)) {next;}				
			print OUT "$tline";
		}
			
		close(OUT);	
	}
	
	if  ( -e $directory."emails" ){
		unlink($directory."emails");
	}
}

sub groupby {
 $userName =  $ENV{'LOGNAME'}; 
	if ($_[0] eq 1) {
		
			mkdir "/tmp/$userName/from", 0777 unless -d "/tmp/$userName/from";
			$dir = "/tmp/$userName/";
			opendir (DIR, $dir);
			@files = readdir(DIR);
			closedir(DIR);
			
			
	 		foreach $file (@files) {
	 			$fullpath = $dir . $file ;
	 			
	 		
	   		next if ($fullpath eq "/tmp/$userName/lexicon"); 
	 			next if ($fullpath eq "/tmp/$userName/lexicon.txt");
	 			next if (-d $fullpath);
	 			
	 			
	 		  	open (FILE,$fullpath);
	 		
	 			@from = <FILE>;
	 				
	 			@pipe = grep(/From/, @from);
	 			@email = split(' ', $pipe[1]);
	 			@email_split = split('@', $email[1]);
	 			$username_from = $email_split[0];
	 		
	 			
	 			$username_from =~ s/<//;
	 			#print $username_from;
	 			
		
				mkdir "/tmp/$userName/from/$username_from" , 0777 unless -d "/tmp/$userName/from/$username_from/";
				copy($fullpath, "/tmp/$userName/from/$username_from/$file") or die "Copy failed: $!";
				
			 }
	}
	elsif ($_[0] eq 2){
			mkdir "/tmp/$userName/to", 0777 unless -d "/tmp/$userName/to";
			$dir = "/tmp/$userName/";
			opendir (DIR, "/tmp/$userName/");
			@files = readdir(DIR);
			closedir(DIR);
			
			
	 		foreach $file (@files) {
		 			$fullpath = $dir.$file;
		 		
					next if ($fullpath eq "/tmp/$userName/lexicon"); 
		 			next if ($fullpath eq "/tmp/$userName/lexicon.txt");
		 			next if (-d $fullpath);	 			
		 			
		 		  	open (FILE,$fullpath);
		 		
		 			@to = <FILE>;
		 			close FILE;
		 			my @email_list = ();
	 				
	 				$i = 0;
	 				$Flag = 0;
	 				foreach $line (@to){
		 				@check_down = split(/ /, $line);		 				
		 						 				
		 				if ($Flag == 0) {
	 						if ($check_down[0] ne "From:"){
	 							next;
	 						}
	 						else {
	 							$Flag = 1;
	 							next;
	 						}	
	 					}						
		 				last if $check_down[0] eq "Subject:";
		 				
		 				$email_list[$i] = $line;
		 				$i = $i + 1;
	 				}
	 				
	 				
	 				$i = 0;
	 				undef @email_full;
	 				foreach $line (@email_list){
	 				
	 						@email_line = split(', ', $email_list[$i]);
	 					
	 						foreach $em (@email_line){
	 							chomp($em);
		 						$em =~ s/To://;
		 						$em =~ s/\s//;
		 						$em =~ s/\>//;
		 						$em =~ s/\t//;
	 			
	 							$email_full[$i] = $em;
	 							$i = $i + 1;	 						
	 						}
	 				}
	 				
	 				undef @usrname;
	 				@usrname = ();
	 				$i = 0;
	 				foreach $usr (@email_full){
	 					@email_sep = split('@', $usr);
	 					$usrname[$i] = $email_sep[0];
	 					$i = $i + 1;
	 				}
	 				 
	 				foreach $usr (@usrname){
	 					mkdir "/tmp/$userName/to/$usr" , 0777 unless -d "/tmp/$userName/to/$usr";
	 					if ($usr ne ""){
	 					
						copy($fullpath, "/tmp/$userName/to/$usr/$file") or die "Copy failed: $!";}

	 				}
			 }	
		}
}


sub lexicon {

	$directory = "/tmp/$userName/";
	opendir(DIR, $directory);
	@files = readdir(DIR);
	closedir(DIR);
	
	open TEMP, ">>$directory"."temp";

	foreach $file (@files) {	
	
		if  (( -d $directory.$file ) || (! -f $directory.$file) || ( $file eq "lexicon" )) {next;}
		
		open FILE, $directory.$file;
		@lines = <FILE>;
		close FILE;		
		
		$v = 0;
		foreach $tline (@lines){
			chomp $tline;
			if ($v == 0){
				if ($tline =~ /^$/) {$v = 1;} #sed '1,/^$/d'
			}
			else{
				$tline2 = $tline;
				if ($tline2 =~ /^$/) {next;} #sed '/^$/d'
				@words = split (/ /, $tline);
				foreach $w (@words){
					$w2 = $w;
					if ($w2 =~ /[^[:alpha:]]/) {next;}
					$w =~ tr/A-Z/a-z/;
					print TEMP $w,"\n";
				}
			}
		}
	}
	close TEMP;
	
	open FILE, ">$directory"."lexicon.txt";
	open TEMP, $directory."temp";
	@lines = <TEMP>;
	close TEMP;	
	
	#remove newlines from array @lines and from its words
	@in = grep(!/^\s*$/, @lines);
	
	for(@in) {chomp $_;}
	
	#count unique words in array
	my %count;
	map { $count{$_}++ } @in;

	#print them to file
	map {print FILE "$_ ${count{$_}}\n"} sort keys(%count);	
	
	close TEMP;
	close FILE;
	unlink ($directory."temp"); #rm /tmp/$USER/temp
	createSchedule();
}

#print lexicon function into a script file
sub createSchedule{

	$directory = "/tmp/$userName/";
	open FILE, ">$directory"."lexicon"; 
	print FILE "#!/usr/bin/perl -w\n\$userName =  \$ENV{'LOGNAME'};"; # add some needed lines to file
	
	open DOWNLD, "download.pl";
	my @lines = <DOWNLD>; #cat download.pl
	close DOWNLD;
	
	my $found = 0;
	
	foreach $l (@lines){
		$t = $l;
		if ($t =~ /sub lexicon {/) {$found = 1; next;} # set the starting point for printing
		$t = $l;
		if ($t =~ /createSchedule\(\);/) {last;} # end printing
		
		if ($found == 1){
			$t = $l;
			if ($t =~ /lexicon.txt/) {
				print FILE "\$date = `date +\%d-\%m-\%y_\%H:\%M`;\nchomp \$date;\n"; #change the line: 'open FILE, ">$directory"."lexicon.txt";'
				$date = "lexicon_\".\$date.\".txt";				
				$l =~ s/lexicon.txt/$date/;
			}
			print FILE $l; #print the line to file
		}
	}
	
	chmod 0777, $directory."lexicon"; #chmod +rwx /tmp/$USER/lexicon
	open CRON, ">>".$directory."mycron"; 
	
	#echo new cron into cron file
	print CRON "00 15 * * * $directory"."lexicon\n";
	print CRON "00 20 * * * $directory"."lexicon\n";
	
	#install new cron file
	system("crontab" ,$directory."mycron");
	unlink($directory."mycron"); #rm /tmp/$USER/mycron	
	close CRON;
	close FILE;
}

sub spellcheck {
	$userName =  $ENV{'LOGNAME'}; 
	$dir = "/tmp/$userName/";
	opendir (DIR, $dir);
	@files = readdir(DIR);
	closedir(DIR);	
			
	 	foreach $file (@files) {
 				open (HEADER, ">>/tmp/$userName/temp");
				open (BODY, ">>/tmp/$userName/temp_file");	
		 	
	 			$fullpath = $dir.$file ;
	 			
				next if ($fullpath eq "/tmp/$userName/lexicon"); 
	 			next if ($fullpath eq "/tmp/$userName/lexicon.txt");
	 			next if (-d $fullpath);
	 		
	 				
				open (FILE,$fullpath);
	 		
	 			@fullFile = <FILE>;				
 				
 				$j = 0;
 				$k = 0;
 				$subjectFlag = 0;
 				foreach $line (@fullFile){
	 				@check = split(' ', $line);
	 				
	 				if ($subjectFlag == 0) {
	 					if ($check[0] ne "X-EsetId:"){
	 						$header[$j] = $line;
	 						$j = $j + 1;
	 						next;
	 					}
	 					else {
	 						$header[$j + 1] = $line;
	 						$subjectFlag = 1;
	 						next;
	 					}	
	 				}
	 				 				
	 				$body[$k]  = $line; 
	 				$k = $k + 1;
 				}
 				
 				
 				foreach $line (@header){
 					print HEADER $line;
 				}
				
				foreach $line (@body){
 					print BODY $line;
 				}		
 				
 				system("aspell check /tmp/$userName/temp_file");
 				close BODY;
 				
 				open (BODY, "/tmp/$userName/temp_file");	
 				@temp_file = <BODY>;
 				foreach $line (@temp_file){	 				
 					print HEADER $line; 				
 				}
 				
 				move ("/tmp/$userName/temp", $fullpath);
	 				
	 		close(HEADER);
	 		close(BODY);			
	 	}
	 	
	 	unlink ("/tmp/$userName/temp");
	 	unlink ("/tmp/$userName/temp_file");
}

sub checkGroupBy {

	foreach $arg (0 .. $#ARGV) {
		if ($ARGV[$arg] eq "groupby"){
			if ($arg eq $#ARGV) { 
				print "Wrong Parameters!";
				exit;
			} 
			
			$next = $ARGV[$arg + 1];
					
			if ($next eq "From" || $next eq "from"){
			 	return 1;
			}
			elsif ($next eq "To" || $next eq "to"){
				return 2;
			}
			else {
				print "download: usage: download [options] popserver username";
				exit;
			}
			
			return 0;	
		}
	
	}
}

sub checkLexicon {

	foreach $arg (0 .. $#ARGV) {
		
		if ($ARGV[$arg] eq "lexicon"){
			return 1;
		}
	}
	return 0;
}		

sub checkSpellcheck {

	foreach $arg (0 .. $#ARGV) {
		
		if ($ARGV[$arg] eq "spellcheck"){
			return 1;
		}
	}
	return 0;
}	

sub quit {
	print $sock "QUIT\n";
	$line = <$sock>;
	close($sock);
}

sub force {
	$userName =  $ENV{'LOGNAME'}; 	
	
	if ($lexValue eq 1){
		if (-f "/tmp/$userName/temp") {
			unlink ("/tmp/$userName/temp") ;
		}		
		lexicon();
	}
	
	if (-f "/tmp/$userName/emails" ) {
			unlink ("/tmp/$userName/emails" ) ;
		}
		
	quit();
	system("stty echo");	
	exit;
}

