#!/usr/bin/perl -w
use IO::Socket::INET;

unless ($#ARGV = 3) {die "Usage\: upload emaildir smtpsever username: $!\n";}

#Open directory and read filenames
$directory = $ARGV[0]; 
opendir(DIR, $directory);
@files = readdir(DIR);
closedir(DIR);

#Store SMTP Server and username
$smtpserver = $ARGV[1];
$username = $ARGV[2];

executeConnection($smtpserver, $username);
sendFiles();
closeConnection();

sub executeConnection {
	#create new socket
	$socket = new IO::Socket::INET (PeerAddr => $_[0], #maybe change it to $smtpserver?
											  PeerPort => 26,
											  Proto => "tcp",
											  Type => SOCK_STREAM)
		or die "Couldn't connect to $_[0] : $!\n";

	$line = <$socket>;

	print $socket "HELO $_[1]\n"; #maybe change it to $username?
	$line = <$socket>;
}

sub sendFiles {

	foreach $file (@files) {

		if (($file eq ".") || ($file eq "..")) {next;}	#ignore current directory (.) and parent (..)
	
		print "Sending file $file ";
	
		print $socket "MAIL FROM: ", $username ,"\@runbox.com\n";
		$line = <$socket>;
	
		print $socket "RCPT TO: ", $username ,"\@runbox.com\n";
		$line = <$socket>;
	
		print $socket "DATA\n";
		
		open(INFO, $directory.$file) or die "Could not open $file: $!"; # concatenate directory to file and Open it
		@lines = <INFO>;		# Read it into an array
		close(INFO);			# Close the file
	
		print $socket @lines;
	
		print $socket "\n.\n";
		$line = <$socket>;
		$line = <$socket>;
	
		print "OK\n";
	}

	print @files -2, " files sent successfully!\n"; #exclude . and .. files

}

sub closeConnection{

	print $socket "QUIT\n";
	$line = <$socket>;

	#Close Socket
	close($socket);

}
