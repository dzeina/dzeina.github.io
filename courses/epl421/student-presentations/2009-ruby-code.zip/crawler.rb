#!/usr/bin/env ruby
require 'socket'  		#library declaration

#function that establishes the connection with a webpage
def openCon(page)
  if %r{([^/]+)/(.*)}i =~ page 			#splitting the page to domain and path
    $domain,path = $1, $2
  end
  begin
    t = TCPSocket.new($domain, 80) 		#creating a connection to socket 80 with the address of the domain
  rescue 
    puts "error: #{$!}" 
  else 
    t.print "GET /"+path+" HTTP/1.0\n\n" 		#gets the text from the path
    answer = t.gets(nil) 					
    t.close 
  end   
  answer.gsub!("<","\n<")
  answer.gsub!("><", ">\n<")
  old = File.open("links.dat.tmp", File::WRONLY|File::TRUNC|File::CREAT) 
  old.print answer
  old.close
  findUrls("links.dat.tmp", page)
end

#function to find the urls in the text of the url that is in the file
def findUrls(fileName, page)
  read = File.open(fileName) 
  if %r{http/1.1 200 ok}i =~ read.gets 			#checks if the page was opened correct
    #finds the urls which are in the text and does the appropriate format     
    while read.gets do 						
      if %r{a\s+href=\"([^\/]+\/)(\/*)(.*[^\.html]\.html)\"[^>]*>}i =~ $_  ||%r{<a\s+href=\"([^\/]+\/)(\/*)(.*\.txt)\"[^>]*>}i =~ $_ 
        cuturl=$3
        
        
        if  %r{(^www\..*)}i =~ cuturl
          url=$1
          
        else
          url=$domain+"/"+ cuturl
          
        end
        flag = findInArrayUrl($arrayWeb, url)			
        if flag ==1							#if the url isn't in the array to be opened it is inserted in the array 
          $arrayWeb=$arrayWeb+[url];
        end
      end 
    end
  else 
    flagB = findInArrayUrl($arrayWebBroken, page)			
    
    if flagB==1
      $arrayWebBroken =$arrayWebBroken +[page]		#if the page was't opened correct puts it in the broken urls
    end
  end
  return $arrayWeb.length
end

#function to check if the urls exist in the array with which it is called
def findInArrayUrl (array, p)
  f=1
  for i in 0..array.length-1
    if array[i]==p
      f=0
      break
    end 
  end
  return f
end

##############################
#main
#############################

#gets the depth. If uncorrect prints the appropriate message
if ARGV.length!=1
  puts "Error! Wrong number of arguments!!"
  
else
  
  $depth= ARGV[0].to_i
  
  
  countDepth = 0
  count=0
  i = 0
  
  #initializing the crawler
  webpage="www.ucy.ac.cy/index.html"
  $arrayWeb=[webpage]
  $arrayWebBroken = ["BROKEN URL"]
  urlD = 1
  
  #it finds the urls and opens them until the given depth
  while countDepth <= $depth do
    while count < urlD do
      urlDepth = openCon($arrayWeb[count])
      count = count +1
    end
    urlD=urlDepth
    puts urlD
    countDepth = countDepth +1
  end
  
  #puts the broken urls in a file
  broken = File.open("brokenurls.dat", File::WRONLY|File::TRUNC|File::CREAT) 
  broken.puts 	$arrayWebBroken
  
  broken.close
  
  #puts the urls that were opened in a file
  urlFile = File.open("urlFile.dat", File::WRONLY|File::TRUNC|File::CREAT) 
  urlFile.puts 	$arrayWeb

  urlFile.close
  
end
