param([string]$f1,[int]$f2)



if(($f1.CompareTo("build-lexicon")) -eq 0){


dir .\georayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\geotweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$file = Get-Content test.txt
foreach($line in $file){
	if($line -match "^Text:"){
	Add-Content test20.txt $line 
	}

    }

$file = Get-Content test20.txt
foreach($line in $file){
	$line=$line -replace '\\u','0x'
	Add-Content test21.txt $line 

}

$file = Get-Content test21.txt
foreach($line in $file){
	$line=$line -replace " ","`n"
	Add-Content test22.txt $line 

}

$file = Get-Content test22.txt
foreach($line in $file){
	$line=$line -replace "0x","`r`n0x"
	Add-Content test23.txt $line 

}

$file = Get-Content test23.txt
foreach($line in $file){
	if($line -match "^0x"){
	$line=$line -replace "0x",[char]$line
	Add-Content test24.txt $line 
	}
	else{
	Add-Content test24.txt $line	
	}

}







}

###################################################################################

if(($f1.CompareTo("geo-sort")) -eq 0){


dir .\georayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\geotweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if(($count -eq 1) -and ($line -match "^Text:")){
	$flag=1
	}
	if(($flag -eq 1) -and ($line -match "^Time:")){
	$fline=$line+$fline
	$flag=0
	}
	else{
	$fline=$fline+$line
	}
	if($count -eq 3){
	Add-Content test2.txt $fline
	$count=0;
	$fline=""
	}
	
	
    }

$file = Get-Content test2.txt
ForEach($line in $file){
	
	if($line -match "^Time:`""){
	$pinakas=""
	$pinakas=$line.Split("`"")
		
	$pinakas2=$pinakas[1].Split(" ")
	$first=$pinakas2[1]+" "+$pinakas2[2]+" "+$pinakas2[5]
	$date=Get-Date "$first" -format d
	
	$second=$date+" "+$pinakas2[3]
	$fdate=(Get-Date "$second").ToFileTime()
	
	$newline="Time:"+$fdate+$pinakas[2]+$pinakas[3]+$pinakas[4]
	Add-Content test3.txt $newline 
	}
	else{
	Add-Content test3.txt $line 
	}	

   }

	get-content test3.txt|sort {$_[6..18]}



}



###################################################################################

if(($f1.CompareTo("geo-max-retransmitted")) -eq 0){


dir .\georayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\geotweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if($line -match "^Text:"){
	$fline=$fline+$line
	}
	if($line -match "^Time:"){
	$fline=$fline+$line
	}
	if($line -match "^Re"){
	$fline=$line+":    "+$fline
	}
	if($count -eq 3){
	Add-Content test12.txt $fline
	$count=0
	$fline=""
	}
	
	
    }
	get-content test12.txt|%{$_-replace ",",""}|Add-Content test13.txt
	get-content test13.txt|Sort-Object { [int]$_.split(":")[1] } -Descending|Add-Content geo_max_retransmitted.txt
}



###################################################################################

if(($f1.CompareTo("geo-before-date")) -eq 0){


dir .\georayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\geotweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

 $date="1/1/"+$f2
 $timestamp=(Get-Date "$date").ToFileTime()
 $timestamp=$timestamp/100000
 $timestamp

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if(($count -eq 1) -and ($line -match "^Text:")){
	$flag=1
	}
	if(($flag -eq 1) -and ($line -match "^Time:")){
	$fline=$line+":"+$fline
	$flag=0
	}
	else{
	$fline=$fline+$line
	}
	if($count -eq 3){
	Add-Content test2.txt $fline
	$count=0;
	$fline=""
	}
	
	
    }

$file = Get-Content test2.txt
ForEach($line in $file){
	
	if($line -match "^Time:`""){
	$pinakas=""
	$pinakas=$line.Split("`"")
		
	$pinakas2=$pinakas[1].Split(" ")
	$first=$pinakas2[1]+" "+$pinakas2[2]+" "+$pinakas2[5]
	$date=Get-Date "$first" -format d
	
	$second=$date+" "+$pinakas2[3]
	$fdate=(Get-Date "$second").ToFileTime()
	$fdate=$fdate/100000
	$newline="Time:"+$fdate+":"+$pinakas[2]+$pinakas[3]+$pinakas[4]
	Add-Content test15.txt $newline 
	}
	else{
	Add-Content test15.txt $line 
	}	

   }

		$file1 = Get-Content test15.txt
		ForEach($line in $file1){
			$table=$line.Split(":")
			if ($table[1] -lt $timestamp) {Add-Content geo_before_date.txt $line}
			}

}


###################################################################################################

if(($f1.CompareTo("geo-oldest")) -eq 0){


dir .\georayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\geotweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if(($count -eq 1) -and ($line -match "^Text:")){
	$flag=1
	}
	if(($flag -eq 1) -and ($line -match "^Time:")){
	$fline=$line+$fline
	$flag=0
	}
	else{
	$fline=$fline+$line
	}
	if($count -eq 3){
	Add-Content test2.txt $fline
	$count=0;
	$fline=""
	}
	
	
    }

$file = Get-Content test2.txt
ForEach($line in $file){
	
	if($line -match "^Time:`""){
	$pinakas=""
	$pinakas=$line.Split("`"")
		
	$pinakas2=$pinakas[1].Split(" ")
	$first=$pinakas2[1]+" "+$pinakas2[2]+" "+$pinakas2[5]
	$date=Get-Date "$first" -format d
	
	$second=$date+" "+$pinakas2[3]
	$fdate=(Get-Date "$second").ToFileTime()
	
	$newline="Time:"+$fdate+$pinakas[2]+$pinakas[3]+$pinakas[4]
	Add-Content test3.txt $newline 
	}
	else{
	Add-Content test3.txt $line 
	}	

   }

	get-content test3.txt|sort {$_[6..18]}|select -First 1



}



##########################################################################################################
if(($f1.CompareTo("latest-oldest")) -eq 0){


dir .\latestrayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\latesttweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if(($count -eq 1) -and ($line -match "^Text:")){
	$flag=1
	}
	if(($flag -eq 1) -and ($line -match "^Time:")){
	$fline=$line+$fline
	$flag=0
	}
	else{
	$fline=$fline+$line
	}
	if($count -eq 3){
	Add-Content test2.txt $fline
	$count=0;
	$fline=""
	}
	
	
    }

$file = Get-Content test2.txt
ForEach($line in $file){
	
	if($line -match "^Time:`""){
	$pinakas=""
	$pinakas=$line.Split("`"")
		
	$pinakas2=$pinakas[1].Split(" ")
	$first=$pinakas2[1]+" "+$pinakas2[2]+" "+$pinakas2[5]
	$date=Get-Date "$first" -format d
	
	$second=$date+" "+$pinakas2[3]
	$fdate=(Get-Date "$second").ToFileTime()
	
	$newline="Time:"+$fdate+$pinakas[2]+$pinakas[3]+$pinakas[4]
	Add-Content test3.txt $newline 
	}
	else{
	Add-Content test3.txt $line 
	}	

   }

	get-content test3.txt|sort {$_[6..18]}|select -First 1



}



####################################################################################################################

if(($f1.CompareTo("latest-sort")) -eq 0){


dir .\latestrayzit_msgs -include *.txt -rec | gc | Add-Content .\test.txt
dir .\latesttweets_msgs -include *.txt -rec | gc | Add-Content .\test.txt

$count=0
$fline=""
$file = Get-Content test.txt
foreach($line in $file){
	$count=$count+1;
	if(($count -eq 1) -and ($line -match "^Text:")){
	$flag=1
	}
	if(($flag -eq 1) -and ($line -match "^Time:")){
	$fline=$line+$fline
	$flag=0
	}
	else{
	$fline=$fline+$line
	}
	if($count -eq 3){
	Add-Content test2.txt $fline
	$count=0;
	$fline=""
	}
	
	
    }

$file = Get-Content test2.txt
ForEach($line in $file){
	
	if($line -match "^Time:`""){
	$pinakas=""
	$pinakas=$line.Split("`"")
		
	$pinakas2=$pinakas[1].Split(" ")
	$first=$pinakas2[1]+" "+$pinakas2[2]+" "+$pinakas2[5]
	$date=Get-Date "$first" -format d
	
	$second=$date+" "+$pinakas2[3]
	$fdate=(Get-Date "$second").ToFileTime()
	
	$newline="Time:"+$fdate+$pinakas[2]+$pinakas[3]+$pinakas[4]
	Add-Content test3.txt $newline 
	}
	else{
	Add-Content test3.txt $line 
	}	

   }

	get-content test3.txt|sort {$_[6..18]}



}