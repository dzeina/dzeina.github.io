
$consumer_key = "nX4pcKmVh97AurzF1vw" 
$enc_consumer_key = [System.Uri]::EscapeDataString($consumer_key) 

$auth_token="823982814-qi4RnSxugD7nPp5zwWEe8LZ1PxfTLpKsbVk2nR12"
$enc_auth_token = [System.Uri]::EscapeDataString($auth_token)

$auth_nonce="8b75d7086fcb184fd4558c11fcf64ca1"
$enc_auth_nonce = [System.Uri]::EscapeDataString($auth_nonce) 

$timestamp=[int][double]::Parse($(Get-Date -date (Get-Date).ToUniversalTime()-uformat %s))

$enc_timestamp = [System.Uri]::EscapeDataString($timestamp) 

$auth_sign="HMAC-SHA1"
$enc_auth_sign = [System.Uri]::EscapeDataString($auth_sign)

$base_url="https://api.twitter.com/1.1/statuses/user_timeline.json"
$enc_base_url = [System.Uri]::EscapeDataString($base_url) 

$auth_ber="1.0"
$enc_auth_ber = [System.Uri]::EscapeDataString($auth_ber) 

$screen_name="geokakou"
$enc_screen_name = [System.Uri]::EscapeDataString($screen_name) 

$count=20
$enc_count = [System.Uri]::EscapeDataString($count)

$http_method="GET"
$enc_http_method = [System.Uri]::EscapeDataString($http_method) 

$parameter_string="count="+$count+"&oauth_consumer_key="+$enc_consumer_key+"&oauth_nonce="+$enc_auth_nonce+"&oauth_signature_method="+$enc_auth_sign+"&oauth_timestamp="+$enc_timestamp+"&oauth_token="+$enc_auth_token+"&oauth_version="+$enc_auth_ber+"&screen_name="+$enc_screen_name
$enc_param_string=[System.Uri]::EscapeDataString($parameter_string)


$base_signature_string=$http_method+"&"+$enc_base_url+"&"+$enc_param_string
$base_signature_string

$consumer_secret="RJQjuHRGiNtFwJZELs4UHyqsXkpkgUvXNafVExHiFIU"
$enc_consumer_secret=[System.Uri]::EscapeDataString($consumer_secret)
$token_secret="vVppPtr9JBbqY9i83teWq1aoCpWpCcFCuVUnZ4a3en13C"
$enc_token_secret=[System.Uri]::EscapeDataString($token_secret)

$signature_key=$enc_consumer_secret+"&"+$enc_token_secret


$hmacsha1 = new-object System.Security.Cryptography.HMACSHA1
$hmacsha1.Key = [System.Text.Encoding]::ASCII.GetBytes($signature_key)
$signature = [System.Convert]::ToBase64String($hmacsha1.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($base_signature_string)))


$enc_signature=[System.Uri]::EscapeDataString($signature)

$command =".\curl.exe -k --"+$http_method +" '"+ $base_url + "' --data 'count="+$count+ "&" + "screen_name="+$screen_name+"' --header 'Authorization: OAuth oauth_consumer_key=`"" + $consumer_key + "`", oauth_nonce=`"" + $enc_auth_nonce + "`", oauth_signature=`"" + $enc_signature + "`", oauth_signature_method=`"" + $auth_sign + "`", oauth_timestamp=`"" + $timestamp + "`", oauth_token=`"" + $auth_token + "`", oauth_version=`"" + $auth_ber + "`"'"
$command
 


invoke-expression $command>twittermsgs.txt





Get-Content twittermsgs.txt |%{$_-replace "},{","`r`n"}|%{$_-replace "`"retweet_count`"","`r`n`"retweet_count`""} > latest.txt 
Get-Content latest.txt |%{$_-replace "`"created_at`"","`r`n`"created_at`""} > latest2.txt 
Get-Content latest2.txt |%{$_-replace "`"text`"","`r`n`"text`""} > latest3.txt 

$count=0;
$rcount=0;
$file = Get-Content latest3.txt
foreach($line in $file){
	if(($count -eq 0) -and ($line -match "^`"created_at`"")){
	$rcount=0	
	$line=$line -replace "`"created_at`"","Time" 
	Add-Content latest4.txt $line
	}
	if(($rcount -eq 0)-and($count -eq 0) -and ($line -match "^`"text`"")){
	$count=1
	$line=$line -replace "`"text`"","Text" 	
	Add-Content latest4.txt $line
	}
	if(($count -eq 1) -and ($line -match "^`"retweet_count`"")){	
	$line=$line -replace "`"retweet_count`"","Retweet" 
	Add-Content latest4.txt $line
	$rcount=1
	$count=0
	}
	
}


##############################################################################

$file = Get-Content latest4.txt
foreach($line in $file){
	$line=$line -replace ",`"","`r`n,`""
	Add-Content latest5.txt $line
}

$file = Get-Content latest5.txt
foreach($line in $file){
	if($line -match "^Time"){
	Add-Content latest6.txt $line
	}
	if($line -match "^Text"){
	Add-Content latest6.txt $line
	}
	if($line -match "^Retweet"){
	Add-Content latest6.txt $line
	}
}





##############################################################################


mkdir latesttweets_msgs


$count=0
$fcount=0
$file2 = Get-Content latest6.txt
Set-Location latesttweets_msgs
foreach($line in $file2){
	$count=$count+1
	Add-Content $fcount".txt" $line
	if($count%3 -eq 0){$fcount=$fcount+1}
}

Set-Location ..

	

##################################################################################################

$command2=".\curl.exe http://api.rayzit.com/latest/rayz/1440"




if(Test-Path .\latestrayzit_msgs){invoke-expression $command2 |
%{$_-replace "`"rayz_message","`n`"rayz_message"}|
%{$_-replace "`"timestamp","`n`"timestamp"}|
%{$_-replace "`"rerayz","`n`"rerayz"}|
%{$_-replace ",`"","`n`""}|
findstr "rayz_message timestamp rerayz"|
%{$_-replace "`"rayz_message`"","Text"}|
%{$_-replace "`"timestamp`"","Time"}|
%{$_-replace "`"rerayz`"","Rerayzs"} > pollis.txt

$src=get-content pollis.txt
Set-Location .\rayzit_msgs
$filename="$count.txt"
foreach($l in $src)
{
	
	if($count%3 -eq 0)
	{        
                 
		 $filename="$filenum.txt"
		 $filenum=$filenum+1
	}
add-content .\$filename $l
$count=$count+1

}


Set-Location ..
}
else
{
mkdir latestrayzit_msgs
invoke-expression $command2 |
%{$_-replace "`"rayz_message","`n`"rayz_message"}|
%{$_-replace "`"timestamp","`n`"timestamp"}|
%{$_-replace "`"rerayz","`n`"rerayz"}|
%{$_-replace ",`"","`n`""}|
findstr "rayz_message timestamp rerayz"|
%{$_-replace "`"rayz_message`"","Text"}|
%{$_-replace "`"timestamp`"","Time"}|
%{$_-replace "`"rerayz`"","Rerayzs"} > pollis.txt

$src=get-content pollis.txt
Set-Location .\latestrayzit_msgs
$filename="$count.txt"
foreach($l in $src)
{
	
	if($count%3 -eq 0)
	{        
                 
		 $filename="$filenum.txt"
		 $filenum=$filenum+1
	}
add-content .\$filename $l
$count=$count+1

}
Set-Location ..
}



##################################################################################################



