param([string]$f1,[string]$f2,[int]$r)



$km=$r*1000

##############################################################################################
$consumer_key = "nX4pcKmVh97AurzF1vw" 
$enc_consumer_key = [System.Uri]::EscapeDataString($consumer_key) 

$auth_token="823982814-qi4RnSxugD7nPp5zwWEe8LZ1PxfTLpKsbVk2nR12"
$enc_auth_token = [System.Uri]::EscapeDataString($auth_token)

$auth_nonce="8b75d7086fcb184fd4558c11fcf64ca1"
$enc_auth_nonce = [System.Uri]::EscapeDataString($auth_nonce) 

$timestamp=[int][double]::Parse($(Get-Date -date (Get-Date).ToUniversalTime()-uformat %s))

$enc_timestamp = [System.Uri]::EscapeDataString($timestamp) 

$auth_sign="HMAC-SHA1"
$enc_auth_sign = [System.Uri]::EscapeDataString($auth_sign)

$base_url="https://api.twitter.com/1.1/search/tweets.json"
$enc_base_url = [System.Uri]::EscapeDataString($base_url) 

$auth_ber="1.0"
$enc_auth_ber = [System.Uri]::EscapeDataString($auth_ber) 

$geo_gode=$f1+","+$f2+","+$r+"km"
$enc_geo_gode = [System.Uri]::EscapeDataString($geo_gode) 

$http_method="GET"
$enc_http_method = [System.Uri]::EscapeDataString($http_method) 

$parameter_string="geocode="+$enc_geo_gode+"&oauth_consumer_key="+$enc_consumer_key+"&oauth_nonce="+$enc_auth_nonce+"&oauth_signature_method="+$enc_auth_sign+"&oauth_timestamp="+$enc_timestamp+"&oauth_token="+$enc_auth_token+"&oauth_version="+$enc_auth_ber+"&query=ela"
$enc_param_string=[System.Uri]::EscapeDataString($parameter_string)


$base_signature_string=$http_method+"&"+$enc_base_url+"&"+$enc_param_string



$consumer_secret="RJQjuHRGiNtFwJZELs4UHyqsXkpkgUvXNafVExHiFIU"
$enc_consumer_secret=[System.Uri]::EscapeDataString($consumer_secret)
$token_secret="vVppPtr9JBbqY9i83teWq1aoCpWpCcFCuVUnZ4a3en13C"
$enc_token_secret=[System.Uri]::EscapeDataString($token_secret)

$signature_key=$enc_consumer_secret+"&"+$enc_token_secret


$hmacsha1 = new-object System.Security.Cryptography.HMACSHA1
$hmacsha1.Key = [System.Text.Encoding]::ASCII.GetBytes($signature_key)
$signature = [System.Convert]::ToBase64String($hmacsha1.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($base_signature_string)))


$enc_signature=[System.Uri]::EscapeDataString($signature)

$command =".\curl.exe -k --"+$http_method +" '"+ $base_url + "' --data 'geocode=" + $enc_geo_gode+"&query=ela' --header 'Authorization: OAuth oauth_consumer_key=`"" + $consumer_key + "`", oauth_nonce=`"" + $auth_nonce + "`", oauth_signature=`"" + $enc_signature + "`", oauth_signature_method=`"" + $auth_sign + "`", oauth_timestamp=`"" + $timestamp + "`", oauth_token=`"" + $auth_token + "`", oauth_version=`"" + $auth_ber + "`"'"


invoke-expression $command>twittermsgs.txt




Get-Content twittermsgs.txt |%{$_-replace "`"metadata`"","`r`n"}|%{$_-replace "`"retweet_count`"","`r`n`"retweet_count`""} > testtwit1.txt 

$file = Get-Content testtwit1.txt
foreach($line in $file){	
        $line=$line -replace "`"created_at`"","`r`n`"created_at`""
	Add-Content testtwit2.txt $line
}

$count=0;
$file = Get-Content testtwit2.txt
foreach($line in $file){
	if($line -match "^:{`"result_type`""){$count=1}
	if(($line -match "^`"created_at`"") -and ($count -eq 1)){	
	Add-Content testtwit3.txt $line
	$count=0;
	}
	if($line -match "^`"retweet_count`""){
	Add-Content testtwit3.txt $line
	}

}



$file2 = Get-Content testtwit3.txt
foreach($line in $file2){
	if($line -match "^`"created_at`""){
	$line=$line -replace "`"text`"","`r`n`"text`""
	Add-Content testtwit4.txt $line
	}
	if($line -match "^`"retweet_count`""){
	Add-Content testtwit4.txt $line
	}
		
        

	
}

$count3=0
$file2 = Get-Content testtwit4.txt
foreach($line in $file2){
	if($line -match "^`"created_at`""){
	$count3=1
	Add-Content testtwit5.txt $line
	}
	if($line -match "^`"retweet_count`""){
	Add-Content testtwit5.txt $line
	}
	if(($line -match "^`"text`"") -and ($count3 -eq 1)){
	Add-Content testtwit5.txt $line
	$count3=0
	}	
        

	
}

$count2=0;
$file = Get-Content testtwit5.txt
foreach($line in $file){
	if($line -match "^`"created_at`""){
	$count2=1
	Add-Content testtwit6.txt $line}
	if(($line -match "^`"retweet_count`"") -and ($count2 -eq 1)){	
	Add-Content testtwit6.txt $line
	$count2=0;
	}
	if($line -match "^`"text`""){
	Add-Content testtwit6.txt $line
	}

}
$create=0;
$text=0;
$file = Get-Content testtwit6.txt
foreach($line in $file){
	if(($line -match "^`"created_at`"") -and ($create -eq 0)){
	$create=1
	Add-Content testtwit7.txt $line}
	if(($line -match "^`"text`"") -and ($text -eq 0)){
	$text=1;
	Add-Content testtwit7.txt $line
	}
	if(($line -match "^`"retweet_count`"") -and ($create -eq 1)){
	Add-Content testtwit7.txt $line
	$create=0
	$text=0
	}

}

$file = Get-Content testtwit7.txt
foreach($line in $file){
	$line=$line -replace ",`"","`r`n,`""
	Add-Content testtwit8.txt $line
}

$file = Get-Content testtwit8.txt
foreach($line in $file){
	if($line -match "^`"created_at`""){
	Add-Content testtwit9.txt $line}
	if($line -match "^`"text`""){
	Add-Content testtwit9.txt $line
	}
	if($line -match "^`"retweet_count`""){
	Add-Content testtwit9.txt $line
	}
}

$file = Get-Content testtwit9.txt
foreach($line in $file){
	if($line -match "^`"Text`""){
	$line=$line -replace "`"Text`"","Text"
	}
	if($line -match "^`"created_at`""){
	$line=$line -replace "`"created_at`"","Time"
	}
	if($line -match "^`"retweet_count`""){
	$line=$line -replace "`"retweet_count`"","Retweet"
	}
	Add-Content testtwit10.txt $line

	
}






$mod=0
$filenum=0
if(Test-Path .\geotweets_msgs){
$file=Get-Content testtwit10.txt
Set-Location .\geotweets_msgs
foreach($l in $file)
{
if($mod%3 -eq 0){
	$filename="$filenum.txt"
	$filenum=$filenum+1
}

add-content .\$filename $l
$mod=$mod+1
}
cd ..
}
else{
mkdir geotweets_msgs
$file=Get-Content testtwit10.txt
Set-Location .\geotweets_msgs
foreach($l in $file)
{
if($mod%3 -eq 0){
	$filename="$filenum.txt"
	$filenum=$filenum+1
}

add-content .\$filename $l
$mod=$mod+1
}
cd ..


}



#########################################################################################

$count=0
$filenum=0

$command2= ".\curl.exe 'http://api.rayzit.com/nearbyrayz/"+$f1+"/"+$f2+"/"+$km+"'"



if(Test-Path .\georayzit_msgs){invoke-expression $command2 |
%{$_-replace "`"rayz_message","`n`"rayz_message"}|
%{$_-replace "`"timestamp","`n`"timestamp"}|
%{$_-replace "`"rerayz","`n`"rerayz"}|
%{$_-replace ",`"","`n`""}|
findstr "rayz_message timestamp rerayz"|
%{$_-replace "`"rayz_message`"","Text"}|
%{$_-replace "`"timestamp`"","Time"}|
%{$_-replace "`"rerayz`"","Rerayzs"} > pollis.txt

$src=get-content pollis.txt
Set-Location .\georayzit_msgs
$filename="$count.txt"
foreach($l in $src)
{
	
	if($count%3 -eq 0)
	{        
                 
		 $filename="$filenum.txt"
		 $filenum=$filenum+1
	}
add-content .\$filename $l
$count=$count+1

}


Set-Location ..
}
else
{
mkdir georayzit_msgs
invoke-expression $command2 |
%{$_-replace "`"rayz_message","`n`"rayz_message"}|
%{$_-replace "`"timestamp","`n`"timestamp"}|
%{$_-replace "`"rerayz","`n`"rerayz"}|
%{$_-replace ",`"","`n`""}|
findstr "rayz_message timestamp rerayz"|
%{$_-replace "`"rayz_message`"","Text"}|
%{$_-replace "`"timestamp`"","Time"}|
%{$_-replace "`"rerayz`"","Rerayzs"} > pollis.txt

$src=get-content pollis.txt
Set-Location .\georayzit_msgs
$filename="$count.txt"
foreach($l in $src)
{
	
	if($count%3 -eq 0)
	{        
                 
		 $filename="$filenum.txt"
		 $filenum=$filenum+1
	}
add-content .\$filename $l
$count=$count+1

}
Set-Location ..
}