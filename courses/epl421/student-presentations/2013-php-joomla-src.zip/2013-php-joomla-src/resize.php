<?php

class Resize{
	
	private $url;
	private $height;
	private $width;
	
	public function __construct($url,$width,$height){
		$this->url=$url;
		$this->width=$width;
		$this->height=$height;
	}
	
	public function resize(){
		list($width,$height) = getimagesize($this->url);
		$_image=imagecreatetruecolor($this->width,$this->height);
		$image = imagecreatefromjpeg($this->url);
		imagecopyresampled($_image,$image,0,0,0,0,$this->width,$this->height,$width,$height);
		header('Content-Type: image/jpeg');
		imagejpeg($_image,NULL,100);
		imagedestroy($_image);
	}
	

	
		
}


$url = $_GET['url'];
$width = $_GET['width'];
$height = $_GET['height'];
$r = new Resize($url,$width,$height);
$r->resize();
?>


