<?php
include "parser.php";
class Search{

	private $path;
	
	public function __construct($path){
		$this->path=$path;
	}
	
	public function search($keyword){
		$tags=array("speaker","time","date","location","affiliation","category","host");//,"abstract","bio");
		$p = new Parser($this->path);
		
		for($x=0;$x<count($tags);$x++){
			//echo $k;
			$k=0;
			$d=$p->parse($k,$tags[$x]);
			//echo $d;
			while($d){
			//	echo $d;
				//echo "<br>";
				$_d=str_split($d);
				$_keyword=str_split($keyword);
				$i=0;
				$j=0;
				//echo $k."<br>";
				//echo strlen($date);
				while($i!=strlen($d)){
				//echo $i;
				
					if($_d[$i]==$_keyword[$j]){
						$j++;
					}else{
						$j=0;
					}
			
					if($j==strlen($keyword)){//found
						$arr[$k]=$k;
						break;
					}else{
						//echo $j." ".strlen($keyword)." ".$keyword;
						if($arr[$k]!=$k){
							$arr[$k]=-1;
						}
					}
			
					$i++;
				}
				$k++;
				$d=$p->parse($k,$tags[$x]);
			}
			
		}
		return $arr;
	}

			
		
	
	
	public function searchDate($date){
		$p = new Parser($this->path);
		$k=0;
		$d=$p->parse($k,"date");
		while($d){
			$_d=str_split($d);
			$_date=str_split($date);
			$i=0;
			$j=0;
			//echo strlen($date);
			while($i!=strlen($d)){
			//echo $i;
				if($_d[$i]==$_date[$j]){
					$j++;
				}else{
					$j=0;
				}
			
				if($j==strlen($date)){//found
				//echo "GOT";
					//return true;
					$arr[$k]=$k;
				}else{
					$arr[$k]=-1;
				}
			
				$i++;
			}
			$k++;
			$d=$p->parse($k,"date");
		}
		return $arr;
	}
	
}
	

//$s = new Search("https://www8.cs.ucy.ac.cy/conferences/colloquium/rss.xml");
//$arr=$s->search(exploit);
//$arr=$s->searchDate(2009);
//echo count($arr);	
//for($x=0;$x<count($arr);$x++){
	//echo $arr[$x];
	//echo "<br>";
//}
//echo $arr[90];

?>
