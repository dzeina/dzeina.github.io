<?php
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die;
$layout =$params->get('layout','default');
require JModuleHelper::getLayoutPath('mod_rsscolloquim',$layout);

/*
$parser = new Parser(get('rss_link')); 
echo "speaker" . $res=$parser->parse(0,"speaker"); 
*/
//echo $params->get('rss_link');
//echo $params->get('number_of_image');
//echo $params->get('moduleclass_sfx');
//echo $params->get('pretext');


//require_once (dirname(__FILE__).'/helper.php');
//$img=ReadData::getimage($params);
//echo "<img src='$img'; alt='dssfdds' height='50' width='75' style='float:left'; margin:'0px 0px 15px 15px';cols='60'; rows='8';>";

?>