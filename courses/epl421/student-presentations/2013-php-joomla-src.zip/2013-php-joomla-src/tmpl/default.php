<?php

//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die;

include('/var/www/joomla/modules/mod_rsscolloquim/search.php');
$document = JFactory::getDocument();
$document->addStyleSheet('modules/mod_rsscolloquim/main.css');
$document->addStyleSheet('modules/mod_rsscolloquim/custom.css');


?>






<?php 



function get(){

$beg=$_GET["beg"];
$end=$_GET["end"];
$type=$_GET["type"];
$year=$_GET["year"];
$search=$_GET["search"];
//echo $beg;
//echo $end;

if(!isset($_GET["beg"])){
	//echo $beg;
	//echo $end;
	$beg=0;
	$end=5;
	$type=0;
	$year=0;
	$search="";
}

?>



<html>
<head>
<script text="text/javascript">
	var beg;
	var end;
	var type;
	var year;
	var key;

function ctype(_type){
	beg = <?php echo $beg; ?>;
	end = <?php echo $end; ?>;
	year = <?php echo $year; ?>;
	//type= <?php echo $type; ?>;
	key = "<?php echo $search; ?>";
	
	type=_type;
	window.location = "index.php?beg="+beg+"&end="+end+"&type="+type+"&year="+year+"&search="+key;
}

function cyear(_year){
	beg=0;
	end=5;
	type=<?php echo $type; ?>;
	key = "";

	window.location = "index.php?beg="+beg+"&end="+end+"&type="+type+"&year="+_year+"&search="+key;

}

function next(){
	beg = <?php echo $beg; ?>;
	end = <?php echo $end; ?>;
	type= <?php echo $type; ?>;
	year= <?php echo $year; ?>;
	key = "<?php echo $search; ?>";

	beg+=5;
	end+=5;
	window.location = "index.php?beg="+beg+"&end="+end+"&type="+type+"&year="+year+"&search="+key;
}

function prev(){
	beg = <?php echo $beg; ?>;
	end = <?php echo $end; ?>;
	type= <?php echo $type; ?>;
	year = <?php echo $year; ?>;
	key = "<?php echo $search; ?>";

	if(beg>0){
		beg-=5;
		end-=5;
	}
	window.location = "index.php?beg="+beg+"&end="+end+"&type="+type+"&year="+year+"&search="+key;
}

function search(){
	key=document.getElementById('sbox').value;
	beg = 0;
	end = 5;
	type= <?php echo $type; ?>;
	year = 0;
	window.location = "index.php?beg="+beg+"&end="+end+"&type="+type+"&year="+year+"&search="+key;


	
}



</script>

<script type='text/javascript'>
function showlayer(layer){
var myLayer = document.getElementById(layer);
if(myLayer.style.display=="none" || myLayer.style.display==""){
myLayer.style.display="block";
} else {
myLayer.style.display="none";
}
}
</script>

</head>
<style type="text/css">
   body{padding:20px; font-size:14px; color:#000000; font-family:Arial, Helvetica, sans-serif;}
   h2 {font-weight:bold; color:#000099; margin:10px 0px; }
   p span {color:#006600; font-weight:bold; }
   a, a:link, a:visited {color:#0000FF;}
   textarea {width: 100%; padding: 10px; margin: 10px 0 15px 0; font-size: 13px; font-family: Consolas,monospace;}
   textarea.html {height: 300px;}
   p {margin: 0 0 10px 0;}
   code, pre {font-family: Consolas,monospace; color: green;}
   ol li {margin: 0 0 15px 0;}
</style>

<body>


<div id='cssmenu'>
<ul>
   <li class='active '><a ><span>CS Colloquium Series @ UCY</span></a></li>
   <li class='has-sub '><a href='#'><span>Years</span></a>
      <ul>
		   <li><a href="javascript:cyear(0);"><span>All</span></a></li>
        <li><a href="javascript:cyear(2013);"><span>2013</span></a></li>
        <li><a href="javascript:cyear(2012);"><span>2012</span></a></li>
	<li><a href="javascript:cyear(2011);"><span>2011</span></a></li>
	<li><a href="javascript:cyear(2010);"><span>2010</span></a></li>
	<li><a href="javascript:cyear(2009);"><span>2009</span></a></li>
      </ul>
   </li>
   <li class='has-sub '><a href='#'><span>View</span></a>
 <ul>
           <li><a href="javascript:ctype(0);"><span>Thumbnail</span></a></li>
           <li><a href="javascript:ctype(1);"><span>Listing</span></a></li>
      </ul>
</li>
 <li class='has-sub '><a href='#'><span>Search</span></a>
	<ul>
		<style= "padding: 2px 0px 0px 2px">
	<input id="sbox" action="search()" type="text" size="1" style=" width:120px ;"/>
	<button onclick="search()"><i>Search</i></button>
	</style>
	</ul>
</li>
</ul>
</div>

<?php
$path="";
$parser = new Parser("https://www.cs.ucy.ac.cy/colloquium/rss.xml");
$width="99";
$height="99";
$beg=$beg+0;//because php cant evaluate it as int

	if($year==0 and $search==""){
		for($i=$beg; $i<$end; $i++)
			{
			
			$speaker=$parser->parse($i,"speaker");
			$img =$parser->parse($i,"image") ;
			if(isset($speaker) && isset($img)){
				if($type==0){
					echo 	'<div style="position: relative; left: 0; top: 0; padding:10px 0px 10px 0px" >';
					echo	"<a  href=".$parser->getLink().">";
					//echo	'<img style=position: relative; top: 0; left: 0; display: block; vertical-align: middle;  margin-right: 8px; float: right;';
					echo 	'<img src = '.$img.' class="photo"/>';
					
					
					echo  	'<span style=position: absolute; top: 0; left: 300; display: block; overflow: auto;>'.'</a>';
					
					////
					echo '<div id="menu">';
					echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
					echo '</div>';
					////
					echo 	"<br>Speaker: ".$speaker."<style=.padding: 0px 0px 0px 0px ></br></a></style></div>";
					}else{
						echo 	'<div style="position: relative; left: 0; top: 0; padding:20px 0px 20px 0px" >';
						echo	'<a  href="'.$parser->getLink().'" target="_blank">';
						echo	'<img style="position: relative; padding:0px 0px 10px 0px; top: 0; display: block; vertical-align: right;  margin-right: 8px; float: left;"';
						//echo 	"<img src = 'http://localhost/resize.php?url=".$img."&width=".$width."&height=".$height . "' />";
						echo 	'<img src = '.$img.' class="photo"/>';
						echo  	'<span style=position: absolute; top: 0; left: 600; display: block; overflow: auto;>'.'</a>';
		

						echo 	'<strong>Title: </strong>'.$parser->getTitle().'<br>';
						echo 	"<strong>Speaker:</strong> ".$speaker."<style=padding: 0px 0px 0px 0px ></br>";
						echo	'<strong>Date: </strong>'.$parser->parse($i,"date").'<br>';
						echo	'<strong>Time: </strong>'.$parser->parse($i,"time").'';
								
						echo 	"</div>";
						echo 	"</style>";
					
						//echo 	'<ul id="menu"><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
						echo '<div id="menu">';
						echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
						echo '</div>';
						
						
						

					}
				}
		
			}
	}else if($year!=0){//year 
	
	
		$s = new Search("https://www.cs.ucy.ac.cy/colloquium/rss.xml");
		$arr=$s->searchDate($year);
		$i=0;
		for($x=0;$x<count($arr);$x++){
			if($arr[$x]!=-1){
				$res[$i]=$arr[$x];
				$i++;
			}
		}
		$_parser = new Parser("https://www.cs.ucy.ac.cy/colloquium/rss.xml");

		
	
		for($i=$beg; $i<$end; $i++)
		{
		
		$speaker=$parser->parse($res[$i]+0,"speaker");
		$img =$parser->parse($res[$i],"image") ;
		if(isset($speaker) && isset($img)){

				if($type==0){
					echo 	'<div style="position: relative; left: 0; top: 0; padding:10px 0px 10px 0px" >';
					echo	"<a  href=".$parser->getLink().">";
					//echo	'<img style=position: relative; top: 0; left: 0; display: block; vertical-align: middle;  margin-right: 8px; float: right;';
					//echo 	'<img src = resize.php?url='.$img.'&width='.$width.'&height='.$height . ' />';
					echo 	'<img src = '.$img.' class="photo"/>';
					echo  	'<span style=position: absolute; top: 0; left: 300; display: block; overflow: auto;>'.'</a>';
					
					//echo 	'<ul id="menu"><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
					echo '<div id="menu">';
					echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($res[$i],"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($res[$i],"bio").'</a></ul></li></ul>';
					echo '</div>';
					echo 	"<br>Speaker: ".$speaker."<style=.padding: 0px 0px 0px 0px ></br></a></style></div>";
					}else{
						echo 	'<div style="position: relative; left: 0; top: 0; padding:20px 0px 20px 0px" >';
						echo	'<a  href="'.$parser->getLink().'" target="_blank">';
						echo	'<img style="position: relative; padding:0px 0px 10px 0px; top: 0; display: block; vertical-align: right;  margin-right: 8px; float: left;"';
						//echo 	"<img src = 'http://localhost/resize.php?url=".$img."&width=".$width."&height=".$height . "' />";
						echo 	'<img src = '.$img.' class="photo"/>';
						echo  	'<span style=position: absolute; top: 0; left: 600; display: block; overflow: auto;>'.'</a>';
		

						echo 	'<strong>Title: </strong>'.$parser->getTitle().'<br>';
						echo 	"<strong>Speaker:</strong> ".$speaker."<style=padding: 0px 0px 0px 0px ></br>";
						echo	'<strong>Date: </strong>'.$parser->parse($res[$i],"date").'<br>';
						echo	'<strong>Time: </strong>'.$parser->parse($res[$i],"time").'';
								

						echo 	"</style>";
					
						//echo 	'<ul id="menu"><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
						echo '<div id="menu">';
						echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($res[$i],"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($res[$i],"bio").'</a></ul></li></ul>';
						echo '</div>';
						echo 	"</div>";
						
						

					}
			}
	
		}

	}else{//search
		$s = new Search("https://www.cs.ucy.ac.cy/colloquium/rss.xml");
		$arr=$s->search($search);
		$i=0;
		for($x=0;$x<count($arr);$x++){
			if($arr[$x]!=-1){
				$res[$i]=$arr[$x];
				$i++;
			}
		}
		$__parser = new Parser("https://www.cs.ucy.ac.cy/colloquium/rss.xml");

		
	
		for($i=$beg; $i<$end; $i++)
		{
		
		$speaker=$parser->parse($res[$i]+0,"speaker");
		$img =$parser->parse($res[$i],"image") ;
		if(isset($speaker) && isset($img)){

				if($type==0){
					echo 	'<div style="position: relative; left: 0; top: 0; padding:10px 0px 10px 0px" >';
					echo	"<a  href=".$parser->getLink().">";
					//echo	'<img style=position: relative; top: 0; left: 0; display: block; vertical-align: middle;  margin-right: 8px; float: right;';
					//echo 	'<img src = resize.php?url='.$img.'&width='.$width.'&height='.$height . ' />';
					echo 	'<img src = '.$img.' class="photo"/>';
					echo  	'<span style=position: absolute; top: 0; left: 300; display: block; overflow: auto;>'.'</a>';
					
					//echo 	'<ul id="menu"><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
					echo '<div id="menu">';
					echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($res[$i],"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($res[$i],"bio").'</a></ul></li></ul>';
					echo '</div>';
					echo 	"<br>Speaker: ".$speaker."<style=.padding: 0px 0px 0px 0px ></br></a></style></div>";
					}else{
						echo 	'<div style="position: relative; left: 0; top: 0; padding:20px 0px 20px 0px" >';
						echo	'<a  href="'.$parser->getLink().'" target="_blank">';
						echo	'<img style="position: relative; padding:0px 0px 10px 0px; top: 0; display: block; vertical-align: right;  margin-right: 8px; float: left;"';
						
						//echo 	"<img src = 'http://localhost/resize.php?url=".$img."&width=".$width."&height=".$height . "' />";
						echo 	'<img src = '.$img.' class="photo"/>';
						echo  	'<span style=position: absolute; top: 0; left: 600; display: block; overflow: auto;>'.'</a>';
		

						echo 	'<strong>Title: </strong>'.$parser->getTitle().'<br>';
						echo 	"<strong>Speaker:</strong> ".$speaker."<style=padding: 0px 0px 0px 0px ></br>";
						echo	'<strong>Date: </strong>'.$parser->parse($res[$i],"date").'<br>';
						echo	'<strong>Time: </strong>'.$parser->parse($res[$i],"time").'';
								

						echo 	"</style>";
					
						//echo 	'<ul id="menu"><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($i,"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($i,"bio").'</a></ul></li></ul>';
						echo '<div id="menu">';
						echo 	'<ul><a href="'.$parser->getLink().'"><li><a href="#">More...</a><ul><li><a href="#"><strong>Abstract:</strong><br>'.$parser->parse($res[$i],"abstract").'<br><strong>Short Bio:</strong><br>'.$parser->parse($res[$i],"bio").'</a></ul></li></ul>';
						echo '</div>';
						echo 	"</div>";
						
						

					}
			}
	
		}
		
		}//////// 
}


get();
?>


</div>
<div id='cssmenu'>
<ul>
   <li class='active '><a ><span>Pages</span></a></li>
   <li><a href="javascript:prev();"><span>Prev</span></a></li>
   <li><a href="javascript:next();"><span>Next</span></a></li>
</ul>
</div>
</body>

</html>



<!--<button onclick="prev()">Previous</button> <button onclick="next()">Next</button>
<button onclick="ctype()">Type</button>
<button onclick="cyear(2013)">2013</button>
<input id="sbox" type="text" />
<button onclick="search()">Search</button> -->














