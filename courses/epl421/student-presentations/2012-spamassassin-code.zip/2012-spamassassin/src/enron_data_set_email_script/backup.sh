#!/bin/bash

# script to send simple email
# email subject


for filename in "$1"
#while read filename 
do
echo "Script is now running in directory. . . . . . ." $filename
#echo "filename is " $filename

SUBJECT="$(cat $filename | grep "Subject:" | sed -e 's/Subject://')"

#echo "Subject is " $SUBJECT
# Email To ?
EMAIL="epl371@localhost.com"
#diavase to arxeio apo tin arxi mexri na vreis to X-FileName:. Molis to vreis apo tin epomeni grammi kai meta mexri to telos tou arxeiou auto pou #akolouthei einai to body tou minimatos
#done;

HEADER_UNTIL_LINE_NO=$(cat $filename | grep -n X-FileName: | cut -d ":" -f1)
#echo $HEADER_UNTIL_LINE_NO
((HEADER_UNTIL_LINE_NO++))
#echo $HEADER_UNTIL_LINE_NO
noofline=0;

while read line 
do
((noofline++))
#echo $noofline
if [[ $noofline -ge HEADER_UNTIL_LINE_NO ]]; then
	echo $line >> temp.txt
fi

done < $filename


# send an email using /bin/mail
/usr/bin/mail -s "$SUBJECT" "$EMAIL" < temp.txt

rm temp.txt
done 
