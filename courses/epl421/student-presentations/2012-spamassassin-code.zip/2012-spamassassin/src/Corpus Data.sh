#!/bin/bash

for filename in `cat Spam.txt`
do
echo "Script is now running in directory. . . . . . ." $filename
#echo "filename is " $filename

SUBJECT="$(cat $filename | grep "Subject:" | sed -e 's/Subject://')"

#echo "Subject is " $SUBJECT
# Email To ?
EMAIL="epl371@localhost.com"

#HEADER_UNTIL_LINE_NO=$(cat $filename | grep -n "^$" | cut -d ":" -f1)
HEADER_UNTIL_LINE_NO=$(cat $filename | grep -n "^$" | head -n 1| cut -d ":" -f1)
#echo $HEADER_UNTIL_LINE_NO
((HEADER_UNTIL_LINE_NO++))
#echo $HEADER_UNTIL_LINE_NO
noofline=0;

while read line 
do
((noofline++))
#echo $noofline
if [[ $noofline -ge HEADER_UNTIL_LINE_NO ]]; then
	echo $line >> temp.txt
fi

done < $filename


# send an email using /bin/mail
/usr/bin/mail -s "$SUBJECT" "$EMAIL" < temp.txt

rm temp.txt
done 
