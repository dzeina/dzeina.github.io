#include <stdio.h>
#include <signal.h>

#define orig_pi 3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862803482534211706798214808651328
float pi=0;

void compute_pi1(char* seconds)
{
 float counter=1;
 int flag=0;

 while(1)
   {
     if (flag % 2==0)
        pi= pi+(4/counter);
     else
        pi= pi-(4/counter);
     flag++;
     counter+=2;
     sleep(1);
     //printf("The difference of pi and Compute_pi1 is %.30f\n", orig_pi-pi);
   }
}

int main(int argc, char * argv[])
{
  compute_pi1(argv[1]);
}
