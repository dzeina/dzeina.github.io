#include <sys/types.h> /* For sockets */
#include <sys/socket.h> /* For sockets */
#include <netinet/in.h> /* For Internet sockets */
#include <netdb.h> /* For gethostbyname */
#include <stdio.h> /* For I/O */
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>

main(int argc, char *argv[]) /* Client with Internet stream sockets */
{
 int port, sock, serverlen; char buf[256];
 struct sockaddr_in server;
 struct sockaddr *serverptr;
 struct hostent *rem;
 int i;

 if (argc < 3)
    { /* Check if server's host name and port number are given */
     printf("Please give the host name and the port number\n");
     exit(1);
    }


  // Your code goes here


 exit(0);
}
