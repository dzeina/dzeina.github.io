/* File: int_str_server.c */
#include <sys/types.h> // For sockets
#include <sys/socket.h> // For sockets
#include <netinet/in.h> // For Internet sockets
#include <netdb.h> // For gethostbyaddr
#include <stdio.h> // For I/O
#include <unistd.h>
#include <stdlib.h>
#include <strings.h>

float convert(char *s);
int find_code(char *s);
void display(int sock);
char *country_table[10];
char *code_table[10];
float equal_value[10];
char country_code[4];
char quantity[10];

main(int argc, char *argv[]) /* Server with Internet stream sockets */
{
 int port, sock, newsock, serverlen;//, clientlen;
 socklen_t clientlen;
 char buf[256];
 struct sockaddr_in server, client;
 struct sockaddr *serverptr, *clientptr;
 struct hostent *rem;
 float amount;

 country_table[0]= "Euro     ";
 country_table[1]= "British Pound";
 country_table[2]= "French Franc";
 country_table[3]= "German Mark";
 country_table[4]= "Greek Drachma";
 country_table[5]= "Italian Lira";
 country_table[6]= "US Dollar";
 country_table[7]= "Yugoslav Dinar";
 country_table[8]= "Swiss Franc";
 country_table[9]= "Russian Rouble";

 code_table[0]= "EUR";
 code_table[1]= "GBP";
 code_table[2]= "FRF";
 code_table[3]= "DEM";
 code_table[4]= "GRD";
 code_table[5]= "ITL";
 code_table[6]= "USD";
 code_table[7]= "YUN";
 code_table[8]= "CHF";
 code_table[9]= "RUB";

 equal_value[0]=0.55867;
 equal_value[1]=0.89177;
 equal_value[2]=0.08517;
 equal_value[3]=0.28565;
 equal_value[4]=0.001640;
 equal_value[5]=0.0002885;
 equal_value[6]=0.61774;
 equal_value[7]=0.009290;
 equal_value[8]=0.37775;
 equal_value[9]=0.02090;

 if (argc < 2)
    { /* Check if server's port number is given */
     printf("Please give the port number\n");
     exit(1);
    }

 if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    { /* Create socket */
     perror("socket");
     exit(1);
    }

 port = atoi(argv[1]); /* Convert port number to integer */
 server.sin_family = AF_INET; /* Internet domain */
 server.sin_addr.s_addr = htonl(INADDR_ANY); /* My Internet address */
 server.sin_port = htons(port); /* The given port */
 serverptr = (struct sockaddr *) &server;
 serverlen = sizeof server;

 if (bind(sock, serverptr, serverlen) < 0)
    { /* Bind socket to an address */
     perror("bind");
     exit(1);
    }
 if (listen(sock, 5) < 0)
    { /* Listen for connections */
     perror("listen");
     exit(1);
    }

 printf("Listening for connections to port %d\n", port);

 while(1)
    {
     clientptr = (struct sockaddr *) &client;
     clientlen = sizeof client;
     if ((newsock = accept(sock, clientptr, &clientlen)) < 0)
        {
         perror("accept");
         exit(1);
        } /* Accept connection */

     rem = gethostbyaddr((char *) &client.sin_addr.s_addr, sizeof client.sin_addr.s_addr, /* Find client's address */client.sin_family);
     if (rem == NULL)
        {
         perror("gethostbyaddr");
         exit(1);
        }

      printf("Accepted connection from %s\n", rem -> h_name);

      switch (fork())
         { /* Create child for serving the client */
          case -1:
               {
                perror("fork");
                exit(1);
               }
          case 0: /* Child process */
               {
                display(newsock);
                do {
                   bzero(buf, sizeof buf); /* Initialize buffer */
                   if (read(newsock, buf, sizeof buf) < 0)
                      { /* Receive message */
                       perror("read");
                       exit(1);
                      }
                   printf("Read string: %s\n", buf);
                   amount = convert(buf); /* Reverse message */

                   bzero(buf, sizeof buf);

                   if ((strcmp(country_code, "end") != 0) && (strcmp(country_code, "err") != 0))
                      {
                       sprintf(buf, "%.10f", amount);
                       if (write(newsock, buf, sizeof buf) < 0)
                          { /* Send message */
                           perror("write");
                           exit(1);
                          }
                      }
                   else
                      {
                       if (write(newsock, country_code, sizeof country_code) < 0)
                          { /* Send message */
                           perror("write");
                           exit(1);
                          }
                      }
                  } while (strcmp(country_code, "end") != 0); /* Finish on "end" */
                }
         close(newsock); /* Close socket */
         printf("Connection from %s is closed\n", rem -> h_name);
         exit(0);
        }
    }
}


float convert(char *s) /* Function for converting the currency */
{
 float amount;
 int i;
 int code_no;

 bzero(country_code, sizeof country_code);
 bzero(quantity, sizeof quantity);

 if (strlen(s)>13)
    {perror("amount"); exit(1);}

 for (i=0; i<3 ; i++)
     country_code[i] = s[i];
 country_code[3]='\0';

 if (strcmp(country_code,"end")!=0)
    {
     for (i=3; i<strlen(s) ; i++)
         quantity[i-3] = s[i];

     amount = atof(quantity);

     code_no = find_code(country_code);

     if (code_no>9)
        {//perror("country_code");
         country_code[0]='e';
         country_code[1]='r';
         country_code[2]='r';
         country_code[3]='\0';
         //exit(1);
        }
     else
         {amount = amount * equal_value[code_no];
         return amount;}
    }
}

int find_code(char *s)
{
 int i=0;

 while ((i<10) && (strcmp(s,code_table[i])!=0))
       i++;

 return i;
}


void display(int sock)
{
 int i;
 char * space = "\t\t";
 char * new_line = "\n"; 
 char buf[20];


 for(i=0; i<10; i++)
     {
      write(sock, country_table[i], sizeof buf);//country_table[i]);
      read(sock, buf, sizeof buf);
      write(sock, space, sizeof space);
      read(sock, buf, sizeof buf);
      write(sock, code_table[i], sizeof code_table[i]);
      read(sock, buf, sizeof buf);
      write(sock, new_line, sizeof new_line);
      read(sock, buf, sizeof buf);
     }

}
